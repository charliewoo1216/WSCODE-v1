# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

WSCODE — VSCode 스타일 AI 코드 에디터 (Electron + Monaco Editor + Local LLM)
주요 언어: Python, Java, JavaScript/TypeScript

## 작업 지침

**작업 전 반드시 아래 파일을 확인할 것:**
- `TASKLIST.md` — 전체 작업 목록, 진행 상태
- `AI-COPILOT.md` — AI Copilot 기능 상세, 구현 파일 경로

작업 완료 후 해당 파일의 체크리스트를 업데이트할 것.

## 프로젝트 구조

```
src/
├── main.js          # Electron 메인 (IPC, AI 프록시, 터미널 UTF-8, 캐시)
└── preload.js       # contextBridge IPC 브릿지

renderer/
├── index.html       # 메인 UI
├── css/styles.css   # 다크 테마
└── js/
    ├── app.js             # 초기화, 단축키, Command Palette, Quick Open, 검색, 터미널
    ├── ai-service.js      # AIService (LLM, 캐시, Ghost Text, VS Code 스타일 시스템 프롬프트)
    ├── ai-panel.js        # AIPanel (채팅, @ 자동완성, 자동 Diff, Help 가이드, 히스토리)
    ├── editor-manager.js  # Monaco, 메인 Diff 탭, 백업(-bak01), AI 우클릭 메뉴
    └── file-tree.js       # 파일 탐색기, 컨텍스트 메뉴, 파일 감시

프로젝트/.history/     # 채팅 히스토리 (워크스페이스별 JSON)
userData/ai-cache/     # AI 캐시 (LLM 24h / RAG 5m / Semantic 48h)
```

## 실행

```bash
npm install
npm start
```

## 기술 스택

- **Framework**: Electron 41 + Node.js 20
- **Editor**: Monaco Editor (VSCode 동일 엔진)
- **AI**: Local LLM (OpenAI 호환, 기본 `http://192.168.0.8:8080`)
- **AI Diff**: 메인 에디터 자동 Diff + 백업 (`-bak01`, `-bak02`)
- **AI Prompt**: 한국어 전용, VS Code Copilot 스타일 (원본 유지, 생략 금지)
- **AI Cache**: JSON (LLM/RAG/Semantic)
- **Terminal**: xterm.js + child_process, UTF-8 (chcp 65001)
- **Theme**: Dark 전용
- **주요 언어**: Python (PEP 8), Java (Google Style), JS/TS
