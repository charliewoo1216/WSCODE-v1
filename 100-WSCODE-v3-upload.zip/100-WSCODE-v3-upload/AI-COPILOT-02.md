# AI-COPILOT-02.md — WSCODE AI Copilot 기능 분석표

> 소스 코드 분석 기준일: 2026-04-05

---

## 1. AI 핵심 기능 요약

| # | 기능 | 설명 | 구현 파일 | 핵심 메서드/위치 |
|---|------|------|-----------|-----------------|
| 1 | **AI 채팅 (Streaming)** | 사용자 메시지를 Local LLM에 스트리밍으로 전송, 실시간 응답 표시 | `ai-service.js`, `ai-panel.js` | `sendMessageStream()`, `send()` |
| 2 | **AI 채팅 (Non-streaming)** | 일반 요청/응답 방식 LLM 호출 | `ai-service.js` | `sendMessage()`, `callLLM()` |
| 3 | **Ghost Text (Inline Completion)** | 코드 작성 중 AI 자동완성 제안 (회색 텍스트) | `ai-service.js`, `editor-manager.js` | `getInlineCompletion()`, `setupInlineCompletions()` |
| 4 | **자동 Diff (메인 에디터)** | AI 응답에 코드블록이 있으면 메인 에디터에 자동으로 Diff 표시 | `ai-panel.js`, `editor-manager.js` | `autoShowDiff()`, `showDiffInEditor()` |
| 5 | **수동 Diff (채팅 내)** | 채팅 코드블록의 Apply 버튼으로 Diff 표시 | `ai-panel.js` | `showDiffAndApply()`, `attachCodeBlockActions()` |
| 6 | **자동 백업 + Apply** | Accept 시 원본을 `-bak01` 형식으로 백업 후 수정 적용 | `editor-manager.js` | `backupAndApply()` |
| 7 | **@ 컨텍스트 시스템** | `@file`, `@workspace`, `@selection`으로 AI에 컨텍스트 전달 | `ai-panel.js` | `atDetect()`, `atShow()`, `atSelect()` |
| 8 | **프로젝트 분석 (@workspace)** | 전체 프로젝트 파일 스캔 + 대형 프로젝트 청크 분석 | `ai-service.js`, `main.js` | `analyzeProject()`, `analyzeProjectChunked()` |
| 9 | **우클릭 AI 메뉴** | 코드 선택 후 우클릭으로 AI 작업 실행 (5종) | `editor-manager.js` | `addAction()` (id: ai-explain 등) |
| 10 | **코드 검증 컨텍스트** | ESLint/py_compile 결과를 AI 컨텍스트에 자동 포함 | `ai-service.js`, `main.js` | `getValidationContext()`, `run-validation` IPC |
| 11 | **대화 히스토리** | 채팅 저장/로드/삭제 (워크스페이스별 JSON) | `ai-panel.js`, `main.js` | `saveCurrentChat()`, `loadChatById()`, `showChatHistory()` |
| 12 | **대화 자동 압축** | 10+ 메시지 또는 3000+ 토큰 시 이전 대화 요약 | `ai-service.js` | `compressHistory()` |
| 13 | **3계층 캐시** | LLM 캐시(24h) + RAG 캐시(5m) + Semantic 캐시(48h) | `ai-service.js`, `main.js` | `cache-get/set`, `rag-cache-*`, `semantic-cache-*` |
| 14 | **모델 선택** | API에서 사용 가능한 모델 목록 조회 및 동적 전환 | `ai-service.js`, `ai-panel.js` | `fetchModels()`, `initModelSelector()` |
| 15 | **AI 설정 패널** | API URL, Key, Model, System Prompt 설정 | `app.js`, `main.js` | `btn-ai-settings` 이벤트, `load/save-settings` IPC |
| 16 | **생성 중지** | 스트리밍 응답 중 Stop 버튼으로 즉시 중단 | `ai-panel.js`, `main.js` | `stopGenerating()`, `ai-stream-abort` IPC |
| 17 | **멀티파일 Diff** | AI 응답에 여러 파일 코드블록이 있을 때 개별/일괄 적용 | `ai-panel.js` | `parseMultiFileBlocks()`, `showMultiFileDiff()` |
| 18 | **AI Help 가이드** | 사용법 안내 (도움말 패널) | `ai-panel.js` | `showAiHelp()` |

---

## 2. @ 컨텍스트 명령어

| 명령어 | 기능 | 동작 방식 |
|--------|------|-----------|
| `@file` | 현재 파일 전달 | 파일 전체 내용을 컨텍스트 칩으로 추가 |
| `@workspace` | 프로젝트 전체 분석 | 파일 트리 스캔 → RAG 캐시 확인 → 대형 프로젝트는 청크 분석 |
| `@selection` | 선택 코드 전달 | 에디터 선택 영역을 컨텍스트로 추가 (`Ctrl+L`과 동일) |

---

## 3. 에디터 우클릭 AI 메뉴

| 메뉴 | ID | 프롬프트 요약 | 기대 응답 형식 |
|------|----|-------------|---------------|
| AI: Explain This Code | `ai-explain` | 선택 코드 상세 설명 | 텍스트만 (코드블록 없음) |
| AI: Refactor This Code | `ai-refactor` | 가독성, 성능, 베스트 프랙티스 개선 | 이유 1줄 + 전체 수정 코드블록 |
| AI: Generate Tests | `ai-test` | 언어별 테스트 프레임워크로 테스트 생성 | 테스트 코드블록 |
| AI: Fix Bugs | `ai-fix` | 버그 탐지 및 수정 | 원인 설명 + 수정 코드블록 |
| AI: Add Comments | `ai-comment` | 명확한 주석 추가 | 주석 포함 전체 코드블록 |

---

## 4. Diff & Apply 시스템

| 구분 | 동작 | 트리거 조건 |
|------|------|------------|
| **자동 Diff** | AI 응답 완료 시 메인 에디터에 Side-by-side Diff 자동 표시 | 파일 컨텍스트 활성 + 코드블록 5줄 이상 + 원본 대비 20%+ 크기 |
| **수동 Diff (메인 에디터)** | 채팅 코드블록 `Apply` 버튼 클릭 → 메인 에디터 Diff | 파일이 열려있을 때 |
| **수동 Diff (채팅 내)** | 메인 에디터 Diff 불가 시 채팅 내부 Monaco DiffEditor | 폴백 |
| **멀티파일 Diff** | 여러 파일 코드블록 감지 시 개별/일괄 Accept/Reject | `### filename` 또는 ` ```lang:filepath` 패턴 |
| **Accept** | Modified 쪽 편집 가능 → Accept 시 원본 백업(`-bak01`) + 디스크 저장 | 버튼 클릭 |
| **Discard** | 변경 취소, 원본 유지 | 버튼 클릭 |
| **View 토글** | Side-by-side ↔ Inline 전환 | 토글 버튼 |

---

## 5. 캐시 시스템

| 캐시 유형 | TTL | 키 생성 방식 | 저장 위치 |
|-----------|-----|-------------|-----------|
| **LLM 캐시** | 24시간 | `model + 최근 3개 메시지` → hash | `userData/ai-cache/llm/` |
| **RAG 캐시** | 5분 | `rootPath` → MD5 hash | `userData/ai-cache/rag/` |
| **Semantic 캐시** | 48시간 | 질문 텍스트 Bigram Dice 유사도 ≥ 0.85 | `userData/ai-cache/semantic/` |

---

## 6. 단축키

| 단축키 | 기능 | 구현 위치 |
|--------|------|-----------|
| `Ctrl+Shift+I` | AI 패널 열기/닫기 | `app.js` |
| `Ctrl+L` | 선택 영역을 AI 채팅에 전송 | `editor-manager.js` |
| `Ctrl+I` | Ghost Text (Inline Completion) on/off | `app.js` |
| `Ctrl+S` | 파일 저장 | `editor-manager.js` |

---

## 7. AI API 아키텍처

| 계층 | 역할 | 통신 방식 |
|------|------|-----------|
| **Renderer** (`ai-service.js`) | LLM 호출 요청, 캐시 키 생성, 프롬프트 빌드 | `window.api.*` (IPC) |
| **Preload** (`preload.js`) | contextBridge IPC 브릿지 | `ipcRenderer` ↔ `ipcMain` |
| **Main** (`main.js`) | HTTP/HTTPS 프록시, 캐시 파일 I/O, 스트리밍 처리 | Node.js `http/https` |
| **LLM Server** | OpenAI 호환 API (기본 `http://192.168.0.8:8080`) | REST `/v1/chat/completions` |

---

## 8. 시스템 프롬프트 주요 규칙

| 규칙 | 내용 |
|------|------|
| 언어 | 반드시 한국어로 답변 |
| 코드 수정 | 원본 전체 유지, 요청 부분만 수정, 생략 금지 |
| 출력 형식 | 전체 파일을 하나의 코드블록으로 출력 (언어 태그 포함) |
| 코딩 컨벤션 | Python: PEP 8, Java: Google Style |
| 보안 | XSS, SQL Injection 등 취약점 경고 |
| Diff 최적화 | 불필요한 변경 금지 (실제 변경 줄만 하이라이트) |

---

## 9. 파일별 AI 관련 코드 분포

| 파일 | 라인 수 | AI 관련 주요 내용 |
|------|---------|-----------------|
| `renderer/js/ai-service.js` | ~403 | LLM 호출, 캐시, Ghost Text, 프로젝트 분석, 프롬프트 빌드 |
| `renderer/js/ai-panel.js` | ~1037 | 채팅 UI, @ 자동완성, Diff 렌더링, 히스토리, Help, 멀티파일 |
| `renderer/js/editor-manager.js` | ~734 | Monaco 에디터, 우클릭 메뉴, Inline Completion, Diff 에디터, 백업 |
| `src/main.js` | ~830 | IPC 핸들러, AI 프록시, 스트리밍, 캐시 I/O, 코드 검증 |
| `renderer/js/app.js` | ~800+ | 설정, 단축키, AI 패널 토글, Command Palette |
