# Woo-Code - Task List

> **핵심 목표**: AI Copilot 패널이 최우선. Local LLM (OpenAI 호환 API) 기반.
> **주요 언어**: Python, Java, JavaScript/TypeScript
> **제외**: Git 소스 관리 (Source Control) — 추후 별도 추가

---

## Phase 1: Core Layout — ✅ 완료
- [x] Title Bar - 커스텀 타이틀바 (메뉴 + 창 컨트롤 버튼)
- [x] Activity Bar - 좌측 아이콘 바 (Explorer, Search, AI Chat)
- [x] Side Bar (좌) - Explorer 패널 (폴더 트리, 열기/닫기 토글)
- [x] Editor Group - 탭 + 에디터 영역 (Monaco Editor)
- [x] Secondary Side Bar (우) - AI Copilot 패널 전용
- [x] Panel - 하단 패널 (Terminal)
- [x] Status Bar - 하단 상태바
- [x] 레이아웃 리사이즈 (사이드바, 패널 드래그로 크기 조절)

## Phase 2: AI Copilot Panel — ✅ 완료

### 2-1. 채팅 UI — ✅ 완료
- [x] 우측 채팅 패널 + 헤더 아이콘 (? 도움말, 📜 히스토리, + 새 세션, ⚙ 설정)
- [x] 멀티라인 입력 (Shift+Enter 줄바꿈, Enter 전송)
- [x] `@` 입력 시 자동완성 팝업 (@file, @workspace, @selection)
- [x] AI 응답 마크다운 렌더링 (코드블록 보호 방식)
- [x] 코드블록 Copy / Apply 버튼
- [x] 스트리밍 응답 + Stop 버튼
- [x] 한국어 전용 시스템 프롬프트 (VS Code Copilot 스타일, 설정에서 변경 가능)

### 2-2. Diff & Apply — ✅ 완료
- [x] AI 응답 완료 시 자동 Diff 표시 (코드블록 감지 → 메인 에디터)
- [x] VS Code 스타일 Diff 탭 ("filename (Changes)")
- [x] Side-by-side / Inline 토글, Modified 쪽 편집 가능
- [x] Accept Changes → 자동 백업(`-bak01`, `-bak02`) + 디스크 저장
- [x] Discard → 원본 유지, 에디터 복귀
- [x] 수동 Apply도 가능 (채팅 코드블록 Apply 버튼)

### 2-3. LLM Backend — ✅ 완료
- [x] Local LLM API (OpenAI 호환 `/v1/chat/completions`)
- [x] 기본값: URL `http://192.168.0.8:8080` / Key `sk_123!` / Model `qwen3.5:9b`
- [x] API URL / Key / Model 설정 UI (변경 가능)
- [x] 모델 목록 조회 (`/v1/models`)
- [x] SSE 스트리밍 + 요청 취소 (Stop 버튼)
- [x] 에러 핸들링 (timeout 15s, resolve로 안전 처리)

### 2-4. 프로젝트 분석 — ✅ 완료
- [x] 전체 프로젝트 파일 스캔 (node_modules/.git 등 제외)
- [x] @workspace / @file / @selection 컨텍스트 시스템
- [x] 분석 결과 RAG 캐싱 (5분 TTL)
- [x] 대용량 프로젝트 → 청크 분할 (15파일/청크) + LLM 요약

### 2-5. AI 인라인 기능 — ✅ 완료
- [x] Ghost Text 자동완성 (Ctrl+I 토글)
- [x] 에디터 우클릭 AI 메뉴 (Explain / Refactor / Tests / Fix / Comments)

### 2-6. AI 최적화 — ✅ 완료
- [x] LLM 캐시 (24h) / RAG 캐시 (5m) / Semantic 캐시 (48h)
- [x] 대화 압축 (10+ 메시지 시 자동 요약)
- [x] 코드 검증 자동화 (ESLint, py_compile → AI 컨텍스트)

## Phase 3: Editor (Monaco Editor) — ✅ 완료
- [x] Monaco Editor, 다중 탭, Breadcrumb, Minimap
- [x] 구문 강조 (Python, Java, JS/TS, HTML/CSS, JSON, Markdown 등)
- [x] 다중 에디터 분할 (Ctrl+\)

## Phase 4: Activity Bar & Side Bar — ✅ 완료
- [x] Explorer (파일/폴더 트리, 우클릭 메뉴)
- [x] Search (정규식, 대소문자, Replace All)

## Phase 5: 파일 시스템 — ✅ 완료
- [x] 파일 열기/저장, 폴더 열기, 파일 감시 (fs.watch)
- [x] Command Palette (Ctrl+Shift+P) / Quick Open (Ctrl+P)
- [x] 자동 저장

## Phase 6: Terminal — ✅ 완료
- [x] xterm.js + child_process (PowerShell/bash)
- [x] 다중 터미널 탭
- [x] 한글 UTF-8 인코딩 (chcp 65001)

## Phase 7: 설정 — ✅ 완료
- [x] Dark Theme (다크 전용)
- [x] 설정: API URL, Key, Model, System Prompt, 폰트, 자동 저장
- [x] 채팅 히스토리: 워크스페이스 `.history/` 폴더에 저장

---

## 기술 스택
| 영역 | 기술 |
|------|------|
| Framework | Electron 41 + Node.js 20 |
| Editor | Monaco Editor |
| Terminal | xterm.js + child_process (UTF-8) |
| AI Backend | Local LLM (OpenAI 호환 `/v1/chat/completions`) |
| AI Diff | 메인 에디터 DiffEditor + 자동 백업 |
| AI Cache | JSON file-based (LLM/RAG/Semantic) |
| 주요 언어 | Python, Java, JS/TS |

## 단축키 맵
| 단축키 | 기능 |
|--------|------|
| Ctrl+Shift+P | Command Palette |
| Ctrl+P | Quick Open |
| Ctrl+B | 사이드바 토글 |
| Ctrl+` | 터미널 토글 |
| Ctrl+L | 선택 영역 → AI 전송 |
| Ctrl+I | Ghost Text 토글 |
| Ctrl+Shift+I | AI 패널 토글 |
| Ctrl+Shift+F | 전체 검색 |
| Ctrl+\ | Split Editor |
| Ctrl+S | 저장 |
| Ctrl+N | 새 파일 |
