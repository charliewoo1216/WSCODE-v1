import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests
import json

API_KEY = "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"
BASE_URL = "https://openrouter.ai/api/v1/chat/completions"
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}

MODELS = [
    "google/gemma-3-27b-it:free",
    "nvidia/nemotron-3-super-120b-a12b:free",
]

for model in MODELS:
    print(f"\n{'='*50}")
    print(f"모델: {model}")
    print('='*50)

    # 첫 번째 요청
    print("\n--- 첫 번째 요청 ---")
    response = requests.post(
        url=BASE_URL,
        headers=HEADERS,
        json={
            "model": model,
            "messages": [
                {"role": "user", "content": "How many r's are in the word 'strawberry'?"}
            ],
        },
        timeout=30
    )

    if response.status_code != 200:
        print(f"Error: {response.status_code} - {response.text[:200]}")
        continue

    result = response.json()
    assistant_msg = result['choices'][0]['message']
    print(f"답변: {assistant_msg.get('content')}")

    # 두 번째 요청 (후속 질문)
    print("\n--- 두 번째 요청 ---")
    messages = [
        {"role": "user", "content": "How many r's are in the word 'strawberry'?"},
        {"role": "assistant", "content": assistant_msg.get('content')},
        {"role": "user", "content": "Are you sure? Think carefully."}
    ]

    response2 = requests.post(
        url=BASE_URL,
        headers=HEADERS,
        json={"model": model, "messages": messages},
        timeout=30
    )

    if response2.status_code != 200:
        print(f"Error: {response2.status_code} - {response2.text[:200]}")
        continue

    result2 = response2.json()
    print(f"답변: {result2['choices'][0]['message'].get('content')}")
