import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests

API_KEY = "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"
BASE_URL = "https://openrouter.ai/api/v1/chat/completions"
MODELS_URL = "https://openrouter.ai/api/v1/models"
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}

BANNER = """
╔══════════════════════════════════════╗
║           Woo-Code v1.0             ║
║   OpenRouter Free Model Chat        ║
╚══════════════════════════════════════╝
"""


def get_free_models():
    """무료 모델 목록을 가져온다."""
    print("무료 모델 목록을 가져오는 중...")
    r = requests.get(MODELS_URL, headers=HEADERS, timeout=15)
    if r.status_code != 200:
        print(f"모델 목록 조회 실패: {r.status_code}")
        return []
    models = r.json().get('data', [])
    return [m['id'] for m in models if ':free' in m['id']]


def check_model(model):
    """모델이 실제 응답 가능한지 빠르게 확인한다."""
    try:
        r = requests.post(BASE_URL, headers=HEADERS, json={
            "model": model,
            "messages": [{"role": "user", "content": "Hi"}],
            "max_tokens": 5,
        }, timeout=10)
        return r.status_code == 200
    except Exception:
        return False


def find_available_models(free_models, count=5):
    """응답 가능한 무료 모델을 count개 찾는다."""
    print(f"응답 가능한 모델을 탐색 중 (최대 {count}개)...\n")
    available = []
    for model in free_models:
        status = "확인 중..."
        print(f"  [{len(available)}/{count}] {model} - {status}", end="", flush=True)
        if check_model(model):
            available.append(model)
            print(f"\r  [{len(available)}/{count}] {model} - OK       ")
        else:
            print(f"\r  [ - ] {model} - 사용불가   ")
        if len(available) >= count:
            break
    return available


def select_model(models):
    """사용자에게 모델을 선택하게 한다."""
    print(f"\n사용 가능한 무료 모델 ({len(models)}개):")
    print("-" * 45)
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")
    print("-" * 45)

    while True:
        try:
            choice = input(f"\n모델을 선택하세요 (1-{len(models)}): ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                return models[idx]
        except (ValueError, EOFError):
            pass
        print("잘못된 입력입니다. 다시 선택하세요.")


def chat(model):
    """선택한 모델과 대화한다."""
    print(f"\n선택된 모델: {model}")
    print("대화를 시작합니다. 종료하려면 'quit' 또는 'q'를 입력하세요.\n")

    messages = []

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if user_input.lower() in ('quit', 'q', ''):
            break

        messages.append({"role": "user", "content": user_input})

        print("AI: ", end="", flush=True)
        try:
            r = requests.post(BASE_URL, headers=HEADERS, json={
                "model": model,
                "messages": messages,
            }, timeout=60)

            if r.status_code != 200:
                print(f"[Error {r.status_code}]")
                messages.pop()
                continue

            content = r.json()['choices'][0]['message'].get('content', '')
            print(content)
            messages.append({"role": "assistant", "content": content})

        except requests.exceptions.Timeout:
            print("[시간 초과]")
            messages.pop()
        except Exception as e:
            print(f"[오류: {e}]")
            messages.pop()

        print()


def main():
    print(BANNER)

    free_models = get_free_models()
    if not free_models:
        print("사용 가능한 무료 모델이 없습니다.")
        return

    available = find_available_models(free_models, count=5)
    if not available:
        print("현재 응답 가능한 무료 모델이 없습니다. 잠시 후 다시 시도하세요.")
        return

    model = select_model(available)
    chat(model)

    print("\nWoo-Code를 종료합니다. 감사합니다!")


if __name__ == "__main__":
    main()
