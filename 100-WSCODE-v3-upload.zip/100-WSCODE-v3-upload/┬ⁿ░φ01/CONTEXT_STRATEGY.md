# Local LLM 코딩 어시스턴트 — 문맥 유지 전략

> 환경: RTX 3060 12GB / qwen3.5:9b (Q4_K_M, 9.7B) / Ollama
> 측정일: 2026-04-05

---

## 1. 하드웨어 제약 요약

| 항목 | 값 |
|------|-----|
| GPU VRAM | 12,288 MiB |
| 모델 VRAM (idle) | ~6.5 GB |
| KV Cache 가용 VRAM | ~4.5 GB |
| 모델 스펙 max context | 262,144 (256K) |
| 실측 안정 max num_ctx | 32,768 (32K) — 응답 느림 |
| 실측 쾌적 num_ctx | **24,576 (24K)** — GPU 72% |
| 24K 기준 응답속도 | prompt 평가 ~2분, 생성 ~15 tok/s |

---

## 2. 토큰 예산 설계 (24K 기준)

24,576 토큰을 한 번의 LLM 호출에서 아래와 같이 분배한다.

```
┌─────────────────────────────────────────────────┐
│              총 예산: 24,576 토큰                │
├─────────────────────────────────────────────────┤
│ ① 시스템 프롬프트          ~1,024 tok  (  4%)   │
│ ② 프로젝트 컨텍스트        ~4,096 tok  ( 17%)   │
│ ③ 대화 히스토리 (슬라이딩)  ~14,336 tok ( 58%)   │
│ ④ 현재 사용자 질의          ~3,072 tok  ( 13%)   │
│ ⑤ 응답 생성 여유            ~2,048 tok  (  8%)   │
└─────────────────────────────────────────────────┘
```

### 각 영역 설명

| 영역 | 용도 | 관리 방식 |
|------|------|-----------|
| **① 시스템 프롬프트** | 역할 정의, 코딩 규칙, 출력 형식 | 고정. 프로젝트별 `system_prompt.md`에서 로드 |
| **② 프로젝트 컨텍스트** | 아키텍처, 파일 구조, 현재 작업 요약 | `PROJECT.md`에서 동적 로드 (Claude Code의 CLAUDE.md 방식) |
| **③ 대화 히스토리** | 이전 대화 턴 | 슬라이딩 윈도우로 관리 |
| **④ 현재 질의** | 사용자 입력 + 코드 스니펫 | 매 턴 새로 구성 |
| **⑤ 응답 여유** | LLM 생성 공간 (`num_predict`) | `num_predict: 2048`로 제한 |

---

## 3. 슬라이딩 윈도우 전략

### 3.1 기본 원리

대화가 길어지면 전체를 넣을 수 없으므로, **최근 N턴 + 요약**으로 구성한다.

```
[시스템 프롬프트] + [프로젝트 컨텍스트] + [세션 요약] + [최근 대화] + [현재 질의]
          ①               ②              ③-a           ③-b           ④
```

### 3.2 구현 방식

```python
MAX_HISTORY_TOKENS = 14336

def build_messages(conversation_history, current_query, project_context, system_prompt):
    messages = []

    # ① 시스템 프롬프트 (고정)
    messages.append({"role": "system", "content": system_prompt})

    # ② 프로젝트 컨텍스트를 시스템에 포함
    messages.append({"role": "system", "content": project_context})

    # ③ 대화 히스토리 — 뒤에서부터 토큰 예산 내에서 채움
    history_tokens = 0
    included = []
    for turn in reversed(conversation_history):
        turn_tokens = estimate_tokens(turn["content"])
        if history_tokens + turn_tokens > MAX_HISTORY_TOKENS:
            break
        included.insert(0, turn)
        history_tokens += turn_tokens

    # 잘린 히스토리가 있으면 요약을 맨 앞에 삽입
    if len(included) < len(conversation_history):
        dropped = conversation_history[:len(conversation_history) - len(included)]
        summary = summarize_turns(dropped)  # LLM 또는 규칙 기반 요약
        messages.append({"role": "system", "content": f"[이전 대화 요약]\n{summary}"})

    messages.extend(included)

    # ④ 현재 질의
    messages.append({"role": "user", "content": current_query})

    return messages
```

### 3.3 토큰 추정 함수

Ollama에는 토크나이저 API가 없으므로 근사치를 사용한다.

```python
def estimate_tokens(text: str) -> int:
    """영어 ~1.3 char/tok, 한국어 ~2.5 char/tok, 코드 ~3 char/tok 기준 혼합 추정"""
    # 보수적으로 3 chars = 1 token (과대 추정이 과소 추정보다 안전)
    return len(text) // 3 + 1
```

### 3.4 요약 트리거 조건

| 조건 | 동작 |
|------|------|
| 대화 히스토리 > 14K 토큰 | 오래된 턴을 요약으로 압축 |
| 5턴마다 | 자동으로 중간 요약 생성 |
| 사용자가 주제 전환 시 | 이전 주제 전체를 요약으로 교체 |

---

## 4. 세션 영속화 (중단/재개)

Claude Code의 memory 시스템을 차용하여 파일 기반으로 세션을 관리한다.

### 4.1 디렉토리 구조

```
project_root/
├── .assistant/
│   ├── PROJECT.md          # 프로젝트 전체 컨텍스트 (CLAUDE.md 역할)
│   ├── MEMORY.md           # 메모리 인덱스
│   ├── memory/
│   │   ├── architecture.md # 아키텍처 메모
│   │   ├── decisions.md    # 설계 결정 사항
│   │   └── bugs.md         # 알려진 이슈
│   └── sessions/
│       ├── active.json     # 현재 세션 상태
│       └── archive/
│           └── 2026-04-05_auth-refactor.json
```

### 4.2 세션 파일 형식 (`active.json`)

```json
{
  "session_id": "2026-04-05-1430",
  "task": "auth 미들웨어 리팩토링",
  "started_at": "2026-04-05T14:30:00",
  "last_active": "2026-04-05T16:45:00",
  "summary": "JWT 검증 로직을 middleware에서 분리하여 별도 서비스로 추출 중. verify_token() 완료, refresh 로직 진행 중.",
  "key_decisions": [
    "토큰 저장소를 Redis에서 PostgreSQL로 변경 (compliance 요구)",
    "refresh token rotation 적용"
  ],
  "modified_files": [
    "src/auth/service.py",
    "src/middleware/jwt.py"
  ],
  "conversation_summary": "사용자가 auth 미들웨어 분리를 요청. verify_token 함수를 AuthService 클래스로 이동 완료. refresh token 로직에서 race condition 발견하여 DB 락 적용 논의 중.",
  "pending_tasks": [
    "refresh_token() 구현",
    "기존 테스트 마이그레이션"
  ],
  "context_snapshot": {
    "recent_turns": 3,
    "total_turns": 12,
    "compressed_history": "..."
  }
}
```

### 4.3 세션 재개 시 컨텍스트 복원 순서

```
1. PROJECT.md 로드               → ② 프로젝트 컨텍스트 슬롯
2. active.json의 summary 로드    → ③-a 세션 요약 슬롯
3. key_decisions 로드             → ③-a에 추가
4. modified_files의 현재 상태 로드 → ④에 필요 시 포함
5. 사용자의 새 질의 수신           → ④ 현재 질의 슬롯
```

이렇게 하면 **이전 대화 없이도** 핵심 문맥이 ~3,000 토큰 내에서 복원된다.

---

## 5. PROJECT.md 작성 가이드 (CLAUDE.md 방식)

```markdown
# PROJECT.md — 코딩 어시스턴트 컨텍스트

## 프로젝트 개요
- 이름, 목적, 기술 스택 한 줄 요약

## 아키텍처
- 핵심 모듈 간 관계 (3~5줄)
- 데이터 흐름

## 현재 작업
- 진행 중인 태스크와 이유
- 최근 변경사항 요약

## 규칙
- 코딩 컨벤션, 금지 패턴
- 테스트/빌드 명령어
```

**핵심 원칙**: LLM이 코드를 읽으면 알 수 있는 것은 쓰지 않는다. 코드만으로는 알 수 없는 **왜(why)와 결정(decision)**만 기록한다.

---

## 6. Ollama 최적 호출 파라미터

```python
OLLAMA_PARAMS = {
    "model": "qwen3.5:9b",
    "options": {
        "num_ctx": 24576,          # 24K — 안정적 최대값
        "num_predict": 2048,       # 응답 길이 제한 → 속도 확보
        "temperature": 0.3,        # 코딩 작업은 낮은 temperature
        "top_p": 0.9,
        "top_k": 20,
        "repeat_penalty": 1.1,
        "num_gpu": 99,             # 전체 레이어 GPU 오프로드
        "num_thread": 4,           # CPU 스레드 (보조 연산용)
    },
    "stream": True,                # 스트리밍으로 체감 속도 향상
    "keep_alive": "10m",           # 10분간 모델 VRAM 유지
}
```

---

## 7. 성능 최적화 팁

### 응답 속도 개선

| 방법 | 효과 |
|------|------|
| `num_predict: 2048` 제한 | 불필요한 긴 응답 방지 |
| `stream: true` | 첫 토큰까지 대기시간 감소 |
| `keep_alive: "10m"` | 모델 재로드 방지 (~30초 절약) |
| 프롬프트 내 코드 최소화 | 전체 파일 대신 관련 함수만 포함 |

### 토큰 절약 기법

| 방법 | 절약량 |
|------|--------|
| 코드를 파일 경로 + 라인 번호로 참조 | 수천 토큰 |
| diff만 전달 (전체 파일 대신) | 50~80% |
| 대화 요약 압축 (5턴→1요약) | 60~70% |
| 시스템 프롬프트 간결화 | 수백 토큰 |

---

## 8. 전체 흐름 다이어그램

```
사용자 입력
    │
    ▼
┌─────────────────┐
│ 토큰 예산 계산    │ ← estimate_tokens()
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌──────────────┐
│ 히스토리 14K 초과?│──Y──▶│ 오래된 턴 요약 │
└────────┬────────┘     └──────┬───────┘
         │N                    │
         ▼                     ▼
┌─────────────────────────────────────┐
│ 메시지 조립                          │
│ [시스템][프로젝트][요약][최근][질의]   │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────┐
│ Ollama API 호출  │ ← num_ctx=24K, num_predict=2048
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 응답 + 히스토리   │
│ 저장 & 표시       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌──────────────────┐
│ 5턴 도달?        │──Y──▶│ 세션 파일 자동저장 │
└────────┬────────┘     └──────────────────┘
         │N
         ▼
    다음 입력 대기
```

---

## 9. 핵심 수치 요약

| 항목 | 값 | 근거 |
|------|-----|------|
| num_ctx | 24,576 | 실측 안정 + GPU 72% |
| num_predict | 2,048 | 코딩 응답 충분 + 속도 |
| 대화 히스토리 예산 | 14,336 | 전체의 58% |
| 프로젝트 컨텍스트 | 4,096 | PROJECT.md 1페이지 분량 |
| 요약 트리거 | 5턴 또는 14K 초과 | 품질/속도 균형 |
| 세션 자동저장 | 5턴마다 | 중단 시 복원 보장 |
| 세션 복원 비용 | ~3,000 토큰 | 24K 중 12% |
