# Woo-Code AI Copilot

> AI Copilot 기능 체크리스트 및 구현 현황

---

## 1. 채팅 UI — ✅ 완료
- [x] 우측 채팅 패널 — `ai-panel.js`
- [x] 헤더 아이콘: ? (도움말) / 📜 (히스토리) / + (새 세션) / ⚙ (설정)
- [x] `@` 입력 시 자동완성 팝업 — `atDetect()`, `atShow()`
- [x] 마크다운 렌더링 (코드블록 보호) — `renderMarkdown()`
- [x] 코드블록 Copy / Apply 버튼
- [x] 스트리밍 응답 + Stop 버튼 — `stopGenerating()`
- [x] 한국어 전용 VS Code Copilot 스타일 시스템 프롬프트 (설정에서 변경 가능)
- [x] 주요 언어: Python (PEP 8), Java (Google Style), JS/TS

## 2. Diff & Apply — ✅ 완료
- [x] **AI 응답 완료 시 자동 Diff 표시** — `autoShowDiff()`
- [x] VS Code 스타일 Diff 탭 ("filename (Changes)") — `showDiffInEditor()`
- [x] Side-by-side / Inline 토글, Modified 쪽 편집 가능
- [x] Accept Changes → 자동 백업(`-bak01`, `-bak02`) + 디스크 저장 — `backupAndApply()`
- [x] Discard → 원본 유지, 에디터 복귀
- [x] 수동 Apply (채팅 코드블록 Apply 버튼)
- [x] Diff 탭 X 버튼으로 닫기

### Diff 흐름
```
파일 열기 → @file → AI에게 수정 요청
→ AI 응답 완료 (코드블록 감지)
→ 자동으로 메인 에디터에 Diff 표시
→ Accept Changes: 원본 백업(-bak01) + 수정 적용 + 디스크 저장
→ Discard: 원본 유지, 에디터 복귀
```

## 3. LLM Backend — ✅ 완료
- [x] Local LLM API (OpenAI 호환 `/v1/chat/completions`) — `callLLM()`
- [x] 기본: URL `http://192.168.0.8:8080` / Key `sk_123!` / Model `qwen3.5:9b`
- [x] 설정에서 URL / Key / Model 변경 가능
- [x] 모델 목록 조회 (`/v1/models`) — `fetchModels()`
- [x] SSE 스트리밍 + 요청 취소 — `aiStreamAbort`

## 4. 컨텍스트 시스템 — ✅ 완료
- [x] `@file` — 현재 파일 컨텍스트 (명시적 사용 시만)
- [x] `@workspace` — 전체 프로젝트 분석 (30+파일 시 청크 분할)
- [x] `@selection` (Ctrl+L) — 선택 영역 전송
- [x] 컨텍스트 칩 표시/삭제
- [x] 코드 검증 결과 자동 주입 (`@file` 시) — `getValidationContext()`
- [x] 새 세션 시 컨텍스트 초기화

## 5. Ghost Text — ✅ 완료
- [x] 커서 위치 자동완성 — `setupInlineCompletions()`
- [x] Tab 수락 / Esc 취소 / Ctrl+I 토글

## 6. 에디터 AI 메뉴 — ✅ 완료
- [x] 우클릭: Explain / Refactor / Tests / Fix / Comments
- [x] `sendWithPrompt()` — 자동 패널 열기 + 전송

## 7. 채팅 히스토리 — ✅ 완료
- [x] 워크스페이스 `.history/` 폴더에 JSON 저장
- [x] 자동 저장 / 목록 표시 / 불러오기 / 삭제
- [x] 대화 압축 (10+ 메시지 시 자동 요약)

## 8. AI 캐시 시스템 — ✅ 완료
- [x] LLM 캐시 (24h TTL)
- [x] RAG 캐시 (5m TTL)
- [x] Semantic 캐시 (48h TTL, Dice 0.85, 컨텍스트 없을 때만)
- [x] 코드 검증 자동화 (ESLint, py_compile)

---

## 시스템 프롬프트 주요 내용
- 한국어 전용 답변
- 원본 코드 전체 유지, 요청 부분만 수정
- 전체 파일 코드블록 출력 (생략 금지)
- 기존 스타일 유지 (Python PEP 8, Java Google Style)
- Diff 최적화 (불필요한 변경 금지)
- 우클릭 메뉴별 응답 형식 지정

## 단축키
| 단축키 | 기능 |
|--------|------|
| Ctrl+Shift+I | AI 패널 토글 |
| Ctrl+L | 선택 영역 → AI 전송 |
| Ctrl+I | Ghost Text 토글 |
| `@` 입력 | 명령어 팝업 |

## 헤더 아이콘
| 아이콘 | 기능 |
|--------|------|
| ? | AI 기능 가이드 |
| 📜 | 이전 대화 목록 |
| + | 새 세션 |
| ⚙ | 설정 |

## 관련 파일
| 파일 | 역할 |
|------|------|
| `src/main.js` | AI 프록시, 스트리밍, 히스토리(.history/), 캐시, 터미널(UTF-8) |
| `src/preload.js` | IPC 브릿지 |
| `renderer/js/ai-service.js` | LLM 호출, 캐시, Ghost Text, 시스템 프롬프트 |
| `renderer/js/ai-panel.js` | 채팅 UI, @ 자동완성, 자동 Diff, Help, 히스토리 |
| `renderer/js/editor-manager.js` | 메인 에디터 Diff, 백업, AI 우클릭 메뉴 |
