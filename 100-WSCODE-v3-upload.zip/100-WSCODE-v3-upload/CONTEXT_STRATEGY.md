# Local LLM 코딩 어시스턴트 — 문맥 유지 전략

> 환경: RTX 3060 12GB / qwen3.5:9b (Q4_K_M, 9.7B) / Ollama
> 최종 업데이트: 2026-04-05

---

## 1. 하드웨어 제약 요약

| 항목 | 값 |
|------|-----|
| GPU VRAM | 12,288 MiB |
| 모델 VRAM (idle) | ~6.5 GB |
| KV Cache 가용 VRAM | ~4.5 GB |
| 모델 스펙 max context | 262,144 (256K) |
| 실측 안정 max num_ctx | 32,768 (32K) — 응답 느림 |
| 실측 쾌적 num_ctx | **24,576 (24K)** — GPU 72% |
| 24K 기준 응답속도 | prompt 평가 ~2분, 생성 ~15 tok/s |

### 자동 측정 기능

Context Budget 모달의 **Measure** 버튼으로 쾌적 num_ctx를 자동 탐지할 수 있다.

```
[Measure 클릭] → 2K → 4K → 8K → 16K → 24K → 32K → 48K → 64K → ...
                 각 단계에서 num_ctx의 70%를 채운 프롬프트로 LLM 호출
                 ≤8s → Comfortable | 8~15s → Slow | >15s 또는 에러 → 중단
                 마지막 Comfortable = 쾌적 num_ctx → Budget에 자동 적용
```

구현: `ai-service.js` → `measureComfortableCtx(onProgress, opts)`

---

## 2. 토큰 예산 설계 (ContextBudget 클래스)

num_ctx를 한 번의 LLM 호출에서 아래 **고정 비율**로 분배한다.
num_ctx가 변경되면 `recalcFromCtx()`로 모든 슬롯이 자동 재계산된다.

```
┌─────────────────────────────────────────────────┐
│              총 예산: num_ctx 토큰               │
├─────────────────────────────────────────────────┤
│ ① 시스템 프롬프트          4%  (256 단위 정렬)   │
│ ② 프로젝트 컨텍스트       17%  (512 단위 정렬)   │
│ ③ 대화 히스토리           58%  (1024 단위 정렬)  │
│ ④ 현재 사용자 질의        13%  (512 단위 정렬)   │
│ ⑤ 응답 생성 여유          나머지 (min 512)       │
└─────────────────────────────────────────────────┘
```

### 프리셋별 자동 계산 결과

| 프리셋 | num_ctx | ① System | ② Project | ③ History | ④ Query | ⑤ Response | numPredict |
|--------|---------|----------|-----------|-----------|---------|------------|------------|
| RTX 3060 / 9B | **24,576** | 1,024 | 4,096 | 14,336 | 3,072 | 2,048 | 2,048 |
| 32K | 32,768 | 1,280 | 5,632 | 19,456 | 4,096 | 2,304 | 2,304 |
| 64K | 65,536 | 2,560 | 11,264 | 38,912 | 8,192 | 4,608 | 4,608 |
| 128K | 131,072 | 5,120 | 22,528 | 75,776 | 16,896 | 10,752 | 8,192 |
| Qwen3 80B | **235,520** | 9,472 | 39,936 | 136,192 | 30,720 | 19,200 | 8,192 |

### 구현 위치

| 구성요소 | 파일 | 위치 |
|----------|------|------|
| `BUDGET_RATIOS` 상수 | `ai-service.js` | 전역 |
| `CONTEXT_BUDGET_PRESETS` | `ai-service.js` | 전역 |
| `ContextBudget` 클래스 | `ai-service.js` | `recalcFromCtx()`, `toJSON()`, `loadFrom()` |
| Budget UI (모달) | `index.html` | `#context-budget-modal` |
| Budget 이벤트 | `app.js` | `btn-context-budget`, `btn-cb-measure`, `btn-cb-save` |
| Budget CSS | `styles.css` | `.cb-budget-bar`, `.cb-grid`, `.cb-seg-*` |
| 설정 영속화 | `settings.json` | `contextBudget` 키 |

---

## 3. 메시지 조립 (buildMessages)

LLM 호출 시 `buildMessages(systemPrompt, history)` 로 예산 내에서 메시지를 조립한다.

```
[시스템 프롬프트 + 프로젝트 컨텍스트] + [잘린 히스토리 마커] + [최근 대화] + [현재 질의]
          ① + ②                           ③-a                    ③-b            ④
```

### 조립 로직 (ai-service.js → buildMessages)

```javascript
buildMessages(systemPrompt, history) {
  // ① 시스템 프롬프트 (budget.system + budget.project 토큰 이내로 트림)
  messages.push({ role: 'system', content: sysContent });

  // ③ 히스토리 — 뒤에서부터 budget.history 토큰 내에서 채움
  for (let i = history.length - 1; i >= 0; i--) {
    if (historyTokens + turnTokens > maxHistoryTokens) break;
    included.unshift(history[i]);
  }

  // 잘린 턴이 있으면 마커 삽입
  if (included.length < history.length) {
    messages.push({ role: 'system', content: `[${droppedCount} earlier messages truncated]` });
  }

  messages.push(...included);
  return messages;
}
```

**핵심**: `history[]` 배열 원본은 건드리지 않고, LLM에 보낼 때만 예산 내로 잘라서 전송.

---

## 4. 히스토리 압축 (compressHistory)

대화가 길어지면 오래된 턴을 LLM 요약으로 대체한다.

### 트리거 조건

| 조건 | 기본값 | 설정 위치 |
|------|--------|-----------|
| 메시지 수 | `budget.compressAfterMsgs` (기본 8) | Context Budget 모달 |
| 토큰 초과 | `budget.history` 토큰 초과 시 | 자동 계산 |

### 동작

```
history[] = [msg1, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9, msg10]
                                                              ↓
compressHistory() 실행 (keepRecentMsgs=4):
  toCompress = [msg1 ~ msg6] → LLM 요약 → "[Previous conversation summary]\n..."
  toKeep = [msg7, msg8, msg9, msg10]
                                                              ↓
history[] = [{ role:'system', content:'[Previous conversation summary]...' }, msg7, msg8, msg9, msg10]
```

### 요약 → 세션 메타 자동 연동

압축 시 생성된 요약은 `aiPanel.sessionMeta.summary`에도 저장되어 `.history/` JSON의 `session.summary` 필드로 영속화된다.

구현: `ai-service.js` → `compressHistory()` (반환: `{ compressed, summary }`)

---

## 5. 토큰 추정

Ollama에는 토크나이저 API가 없으므로 보수적 근사치를 사용한다.

```javascript
estimateTokens(text) {
  return Math.ceil(text.length / 3) + 1;
  // 영어 ~1.3 char/tok, 한국어 ~2.5 char/tok, 코드 ~3 char/tok
  // 보수적으로 3 chars = 1 token (과대 추정 > 과소 추정)
}
```

---

## 6. 세션 영속화 (.history/ 확장)

`.history/` 디렉토리(워크스페이스별)에 세션 메타데이터를 포함하여 저장한다.

### 디렉토리 구조

```
project_root/
├── PROJECT.md              # 프로젝트 컨텍스트 (선택, 자동 로드)
└── .history/
    ├── chat_170000001_abc.json
    ├── chat_170000002_def.json
    └── ...
```

### 채팅 파일 형식

```json
{
  "id": "chat_1712345678_abc123",
  "title": "auth 미들웨어 리팩토링",
  "timestamp": 1712345678000,
  "messages": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ],
  "session": {
    "task": "auth 미들웨어 리팩토링",
    "summary": "JWT 검증 로직을 middleware에서 분리하여 별도 서비스로 추출 중...",
    "keyDecisions": [],
    "modifiedFiles": ["jwt.py", "service.py"],
    "pendingTasks": [],
    "budgetSnapshot": {
      "numCtx": 24576,
      "system": 1024,
      "project": 4096,
      "history": 14336,
      "query": 3072,
      "response": 2048,
      "numPredict": 2048,
      "temperature": 0.3,
      "repeatPenalty": 1.1,
      "compressAfterMsgs": 8,
      "keepRecentMsgs": 4
    }
  }
}
```

### 세션 메타 자동 추출 (updateSessionMeta)

| 필드 | 추출 소스 |
|------|-----------|
| `task` | 첫 번째 user 메시지 (100자) |
| `summary` | compressHistory 요약 또는 마지막 assistant 응답 (300자) |
| `modifiedFiles` | `@file`로 추가된 파일명 자동 수집 |
| `budgetSnapshot` | 저장 시점의 `budget.toJSON()` |

### 세션 복원 시 (loadChatById)

```
1. messages → history[] 복원
2. session.budgetSnapshot → budget.loadFrom() 적용
3. session.summary → (history 비어있으면) 히스토리 앞에 삽입
4. session 배너 표시 (task, files, decisions, budget 요약)
```

구현:
- 저장: `ai-panel.js` → `saveCurrentChat()`, `updateSessionMeta()`
- 복원: `ai-panel.js` → `loadChatById()`, `showSessionBanner()`

---

## 7. PROJECT.md 자동 로드

폴더를 열 때 아래 경로 중 하나가 존재하면 자동으로 `projectContext.summary`에 로드한다.

1. `rootPath/PROJECT.md`
2. `rootPath/.assistant/PROJECT.md`

```markdown
# PROJECT.md 작성 가이드

## 프로젝트 개요
- 이름, 목적, 기술 스택 한 줄 요약

## 아키텍처
- 핵심 모듈 간 관계 (3~5줄)

## 현재 작업
- 진행 중인 태스크와 이유

## 규칙
- 코딩 컨벤션, 금지 패턴
```

**원칙**: 코드만으로는 알 수 없는 **왜(why)와 결정(decision)**만 기록한다.

구현: `file-tree.js` → `loadProjectMd(folderPath)`

---

## 8. 프로젝트 격리

**절대로 다른 프로젝트의 데이터가 혼입되지 않도록** 다음 5개 경계에서 격리한다.

### 프로젝트 전환 시 (openFolder)

| 항목 | 처리 | 구현 위치 |
|------|------|-----------|
| `history[]` | `clearHistory()` | `file-tree.js:openFolder()` |
| `projectContext` | `null` 초기화 | 〃 |
| `contexts[]` (채팅 칩) | 빈 배열 + UI 리셋 | 〃 |
| `sessionMeta` | 모든 필드 초기화 | 〃 |
| 채팅 UI | 웰컴 화면 복원 | 〃 |

### 캐시 프로젝트 스코핑

| 캐시 | 격리 방식 | 구현 |
|------|-----------|------|
| **LLM 캐시** | 키에 `rootPath` 포함 | `ai-service.js:generateCacheKey()` |
| **Semantic 캐시** | `semantic/<rootPath-hash>/` 서브디렉토리 | `main.js:semantic-cache-get/set` |
| **RAG 캐시** | 키 = `MD5(rootPath)` | `main.js:rag-cache-get/set` (기존) |
| **.history/** | `rootPath/.history/` 하위 | `main.js:save/load/list/delete-chat` (기존) |

### 격리 다이어그램

```
프로젝트 A (C:\projects\foo)          프로젝트 B (C:\projects\bar)
┌────────────────────────┐            ┌────────────────────────┐
│ RAM                    │            │ RAM                    │
│  history[]     ← 격리  │  전환 시   │  history[]     ← 초기화│
│  projectContext← 격리  │ ═══════>  │  projectContext← 새로드 │
│  sessionMeta  ← 격리  │  전부클리어 │  sessionMeta  ← 리셋  │
├────────────────────────┤            ├────────────────────────┤
│ 파일 캐시              │            │ 파일 캐시              │
│  llm/llm_<A-hash>     │            │  llm/llm_<B-hash>     │
│  rag/<A-md5>.json      │            │  rag/<B-md5>.json      │
│  semantic/<A-md5>/     │            │  semantic/<B-md5>/     │
├────────────────────────┤            ├────────────────────────┤
│ 히스토리               │            │ 히스토리               │
│  foo/.history/*.json   │            │  bar/.history/*.json   │
└────────────────────────┘            └────────────────────────┘
```

---

## 9. 캐시 시스템

### 3계층 캐시

| 캐시 | TTL | 매칭 | 저장 위치 | 스코프 |
|------|-----|------|-----------|--------|
| **LLM** | 24h | `rootPath + model + 최근 3메시지` 해시 | `userData/ai-cache/llm/` | 프로젝트별 |
| **RAG** | 5min | `MD5(rootPath)` | `userData/ai-cache/rag/` | 프로젝트별 |
| **Semantic** | 48h | Bigram Dice 유사도 ≥ 0.85 | `userData/ai-cache/semantic/<hash>/` | 프로젝트별 |

### 자동 정리 (purgeExpiredCache)

- **앱 시작 5초 후** 자동 실행
- `cache-purge` IPC로 수동 실행 가능
- 만료 파일 삭제, 빈 디렉토리 삭제, 손상 파일 삭제
- 프로젝트별 서브디렉토리 재귀 순회

구현: `main.js` → `purgeExpiredCache()`, `purgeDir()`

---

## 10. Ollama 호출 파라미터

API 호출 시 ContextBudget의 값이 자동으로 body에 포함된다.

```javascript
// callLLM() 및 sendMessageStream()에서 자동 적용
body = {
  model: 'qwen3.5:9b',
  messages: [...],
  temperature: budget.temperature,      // 기본 0.3
  max_tokens: budget.numPredict,         // 기본 2048
  options: {                             // Ollama 전용 (:8080 또는 :11434)
    num_ctx: budget.numCtx,              // 기본 24576
    num_predict: budget.numPredict,      // 기본 2048
    repeat_penalty: budget.repeatPenalty, // 기본 1.1
  },
};
```

Ollama 전용 `options`는 API URL에 `:8080` 또는 `:11434` 포함 시에만 추가된다.

---

## 11. 성능 최적화

### 응답 속도 개선

| 방법 | 효과 | 구현 상태 |
|------|------|-----------|
| `num_predict` 제한 | 불필요한 긴 응답 방지 | `budget.numPredict` (기본 2048, max 8192) |
| `stream: true` | 첫 토큰까지 대기시간 감소 | `sendMessageStream()` |
| 프롬프트 내 코드 최소화 | 토큰 절약 | `buildMessages()` 예산 트림 |

### 토큰 절약 기법

| 방법 | 절약량 | 구현 상태 |
|------|--------|-----------|
| buildMessages 슬라이딩 윈도우 | 예산 초과분 자동 절단 | `buildMessages()` |
| 대화 요약 압축 | 60~70% | `compressHistory()` |
| 시스템 프롬프트 예산 트림 | system+project 초과 시 자동 절단 | `buildMessages()` |
| Semantic 캐시 (유사 질문 재사용) | LLM 호출 0회 | `semanticCacheGet()` |

---

## 12. 전체 흐름 다이어그램

```
폴더 열기
    │
    ▼
┌─────────────────┐
│ 프로젝트 격리    │ ← history, context, sessionMeta 전부 클리어
│ PROJECT.md 로드  │ ← rootPath/PROJECT.md 자동 탐지
│ 캐시 만료 정리   │ ← purgeExpiredCache() (앱 시작 시)
└────────┬────────┘
         │
         ▼
사용자 입력
    │
    ├── @workspace → analyzeProject() → RAG 캐시
    ├── @file → 파일 내용 → contexts[]
    └── @selection → 선택 코드 → contexts[]
    │
    ▼
┌─────────────────┐     ┌──────────────────┐
│ Semantic 캐시    │──Y──▶│ 캐시 히트 → 즉시 │
│ (프로젝트별)     │     │ 응답 반환        │
└────────┬────────┘     └──────────────────┘
         │N
         ▼
┌─────────────────┐     ┌──────────────────┐
│ compressHistory │──Y──▶│ 오래된 턴 → LLM  │
│ 트리거?          │     │ 요약으로 대체     │
│ (8+개 & 토큰초과)│     │ → sessionMeta    │
└────────┬────────┘     └──────────────────┘
         │
         ▼
┌───────────────────────────────────────────┐
│ buildMessages() — 예산 내 메시지 조립      │
│ [시스템+프로젝트] [잘린마커] [최근대화] [질의]│
│   ① + ②            ③-a       ③-b      ④  │
└─────────────────────┬─────────────────────┘
                      │
                      ▼
┌─────────────────────────┐
│ Ollama API 스트리밍 호출  │
│ num_ctx / num_predict    │
│ / repeat_penalty 자동 적용│
└────────────┬────────────┘
             │
             ▼
┌─────────────────┐
│ 응답 표시        │
│ 토큰 사용량 표시  │ ← "~500 tok | hist 8,200/14,336"
│ 자동 Diff        │
│ 세션 저장        │ ← .history/ + session 메타
│ Semantic 캐시 저장│ ← 프로젝트별 서브디렉토리
└─────────────────┘
```

---

## 13. 핵심 수치 요약 (24K 기본값 기준)

| 항목 | 값 | 근거 |
|------|-----|------|
| num_ctx | 24,576 | 실측 쾌적 + GPU 72% (Measure로 자동 탐지 가능) |
| num_predict | 2,048 | 코딩 응답 충분 + 속도 |
| temperature | 0.3 | 코딩 작업 낮은 temperature |
| repeat_penalty | 1.1 | 반복 방지 |
| 대화 히스토리 예산 | 14,336 (58%) | 문맥 유지 최대화 |
| 프로젝트 컨텍스트 | 4,096 (17%) | PROJECT.md 1페이지 분량 |
| 압축 트리거 | 8+ 메시지 & 히스토리 예산 초과 | Context Budget 모달에서 조정 가능 |
| 최근 유지 메시지 | 4개 | 압축 시 보존할 최근 턴 수 |
| 토큰 추정 | `len / 3` | 보수적 (과대 추정 > 과소 추정) |
| 세션 복원 비용 | ~3,000 토큰 | 24K 중 12% |
| Semantic 캐시 매칭 | Dice ≥ 0.85 | 프로젝트별 격리 |
| 캐시 자동 정리 | 앱 시작 시 | LLM 24h / RAG 5m / Semantic 48h |

---

## 14. UI 접근 경로

| 기능 | 접근 방법 |
|------|-----------|
| Context Budget 설정 | AI 패널 헤더 → 시계 아이콘 |
| 프리셋 선택 | 모달 → Preset 드롭다운 (24K~235K) |
| num_ctx 자동 측정 | 모달 → **Measure** 버튼 |
| 개별 슬롯 수동 조정 | 모달 → 각 필드 직접 수정 → Custom 모드 |
| Ollama 파라미터 | 모달 → num_predict, temperature, repeat_penalty |
| 압축 설정 | 모달 → Compress after / Keep recent |
| 적용 | 모달 → **Apply Budget** → settings.json에 영속화 |
