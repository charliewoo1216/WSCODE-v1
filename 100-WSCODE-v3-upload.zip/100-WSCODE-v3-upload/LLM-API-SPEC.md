# WSCODE LLM API 호출 규격 (curl)

> 기준일: 2026-04-05
> 엔드포인트: OpenAI-compatible API (Ollama `/v1/chat/completions`)
> 기본 URL: `http://192.168.0.8:8080`

---

## 1. 채팅 (Streaming) — 메인 호출

사용자 메시지 전송 시 사용. `sendMessageStream()` 경로.

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "system",
        "content": "당신은 WSCODE 에디터에 내장된 AI 코딩 어시스턴트입니다.\n...(시스템 프롬프트 + 프로젝트 컨텍스트)..."
      },
      {
        "role": "system",
        "content": "[3 earlier messages truncated to fit context budget]"
      },
      {
        "role": "user",
        "content": "이전 사용자 메시지"
      },
      {
        "role": "assistant",
        "content": "이전 AI 응답"
      },
      {
        "role": "user",
        "content": "현재 사용자 질문"
      }
    ],
    "stream": true,
    "temperature": 0.3,
    "options": {
      "num_ctx": 24576,
      "num_predict": 2048,
      "repeat_penalty": 1.1
    }
  }'
```

### 응답 (SSE stream)

```
data: {"choices":[{"delta":{"content":"안"},"index":0}]}
data: {"choices":[{"delta":{"content":"녕"},"index":0}]}
data: {"choices":[{"delta":{"content":"하세요"},"index":0}]}
data: [DONE]
```

### messages 조립 규칙 (buildMessages)

```
① system prompt + project context   → budget.system + budget.project 토큰 이내 (초과 시 트림)
② [N earlier messages truncated]    → 히스토리가 잘렸을 때만 삽입
③ 최근 대화 턴들                     → budget.history 토큰 이내 (뒤에서부터 채움)
④ 현재 사용자 질의                   → ③에 포함
```

---

## 2. 채팅 (Non-streaming)

내부 유틸리티 및 `sendMessage()` 경로. 동일한 budget 적용.

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "system",
        "content": "시스템 프롬프트..."
      },
      {
        "role": "user",
        "content": "사용자 메시지"
      }
    ],
    "temperature": 0.3,
    "max_tokens": 2048,
    "options": {
      "num_ctx": 24576,
      "num_predict": 2048,
      "repeat_penalty": 1.1
    }
  }'
```

### 응답

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "AI 응답 텍스트"
      }
    }
  ],
  "usage": {
    "prompt_tokens": 1234,
    "completion_tokens": 567,
    "total_tokens": 1801
  }
}
```

---

## 3. Ghost Text (Inline Completion)

코드 작성 중 자동완성 제안. `getInlineCompletion()` 경로.

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "user",
        "content": "You are a code completion AI. Complete the code at the cursor position. Only output the completion text, nothing else. No explanations, no markdown, no code fences.\n\nFile: app.js (javascript)\n\nCode before cursor:\nfunction calculateTotal(items) {\n  return items.reduce((sum, item) => sum +\n\nCode after cursor:\n  , 0);\n}\n\nComplete from the cursor position:"
      }
    ],
    "temperature": 0.2,
    "max_tokens": 100,
    "options": {
      "num_ctx": 24576,
      "num_predict": 100,
      "repeat_penalty": 1.1
    }
  }'
```

### 특이사항

- `temperature: 0.2` (메인 채팅 0.3보다 낮음 — 정확도 우선)
- `max_tokens: 100` (짧은 완성만 필요)
- 응답에서 ` ```lang ` 코드펜스 자동 제거 후 반환

---

## 4. 히스토리 압축 (요약 생성)

대화가 길어질 때 오래된 턴을 요약. `compressHistory()` 경로.

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "user",
        "content": "Summarize the following conversation concisely. Keep key decisions, code context, and important details. Output only the summary:\n\nuser: auth 미들웨어를 분리해줘\n\nassistant: AuthService 클래스로 이동했습니다...\n\nuser: refresh token에 race condition이 있어\n\nassistant: DB 락을 적용하는 방안을 제안합니다..."
      }
    ],
    "temperature": 0.3,
    "max_tokens": 500,
    "options": {
      "num_ctx": 24576,
      "num_predict": 500,
      "repeat_penalty": 1.1
    }
  }'
```

### 특이사항

- `max_tokens: 500` (요약은 간결해야 함)
- 각 턴의 content를 500자로 잘라서 전달
- 결과는 `[Previous conversation summary]\n{요약}` 형태로 히스토리에 삽입

---

## 5. 프로젝트 청크 분석 (대형 프로젝트)

30+ 파일 프로젝트를 15개씩 청크로 나눠 요약. `analyzeProjectChunked()` 경로.

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "user",
        "content": "Summarize the purpose and key exports of these files concisely:\n\n### src/auth/service.py\n```\nclass AuthService:\n    def verify_token(self, token)...\n```\n\n### src/middleware/jwt.py\n```\ndef jwt_middleware(request)...\n```"
      }
    ],
    "temperature": 0.3,
    "max_tokens": 500,
    "options": {
      "num_ctx": 24576,
      "num_predict": 500,
      "repeat_penalty": 1.1
    }
  }'
```

### 특이사항

- 각 파일 content를 1500자로 잘라서 전달
- 청크당 최대 15개 파일
- `max_tokens: 500` (요약만 필요)

---

## 6. Measure (쾌적 num_ctx 벤치마크)

num_ctx를 점진적으로 늘려가며 응답 시간 측정. `measureComfortableCtx()` 경로.

첫 호출에서 **엔드포인트 자동 감지**: Ollama 네이티브 → OpenAI 호환 순으로 시도.

### 6-A. Ollama 네이티브 (우선 시도)

```bash
curl -X POST http://192.168.0.8:8080/api/chat \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  --max-time 20 \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "user",
        "content": "Respond with only \"OK\". Ignore the padding below.\n\n...(패딩)..."
      }
    ],
    "stream": false,
    "options": {
      "num_ctx": 24576,
      "num_predict": 8,
      "temperature": 0
    }
  }'
```

**응답** (Ollama native):
```json
{
  "message": { "role": "assistant", "content": "OK" },
  "eval_count": 2,
  "eval_duration": 150000000,
  "prompt_eval_count": 4800,
  "prompt_eval_duration": 3200000000
}
```

### 6-B. OpenAI 호환 (폴백)

네이티브 실패 시 `options` 없이 OpenAI 호환으로 전환:

```bash
curl -X POST http://192.168.0.8:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk_123!" \
  --max-time 20 \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {
        "role": "user",
        "content": "Respond with only \"OK\". Ignore the padding below.\n\n...(패딩)..."
      }
    ],
    "temperature": 0,
    "max_tokens": 8
  }'
```

> **참고**: OpenAI 호환 폴백에서는 `num_ctx`를 제어할 수 없으므로 서버 기본값 사용.
> 이 경우 Measure는 "서버 기본 컨텍스트에서의 응답 시간"만 측정.

### 테스트 시퀀스

```
2K → 4K → 8K → 16K → 24K → 32K → 48K → 64K → 96K → 128K → 196K → 262K
```

### 판정 기준

| 응답 시간 | 판정 |
|-----------|------|
| ≤ 8초 | **Comfortable** |
| 8~15초 | **Slow** |
| > 15초 | **Timeout** (중단) |
| API 에러 | **Error** (OOM 등, 즉시 중단) |

### 특이사항

- `temperature: 0` (벤치마크 — 일관된 결과)
- `max_tokens: 8` / `num_predict: 8` (응답은 "OK"만 필요, 생성 시간 최소화)
- HTTP 타임아웃: `maxTimeMs + 5000` (기본 20초)
- 패딩 = `num_ctx * 0.7 * 3` 글자 (토큰 추정 역산)

---

## 7. 모델 목록 조회

사용 가능한 모델 목록 가져오기. `fetchModels()` 경로.

```bash
curl -X GET http://192.168.0.8:8080/v1/models \
  -H "Authorization: Bearer sk_123!"
```

### 응답

```json
{
  "data": [
    { "id": "qwen3.5:9b" },
    { "id": "qwen3:80b" },
    { "id": "codellama:13b" }
  ]
}
```

---

## 8. 파라미터 요약

### 공통 헤더

```
Content-Type: application/json
Authorization: Bearer {apiKey}
```

### 호출별 파라미터 비교

| 호출 | temperature | max_tokens | num_ctx | num_predict | stream | timeout |
|------|:-----------:|:----------:|:-------:|:-----------:|:------:|:-------:|
| 채팅 (streaming) | **0.3** | - | **24576** | **2048** | `true` | 없음 (스트리밍) |
| 채팅 (non-streaming) | **0.3** | **2048** | **24576** | **2048** | `false` | 15s |
| Ghost Text | **0.2** | **100** | **24576** | **100** | `false` | 15s |
| 히스토리 압축 | **0.3** | **500** | **24576** | **500** | `false` | 15s |
| 청크 분석 | **0.3** | **500** | **24576** | **500** | `false` | 15s |
| Measure | **0** | **8** | **가변** | **8** | `false` | 20s |
| 모델 목록 | - | - | - | - | - | 15s |

### Ollama `options` 필드 (`:8080` 또는 `:11434` URL에서만)

```json
{
  "num_ctx": 24576,
  "num_predict": 2048,
  "repeat_penalty": 1.1
}
```

### Context Budget 프리셋별 값

| 프리셋 | num_ctx | num_predict | history budget |
|--------|---------|-------------|----------------|
| RTX 3060 / 9B | 24,576 | 2,048 | 14,336 |
| 32K | 32,768 | 2,304 | 19,456 |
| 64K | 65,536 | 4,608 | 38,912 |
| 128K | 131,072 | 8,192 | 75,776 |
| Qwen3 80B (235K) | 235,520 | 8,192 | 136,192 |

> num_predict 상한: 8,192 (큰 컨텍스트에서도 응답 길이는 제한)
