const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    backgroundColor: '#1e1e1e',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

// ─── Window Controls ───
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => mainWindow?.close());

// ─── File System ───
ipcMain.handle('open-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('open-file-dialog', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'] });
  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('read-file', async (_, filePath) => {
  try {
    return await fs.promises.readFile(filePath, 'utf-8');
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('write-file', async (_, filePath, content) => {
  try {
    await fs.promises.writeFile(filePath, content, 'utf-8');
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('read-dir', async (_, dirPath) => {
  try {
    return await readDirRecursive(dirPath, dirPath, 0);
  } catch (e) {
    return { error: e.message };
  }
});

const IGNORE_DIRS = new Set([
  'node_modules', '.git', 'dist', 'build', '.next', '__pycache__',
  '.vscode', '.idea', 'coverage', '.cache', '.turbo', 'out',
]);

async function readDirRecursive(basePath, dirPath, depth) {
  if (depth > 6) return [];
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });
  const items = [];

  // sort: folders first, then files, alphabetical
  const sorted = entries.sort((a, b) => {
    if (a.isDirectory() && !b.isDirectory()) return -1;
    if (!a.isDirectory() && b.isDirectory()) return 1;
    return a.name.localeCompare(b.name);
  });

  for (const entry of sorted) {
    if (entry.name.startsWith('.') && entry.isDirectory()) continue;
    if (IGNORE_DIRS.has(entry.name) && entry.isDirectory()) continue;

    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.relative(basePath, fullPath);

    if (entry.isDirectory()) {
      const children = await readDirRecursive(basePath, fullPath, depth + 1);
      items.push({ name: entry.name, path: fullPath, relativePath, type: 'dir', children });
    } else {
      items.push({ name: entry.name, path: fullPath, relativePath, type: 'file' });
    }
  }
  return items;
}

ipcMain.handle('save-file-dialog', async (_, defaultPath) => {
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath });
  if (result.canceled) return null;
  return result.filePath;
});

// ─── Project Analysis (for AI context) ───
ipcMain.handle('scan-project-files', async (_, rootPath) => {
  try {
    return await collectProjectFiles(rootPath, rootPath, 0);
  } catch (e) {
    return { error: e.message };
  }
});

const TEXT_EXTENSIONS = new Set([
  '.js', '.ts', '.jsx', '.tsx', '.py', '.java', '.c', '.cpp', '.h',
  '.html', '.css', '.scss', '.less', '.json', '.xml', '.yaml', '.yml',
  '.md', '.txt', '.sh', '.bat', '.ps1', '.sql', '.go', '.rs', '.rb',
  '.php', '.swift', '.kt', '.dart', '.vue', '.svelte', '.toml', '.ini',
  '.env', '.gitignore', '.editorconfig',
]);

async function collectProjectFiles(basePath, dirPath, depth) {
  if (depth > 5) return [];
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    if (IGNORE_DIRS.has(entry.name) && entry.isDirectory()) continue;
    if (entry.name.startsWith('.') && entry.isDirectory()) continue;

    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.relative(basePath, fullPath);

    if (entry.isDirectory()) {
      const subFiles = await collectProjectFiles(basePath, fullPath, depth + 1);
      files.push(...subFiles);
    } else {
      const ext = path.extname(entry.name).toLowerCase();
      if (TEXT_EXTENSIONS.has(ext)) {
        try {
          const stat = await fs.promises.stat(fullPath);
          if (stat.size < 100000) { // < 100KB
            const content = await fs.promises.readFile(fullPath, 'utf-8');
            files.push({ path: relativePath, content, size: stat.size });
          } else {
            files.push({ path: relativePath, content: '[File too large]', size: stat.size });
          }
        } catch { /* skip unreadable */ }
      }
    }
  }
  return files;
}

// ─── AI API Proxy ───
ipcMain.handle('ai-request', async (_, { provider, url, headers, body, timeout }) => {
  return new Promise((resolve) => {
    try {
      const isHttps = url.startsWith('https');
      const lib = isHttps ? https : http;
      const parsed = new URL(url);
      const reqTimeout = timeout || 15000;

      const req = lib.request({
        hostname: parsed.hostname,
        port: parsed.port,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...headers },
        timeout: reqTimeout,
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          // Try normal JSON first
          try { resolve(JSON.parse(data)); return; } catch {}

          // Server may return SSE stream even for non-stream requests — reassemble
          if (data.includes('data: ')) {
            try {
              let content = '';
              let model = '';
              let usage = null;
              for (const line of data.split('\n')) {
                if (!line.startsWith('data: ')) continue;
                const payload = line.slice(6).trim();
                if (payload === '[DONE]') continue;
                const chunk = JSON.parse(payload);
                if (chunk.model) model = chunk.model;
                if (chunk.usage) usage = chunk.usage;
                const delta = chunk.choices?.[0]?.delta?.content || '';
                content += delta;
              }
              resolve({
                choices: [{ message: { role: 'assistant', content } }],
                model,
                usage,
              });
              return;
            } catch {}
          }

          const preview = (data || '').substring(0, 200);
          resolve({ error: { message: `Invalid JSON (HTTP ${res.statusCode}): ${preview}` } });
        });
      });

      req.on('error', (e) => resolve({ error: { message: `Connection error: ${e.message}` } }));
      req.on('timeout', () => { req.destroy(); resolve({ error: { message: `Request timeout (${reqTimeout}ms)` } }); });
      req.write(JSON.stringify(body));
      req.end();
    } catch (e) {
      resolve({ error: { message: e.message } });
    }
  });
});

// Streaming AI request
let activeStreamReq = null;

ipcMain.on('ai-stream-request', (event, { provider, url, headers, body }) => {
  const isHttps = url.startsWith('https');
  const lib = isHttps ? https : http;
  const parsed = new URL(url);

  const req = lib.request({
    hostname: parsed.hostname,
    port: parsed.port,
    path: parsed.pathname + parsed.search,
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
  }, (res) => {
    res.on('data', (chunk) => {
      event.sender.send('ai-stream-chunk', chunk.toString());
    });
    res.on('end', () => {
      activeStreamReq = null;
      event.sender.send('ai-stream-end');
    });
  });

  activeStreamReq = req;

  req.on('error', (e) => {
    activeStreamReq = null;
    event.sender.send('ai-stream-error', e.message);
  });

  req.write(JSON.stringify(body));
  req.end();
});

ipcMain.on('ai-stream-abort', () => {
  if (activeStreamReq) {
    activeStreamReq.destroy();
    activeStreamReq = null;
  }
});

// Fetch models
ipcMain.handle('ai-fetch-models', async (_, { provider, url, headers }) => {
  return new Promise((resolve) => {
    try {
      const isHttps = url.startsWith('https');
      const lib = isHttps ? https : http;
      const parsed = new URL(url);

      const req = lib.request({
        hostname: parsed.hostname,
        port: parsed.port,
        path: parsed.pathname + parsed.search,
        method: 'GET',
        headers: headers || {},
        timeout: 15000,
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try { resolve(JSON.parse(data)); }
          catch { resolve({ error: { message: 'Invalid JSON response' } }); }
        });
      });

      req.on('error', (e) => resolve({ error: { message: e.message } }));
      req.on('timeout', () => { req.destroy(); resolve({ error: { message: 'Request timeout' } }); });
      req.end();
    } catch (e) {
      resolve({ error: { message: e.message } });
    }
  });
});

// ─── Search in Files ───
ipcMain.handle('search-in-files', async (_, rootPath, query, options) => {
  try {
    const results = [];
    const opts = options || {};
    await searchFilesRecursive(rootPath, rootPath, query, results, 0, opts);
    return results;
  } catch (e) {
    return { error: e.message };
  }
});

async function searchFilesRecursive(basePath, dirPath, query, results, depth, opts) {
  if (depth > 8) return;
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    if (IGNORE_DIRS.has(entry.name) && entry.isDirectory()) continue;
    if (entry.name.startsWith('.') && entry.isDirectory()) continue;

    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory()) {
      await searchFilesRecursive(basePath, fullPath, query, results, depth + 1, opts);
    } else {
      const ext = path.extname(entry.name).toLowerCase();
      if (!TEXT_EXTENSIONS.has(ext)) continue;
      try {
        const stat = await fs.promises.stat(fullPath);
        if (stat.size > 500000) continue; // skip files > 500KB
        const content = await fs.promises.readFile(fullPath, 'utf-8');
        const lines = content.split('\n');
        for (let i = 0; i < lines.length; i++) {
          let isMatch = false;
          if (opts.regex) {
            try {
              const flags = opts.caseSensitive ? 'g' : 'gi';
              const re = new RegExp(query, flags);
              isMatch = re.test(lines[i]);
            } catch { isMatch = false; }
          } else {
            isMatch = opts.caseSensitive
              ? lines[i].includes(query)
              : lines[i].toLowerCase().includes(query.toLowerCase());
          }
          if (isMatch) {
            results.push({
              filePath: fullPath,
              relativePath: path.relative(basePath, fullPath),
              lineNumber: i + 1,
              lineContent: lines[i].trimEnd(),
            });
          }
        }
      } catch { /* skip unreadable files */ }
    }
  }
}

// ─── File Operations ───
ipcMain.handle('create-file', async (_, filePath, content) => {
  try {
    await fs.promises.writeFile(filePath, content || '', 'utf-8');
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('create-folder', async (_, folderPath) => {
  try {
    await fs.promises.mkdir(folderPath, { recursive: true });
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('rename-path', async (_, oldPath, newPath) => {
  try {
    await fs.promises.rename(oldPath, newPath);
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('delete-path', async (_, filePath) => {
  try {
    if (shell.trashItem) {
      await shell.trashItem(filePath);
    } else {
      const stat = await fs.promises.stat(filePath);
      if (stat.isDirectory()) {
        await fs.promises.rm(filePath, { recursive: true });
      } else {
        await fs.promises.unlink(filePath);
      }
    }
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('path-exists', async (_, filePath) => {
  try {
    await fs.promises.access(filePath);
    return true;
  } catch {
    return false;
  }
});

// ─── List All Files (Quick Open) ───
ipcMain.handle('list-all-files', async (_, rootPath) => {
  try {
    const files = [];
    await listAllFilesRecursive(rootPath, rootPath, files, 0);
    return files;
  } catch (e) {
    return { error: e.message };
  }
});

async function listAllFilesRecursive(basePath, dirPath, files, depth) {
  if (depth > 8) return;
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    if (IGNORE_DIRS.has(entry.name) && entry.isDirectory()) continue;
    if (entry.name.startsWith('.') && entry.isDirectory()) continue;

    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory()) {
      await listAllFilesRecursive(basePath, fullPath, files, depth + 1);
    } else {
      files.push({
        name: entry.name,
        path: fullPath,
        relativePath: path.relative(basePath, fullPath),
      });
    }
  }
}

// ─── File Watching ───
let watcher = null;

ipcMain.handle('watch-folder', async (_, folderPath) => {
  if (watcher) watcher.close();
  try {
    watcher = fs.watch(folderPath, { recursive: true }, (eventType, filename) => {
      if (!filename) return;
      // Ignore common non-essential changes
      if (filename.includes('node_modules') || filename.includes('.git')) return;
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('file-changed', { eventType, filename, folderPath });
      }
    });
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('unwatch-folder', async () => {
  if (watcher) { watcher.close(); watcher = null; }
  return { success: true };
});

// ─── Chat History (workspace/.history/) ───
function getChatDir(rootPath) {
  return path.join(rootPath, '.history');
}

ipcMain.handle('save-chat', async (_, rootPath, chatId, data) => {
  try {
    const dir = getChatDir(rootPath);
    await fs.promises.mkdir(dir, { recursive: true });
    await fs.promises.writeFile(
      path.join(dir, `${chatId}.json`),
      JSON.stringify(data, null, 2), 'utf-8'
    );
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('load-chat', async (_, rootPath, chatId) => {
  try {
    const data = await fs.promises.readFile(
      path.join(getChatDir(rootPath), `${chatId}.json`), 'utf-8'
    );
    return JSON.parse(data);
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('list-chats', async (_, rootPath) => {
  try {
    const dir = getChatDir(rootPath);
    await fs.promises.mkdir(dir, { recursive: true });
    const files = await fs.promises.readdir(dir);
    const chats = [];
    for (const file of files) {
      if (!file.endsWith('.json')) continue;
      try {
        const data = await fs.promises.readFile(path.join(dir, file), 'utf-8');
        const chat = JSON.parse(data);
        chats.push({ id: chat.id, title: chat.title, timestamp: chat.timestamp });
      } catch { /* skip corrupt files */ }
    }
    return chats.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('delete-chat', async (_, rootPath, chatId) => {
  try {
    await fs.promises.unlink(path.join(getChatDir(rootPath), `${chatId}.json`));
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

// ─── Terminal (node-pty) ───
let pty;
try {
  pty = require('node-pty');
} catch {
  // Fallback to child_process if node-pty not available
  pty = null;
}
const { spawn: cpSpawn } = require('child_process');
const terminals = new Map();
let terminalIdCounter = 0;

ipcMain.handle('terminal-create', async (_, options) => {
  const id = ++terminalIdCounter;
  const cwd = options?.cwd || process.env.HOME || process.env.USERPROFILE || '.';
  const isWin = process.platform === 'win32';
  const shellCmd = isWin ? 'powershell.exe' : process.env.SHELL || '/bin/bash';

  if (pty) {
    // node-pty: full PTY support (Tab completion, arrow keys, colors)
    const proc = pty.spawn(shellCmd, [], {
      name: 'xterm-256color',
      cols: 80,
      rows: 24,
      cwd,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8', LANG: 'ko_KR.UTF-8' },
    });

    terminals.set(id, { proc, type: 'pty' });

    proc.onData((data) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('terminal-data', { id, data });
      }
    });

    proc.onExit(({ exitCode }) => {
      terminals.delete(id);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('terminal-exit', { id, code: exitCode });
      }
    });
  } else {
    // Fallback: child_process (no Tab completion)
    const shellArgs = isWin ? ['-NoLogo', '-NoProfile', '-Command',
      'chcp 65001 > $null; $OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8; powershell -NoLogo'] : [];

    const proc = cpSpawn(shellCmd, shellArgs, {
      cwd,
      env: { ...process.env, TERM: 'xterm-256color', PYTHONIOENCODING: 'utf-8', LANG: 'ko_KR.UTF-8' },
      shell: false,
    });

    terminals.set(id, { proc, type: 'spawn' });

    proc.stdout.on('data', (data) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('terminal-data', { id, data: data.toString('utf-8') });
      }
    });

    proc.stderr.on('data', (data) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('terminal-data', { id, data: data.toString('utf-8') });
      }
    });

    proc.on('exit', (code) => {
      terminals.delete(id);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('terminal-exit', { id, code });
      }
    });
  }

  return { id };
});

ipcMain.on('terminal-write', (_, { id, data }) => {
  const t = terminals.get(id);
  if (!t) return;
  if (t.type === 'pty') {
    t.proc.write(data);
  } else if (t.proc.stdin?.writable) {
    t.proc.stdin.write(data);
  }
});

ipcMain.handle('terminal-resize', async (_, { id, cols, rows }) => {
  const t = terminals.get(id);
  if (t && t.type === 'pty') {
    try { t.proc.resize(cols, rows); } catch {}
  }
  return { success: true };
});

ipcMain.handle('terminal-kill', async (_, id) => {
  const t = terminals.get(id);
  if (t) {
    t.proc.kill();
    terminals.delete(id);
  }
  return { success: true };
});

// Clean up terminals on app quit
app.on('before-quit', () => {
  for (const [id, proc] of terminals) {
    try { proc.kill(); } catch {}
  }
  terminals.clear();
});

// ─── AI Cache System ───
const cacheDir = path.join(app.getPath('userData'), 'ai-cache');
const crypto = require('crypto');

function cacheHash(str) {
  return crypto.createHash('md5').update(str).digest('hex');
}

// LLM Cache - exact match on model + messages
ipcMain.handle('cache-get', async (_, key) => {
  try {
    const filePath = path.join(cacheDir, 'llm', `${key}.json`);
    const data = await fs.promises.readFile(filePath, 'utf-8');
    const cached = JSON.parse(data);
    // Check TTL (24 hours)
    if (Date.now() - cached.timestamp > 86400000) {
      await fs.promises.unlink(filePath).catch(() => {});
      return null;
    }
    return cached.value;
  } catch {
    return null;
  }
});

ipcMain.handle('cache-set', async (_, key, value) => {
  try {
    const dir = path.join(cacheDir, 'llm');
    await fs.promises.mkdir(dir, { recursive: true });
    await fs.promises.writeFile(
      path.join(dir, `${key}.json`),
      JSON.stringify({ timestamp: Date.now(), value }), 'utf-8'
    );
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

// RAG Cache - project file index with mtime
ipcMain.handle('rag-cache-get', async (_, rootPath) => {
  try {
    const key = cacheHash(rootPath);
    const filePath = path.join(cacheDir, 'rag', `${key}.json`);
    const data = await fs.promises.readFile(filePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return null;
  }
});

ipcMain.handle('rag-cache-set', async (_, rootPath, indexData) => {
  try {
    const dir = path.join(cacheDir, 'rag');
    await fs.promises.mkdir(dir, { recursive: true });
    const key = cacheHash(rootPath);
    await fs.promises.writeFile(
      path.join(dir, `${key}.json`),
      JSON.stringify(indexData), 'utf-8'
    );
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

// Semantic Cache - question similarity matching (project-scoped)
ipcMain.handle('semantic-cache-get', async (_, question, rootPath) => {
  try {
    const projectScope = rootPath ? cacheHash(rootPath) : '_global';
    const dir = path.join(cacheDir, 'semantic', projectScope);
    await fs.promises.mkdir(dir, { recursive: true });
    const files = await fs.promises.readdir(dir);

    let bestMatch = null;
    let bestScore = 0;
    const threshold = 0.85;

    for (const file of files.slice(-100)) { // Check last 100 entries
      if (!file.endsWith('.json')) continue;
      try {
        const data = JSON.parse(await fs.promises.readFile(path.join(dir, file), 'utf-8'));
        // Check TTL (48 hours for semantic cache)
        if (Date.now() - data.timestamp > 172800000) continue;
        const score = stringSimilarity(question.toLowerCase(), data.question.toLowerCase());
        if (score > threshold && score > bestScore) {
          bestScore = score;
          bestMatch = data;
        }
      } catch { /* skip corrupt */ }
    }

    return bestMatch ? { answer: bestMatch.answer, score: bestScore, question: bestMatch.question } : null;
  } catch {
    return null;
  }
});

ipcMain.handle('semantic-cache-set', async (_, question, answer, rootPath) => {
  try {
    const projectScope = rootPath ? cacheHash(rootPath) : '_global';
    const dir = path.join(cacheDir, 'semantic', projectScope);
    await fs.promises.mkdir(dir, { recursive: true });
    const key = cacheHash(question + Date.now());
    await fs.promises.writeFile(
      path.join(dir, `${key}.json`),
      JSON.stringify({ question, answer, timestamp: Date.now() }), 'utf-8'
    );
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

// Cache stats
ipcMain.handle('cache-stats', async () => {
  try {
    await fs.promises.mkdir(path.join(cacheDir, 'llm'), { recursive: true });
    await fs.promises.mkdir(path.join(cacheDir, 'semantic'), { recursive: true });
    const llmFiles = await fs.promises.readdir(path.join(cacheDir, 'llm')).catch(() => []);
    const semanticFiles = await fs.promises.readdir(path.join(cacheDir, 'semantic')).catch(() => []);
    return { llmEntries: llmFiles.length, semanticEntries: semanticFiles.length };
  } catch {
    return { llmEntries: 0, semanticEntries: 0 };
  }
});

// ─── Cache Cleanup (purge expired entries) ───
const CACHE_TTL = {
  llm: 86400000,      // 24 hours
  rag: 300000,         // 5 minutes
  semantic: 172800000, // 48 hours
};

async function purgeExpiredCache() {
  let purged = { llm: 0, rag: 0, semantic: 0 };
  for (const [type, ttl] of Object.entries(CACHE_TTL)) {
    const baseDir = path.join(cacheDir, type);
    try {
      await fs.promises.mkdir(baseDir, { recursive: true });
      // Purge JSON files at baseDir level (llm, rag)
      // and also recurse into project-scoped subdirs (semantic/<hash>/)
      await purgeDir(baseDir, ttl, purged, type);
    } catch { /* dir doesn't exist yet */ }
  }
  return purged;
}

async function purgeDir(dir, ttl, purged, type) {
  const entries = await fs.promises.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      // Recurse into project-scoped subdirs
      await purgeDir(fullPath, ttl, purged, type);
      // Remove empty dirs
      try {
        const remaining = await fs.promises.readdir(fullPath);
        if (remaining.length === 0) await fs.promises.rmdir(fullPath);
      } catch {}
    } else if (entry.name.endsWith('.json')) {
      try {
        const data = JSON.parse(await fs.promises.readFile(fullPath, 'utf-8'));
        if (data.timestamp && (Date.now() - data.timestamp > ttl)) {
          await fs.promises.unlink(fullPath);
          purged[type]++;
        }
      } catch {
        // Corrupt file — remove it
        await fs.promises.unlink(fullPath).catch(() => {});
        purged[type]++;
      }
    }
  }
}

// Run on app start (after ready)
app.whenReady().then(() => {
  setTimeout(() => purgeExpiredCache(), 5000);
});

// Expose as IPC for manual trigger
ipcMain.handle('cache-purge', async () => {
  return await purgeExpiredCache();
});

// Simple string similarity (bigram-based Dice coefficient)
function stringSimilarity(a, b) {
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  const bigramsA = new Set();
  for (let i = 0; i < a.length - 1; i++) bigramsA.add(a.substring(i, i + 2));
  let matches = 0;
  for (let i = 0; i < b.length - 1; i++) {
    if (bigramsA.has(b.substring(i, i + 2))) matches++;
  }
  return (2 * matches) / (a.length - 1 + b.length - 1);
}

// ─── Code Validation ───
const { execFile } = require('child_process');

ipcMain.handle('run-validation', async (_, rootPath, filePath) => {
  const results = [];
  const ext = path.extname(filePath).toLowerCase();

  // Try ESLint for JS/TS files
  if (['.js', '.jsx', '.ts', '.tsx'].includes(ext)) {
    try {
      const eslintPath = path.join(rootPath, 'node_modules', '.bin', 'eslint');
      const r = await runCommand(eslintPath, [filePath, '--format', 'json', '--no-eslintrc'], rootPath);
      if (r.stdout) {
        try {
          const parsed = JSON.parse(r.stdout);
          for (const file of parsed) {
            for (const msg of (file.messages || [])) {
              results.push({
                type: msg.severity === 2 ? 'error' : 'warning',
                line: msg.line,
                column: msg.column,
                message: msg.message,
                rule: msg.ruleId,
              });
            }
          }
        } catch {}
      }
    } catch {}
  }

  // Try Python flake8/pylint
  if (ext === '.py') {
    try {
      const r = await runCommand('python', ['-m', 'py_compile', filePath], rootPath);
      if (r.stderr) {
        results.push({ type: 'error', line: 0, message: r.stderr.trim() });
      }
    } catch (e) {
      if (e.stderr) {
        results.push({ type: 'error', line: 0, message: e.stderr.trim() });
      }
    }
  }

  return results;
});

function runCommand(cmd, args, cwd) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { cwd, timeout: 10000 }, (error, stdout, stderr) => {
      if (error && !stdout && !stderr) reject(error);
      else resolve({ stdout: stdout || '', stderr: stderr || '' });
    });
  });
}

// ─── Debug Log ───
const debugDir = path.join(__dirname, '..', 'debug');

ipcMain.handle('debug-log', async (_, filename, content) => {
  try {
    await fs.promises.mkdir(debugDir, { recursive: true });
    const filePath = path.join(debugDir, filename);
    await fs.promises.writeFile(filePath, content, 'utf-8');
    return { success: true, path: filePath };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('debug-log-append', async (_, filename, line) => {
  try {
    await fs.promises.mkdir(debugDir, { recursive: true });
    const filePath = path.join(debugDir, filename);
    await fs.promises.appendFile(filePath, line + '\n', 'utf-8');
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
});

// ─── Settings ───
const settingsPath = path.join(app.getPath('userData'), 'settings.json');

ipcMain.handle('load-settings', async () => {
  try {
    const data = await fs.promises.readFile(settingsPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
});

ipcMain.handle('save-settings', async (_, settings) => {
  await fs.promises.writeFile(settingsPath, JSON.stringify(settings, null, 2), 'utf-8');
  return { success: true };
});
