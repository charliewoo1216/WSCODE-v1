const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Window controls
  windowMinimize: () => ipcRenderer.send('window-minimize'),
  windowMaximize: () => ipcRenderer.send('window-maximize'),
  windowClose: () => ipcRenderer.send('window-close'),

  // File system
  openFolder: () => ipcRenderer.invoke('open-folder'),
  openFileDialog: () => ipcRenderer.invoke('open-file-dialog'),
  readFile: (filePath) => ipcRenderer.invoke('read-file', filePath),
  writeFile: (filePath, content) => ipcRenderer.invoke('write-file', filePath, content),
  readDir: (dirPath) => ipcRenderer.invoke('read-dir', dirPath),
  saveFileDialog: (defaultPath) => ipcRenderer.invoke('save-file-dialog', defaultPath),

  // Project analysis
  scanProjectFiles: (rootPath) => ipcRenderer.invoke('scan-project-files', rootPath),

  // AI
  aiRequest: (params) => ipcRenderer.invoke('ai-request', params),
  aiStreamRequest: (params) => ipcRenderer.send('ai-stream-request', params),
  onAiStreamChunk: (cb) => ipcRenderer.on('ai-stream-chunk', (_, chunk) => cb(chunk)),
  onAiStreamEnd: (cb) => ipcRenderer.on('ai-stream-end', () => cb()),
  onAiStreamError: (cb) => ipcRenderer.on('ai-stream-error', (_, err) => cb(err)),
  aiStreamAbort: () => ipcRenderer.send('ai-stream-abort'),
  removeAiStreamListeners: () => {
    ipcRenderer.removeAllListeners('ai-stream-chunk');
    ipcRenderer.removeAllListeners('ai-stream-end');
    ipcRenderer.removeAllListeners('ai-stream-error');
  },

  // AI models
  aiFetchModels: (params) => ipcRenderer.invoke('ai-fetch-models', params),

  // Search & file operations
  searchInFiles: (rootPath, query, options) => ipcRenderer.invoke('search-in-files', rootPath, query, options),
  createFile: (filePath, content) => ipcRenderer.invoke('create-file', filePath, content),
  createFolder: (folderPath) => ipcRenderer.invoke('create-folder', folderPath),
  renamePath: (oldPath, newPath) => ipcRenderer.invoke('rename-path', oldPath, newPath),
  deletePath: (filePath) => ipcRenderer.invoke('delete-path', filePath),
  pathExists: (filePath) => ipcRenderer.invoke('path-exists', filePath),
  listAllFiles: (rootPath) => ipcRenderer.invoke('list-all-files', rootPath),

  // File watching
  watchFolder: (folderPath) => ipcRenderer.invoke('watch-folder', folderPath),
  unwatchFolder: () => ipcRenderer.invoke('unwatch-folder'),
  onFileChanged: (cb) => ipcRenderer.on('file-changed', (_, data) => cb(data)),

  // Chat history (workspace/.history/)
  saveChat: (rootPath, chatId, data) => ipcRenderer.invoke('save-chat', rootPath, chatId, data),
  loadChat: (rootPath, chatId) => ipcRenderer.invoke('load-chat', rootPath, chatId),
  listChats: (rootPath) => ipcRenderer.invoke('list-chats', rootPath),
  deleteChat: (rootPath, chatId) => ipcRenderer.invoke('delete-chat', rootPath, chatId),

  // Terminal
  terminalCreate: (options) => ipcRenderer.invoke('terminal-create', options),
  terminalWrite: (id, data) => ipcRenderer.send('terminal-write', { id, data }),
  terminalResize: (id, cols, rows) => ipcRenderer.invoke('terminal-resize', { id, cols, rows }),
  terminalKill: (id) => ipcRenderer.invoke('terminal-kill', id),
  onTerminalData: (cb) => ipcRenderer.on('terminal-data', (_, data) => cb(data)),
  onTerminalExit: (cb) => ipcRenderer.on('terminal-exit', (_, data) => cb(data)),

  // Cache
  cacheGet: (key) => ipcRenderer.invoke('cache-get', key),
  cacheSet: (key, value) => ipcRenderer.invoke('cache-set', key, value),
  ragCacheGet: (rootPath) => ipcRenderer.invoke('rag-cache-get', rootPath),
  ragCacheSet: (rootPath, data) => ipcRenderer.invoke('rag-cache-set', rootPath, data),
  semanticCacheGet: (question, rootPath) => ipcRenderer.invoke('semantic-cache-get', question, rootPath),
  semanticCacheSet: (question, answer, rootPath) => ipcRenderer.invoke('semantic-cache-set', question, answer, rootPath),
  cacheStats: () => ipcRenderer.invoke('cache-stats'),
  cachePurge: () => ipcRenderer.invoke('cache-purge'),

  // Code Validation
  runValidation: (rootPath, filePath) => ipcRenderer.invoke('run-validation', rootPath, filePath),

  // Debug
  debugLog: (filename, content) => ipcRenderer.invoke('debug-log', filename, content),
  debugLogAppend: (filename, line) => ipcRenderer.invoke('debug-log-append', filename, line),

  // Settings
  loadSettings: () => ipcRenderer.invoke('load-settings'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
});
