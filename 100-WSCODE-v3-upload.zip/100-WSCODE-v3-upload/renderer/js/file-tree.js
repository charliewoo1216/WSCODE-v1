/**
 * File Explorer / Tree View
 */

class FileTree {
  constructor() {
    this.rootPath = null;
    this.rootName = '';
    this._watchDebounce = null;
    this.setupWatcher();
  }

  async openFolder(folderPath) {
    if (!folderPath) {
      folderPath = await window.api.openFolder();
    }
    if (!folderPath) return;

    // ─── Project isolation: clear all AI state when switching projects ───
    const isSwitch = this.rootPath && this.rootPath !== folderPath;
    if (isSwitch) {
      // Save current chat before switching
      if (window.aiPanel) window.aiPanel.saveCurrentChat();
    }

    // Always reset AI state for clean project boundary
    window.aiService.clearHistory();
    window.aiService.projectContext = null;
    if (window.aiPanel) {
      window.aiPanel.currentChatId = null;
      window.aiPanel.contexts = [];
      window.aiPanel.sessionMeta = { task: '', summary: '', keyDecisions: [], modifiedFiles: [], pendingTasks: [] };
      window.aiPanel.renderChips();
      window.aiPanel.messagesEl.innerHTML = `
        <div class="ai-welcome">
          <div class="ai-welcome-icon">&#129302;</div>
          <h3>WSCODE AI Copilot</h3>
          <p>Ask me anything about your code.</p>
          <p class="ai-welcome-hint">Use <code>@workspace</code> to analyze the whole project<br>Use <code>@file</code> to reference a specific file</p>
        </div>
      `;
      if (window.aiPanel.tokenInfo) window.aiPanel.tokenInfo.textContent = 'Ready';
    }

    this.rootPath = folderPath;
    this.rootName = folderPath.split(/[/\\]/).pop();
    document.getElementById('titlebar-title').textContent =
      `${this.rootName} - WSCODE`;

    const tree = await window.api.readDir(folderPath);
    if (tree.error) {
      console.error(tree.error);
      return;
    }

    this.render(tree);

    // Start watching for file changes
    window.api.watchFolder(folderPath);

    // Auto-load PROJECT.md as AI project context
    this.loadProjectMd(folderPath);
  }

  async loadProjectMd(folderPath) {
    const sep = folderPath.includes('/') ? '/' : '\\';
    // Try PROJECT.md, then .assistant/PROJECT.md
    const candidates = [
      folderPath + sep + 'PROJECT.md',
      folderPath + sep + '.assistant' + sep + 'PROJECT.md',
    ];
    for (const filePath of candidates) {
      const exists = await window.api.pathExists(filePath);
      if (exists) {
        const content = await window.api.readFile(filePath);
        if (content && !content.error) {
          const fileName = filePath.split(/[/\\]/).pop();
          window.aiService.setProjectContext({
            tree: '',
            files: [],
            summary: content,
          });
          if (window.aiPanel) {
            window.aiPanel.addSystemMessage(`Loaded ${fileName} as project context`);
          }
          return;
        }
      }
    }
  }

  setupWatcher() {
    window.api.onFileChanged((data) => {
      // Debounce refresh
      clearTimeout(this._watchDebounce);
      this._watchDebounce = setTimeout(() => {
        if (this.rootPath) this.refreshTree();
      }, 500);
    });
  }

  async refreshTree() {
    if (!this.rootPath) return;
    const tree = await window.api.readDir(this.rootPath);
    if (!tree.error) this.render(tree);
  }

  render(tree) {
    const container = document.getElementById('file-tree');
    container.innerHTML = '';

    // Root section header
    const header = document.createElement('div');
    header.className = 'sidebar-header';
    header.style.cursor = 'pointer';
    header.innerHTML = `<span>&#9660; ${this.rootName.toUpperCase()}</span>`;
    container.appendChild(header);

    const treeEl = document.createElement('div');
    treeEl.style.paddingBottom = '20px';
    this.renderItems(tree, treeEl, 0);
    container.appendChild(treeEl);
  }

  renderItems(items, parentEl, depth) {
    for (const item of items) {
      if (item.type === 'dir') {
        const folder = document.createElement('div');

        const row = document.createElement('div');
        row.className = 'tree-folder';
        row.style.paddingLeft = `${12 + depth * 16}px`;
        row.innerHTML = `
          <span class="tree-arrow">&#9654;</span>
          <span class="tree-icon icon-folder">&#128194;</span>
          <span class="tree-name">${item.name}</span>
        `;

        const children = document.createElement('div');
        children.className = 'tree-children';
        this.renderItems(item.children || [], children, depth + 1);

        row.addEventListener('click', () => {
          const isOpen = children.classList.toggle('open');
          row.querySelector('.tree-arrow').innerHTML = isOpen ? '&#9660;' : '&#9654;';
        });

        // Right click → folder context menu
        row.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          const folderItem = { ...item, isDir: true };
          this.showContextMenu(e, folderItem);
        });

        folder.appendChild(row);
        folder.appendChild(children);
        parentEl.appendChild(folder);
      } else {
        const file = document.createElement('div');
        file.className = 'tree-file';
        file.style.paddingLeft = `${28 + depth * 16}px`;
        file.dataset.path = item.path;

        const ext = item.name.split('.').pop().toLowerCase();
        const iconClass = `icon-${ext}`;
        const iconText = this.getIconText(ext);

        file.innerHTML = `
          <span class="tree-icon ${iconClass}">${iconText}</span>
          <span class="tree-name">${item.name}</span>
        `;

        file.addEventListener('click', () => {
          window.editorManager.openFile(item.path, item.name);
        });

        // Right click → context menu with "Send to AI"
        file.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          this.showContextMenu(e, item);
        });

        parentEl.appendChild(file);
      }
    }
  }

  getIconText(ext) {
    const icons = {
      js: 'JS', ts: 'TS', py: 'Py', html: '<>', css: '#', json: '{}',
      md: 'M', xml: '<>', yaml: 'Y', yml: 'Y', sh: '$', sql: 'Q',
      go: 'Go', rs: 'Rs', java: 'Jv', c: 'C', cpp: 'C+', rb: 'Rb',
    };
    return icons[ext] || '~';
  }

  showContextMenu(e, item) {
    // Remove existing
    document.querySelectorAll('.context-menu').forEach(m => m.remove());

    const menu = document.createElement('div');
    menu.className = 'context-menu';
    menu.style.cssText = `
      position: fixed; left: ${e.clientX}px; top: ${e.clientY}px;
      background: #2d2d2d; border: 1px solid #454545; border-radius: 4px;
      padding: 4px 0; z-index: 9999; min-width: 180px; font-size: 13px;
    `;

    const items = item.isDir ? [
      { label: 'New File...', action: () => this.createNewFile(item) },
      { label: 'New Folder...', action: () => this.createNewFolder(item) },
      { type: 'separator' },
      { label: 'Rename', action: () => this.inlineRename(item) },
      { label: 'Delete', action: () => this.deleteItem(item) },
    ] : [
      { label: 'Open', action: () => window.editorManager.openFile(item.path, item.name) },
      { type: 'separator' },
      { label: 'New File...', action: () => this.createNewFile(item) },
      { label: 'New Folder...', action: () => this.createNewFolder(item) },
      { type: 'separator' },
      { label: 'Rename', action: () => this.inlineRename(item) },
      { label: 'Delete', action: () => this.deleteItem(item) },
      { type: 'separator' },
      { label: 'Send to AI Chat', action: () => {
        if (window.aiPanel) window.aiPanel.addFileContext(item.path, item.name);
      }},
    ];

    for (const menuItem of items) {
      if (menuItem.type === 'separator') {
        const sep = document.createElement('div');
        sep.style.cssText = 'height:1px; background:#454545; margin:4px 0;';
        menu.appendChild(sep);
        continue;
      }
      const el = document.createElement('div');
      el.textContent = menuItem.label;
      el.style.cssText = 'padding: 4px 16px; cursor: pointer; color: #ccc;';
      el.addEventListener('mouseenter', () => el.style.background = '#094771');
      el.addEventListener('mouseleave', () => el.style.background = 'transparent');
      el.addEventListener('click', () => { menuItem.action(); menu.remove(); });
      menu.appendChild(el);
    }

    document.body.appendChild(menu);
    setTimeout(() => {
      document.addEventListener('click', () => menu.remove(), { once: true });
    }, 10);
  }
  async createNewFile(contextItem) {
    const dirPath = contextItem.type === 'dir' ? contextItem.path :
      contextItem.path.substring(0, contextItem.path.lastIndexOf(contextItem.path.includes('/') ? '/' : '\\'));
    const name = prompt('New file name:');
    if (!name) return;
    const fullPath = dirPath + (dirPath.includes('/') ? '/' : '\\') + name;
    const result = await window.api.createFile(fullPath, '');
    if (result.success) {
      await this.openFolder(this.rootPath);
      window.editorManager.openFile(fullPath, name);
    }
  }

  async createNewFolder(contextItem) {
    const dirPath = contextItem.type === 'dir' ? contextItem.path :
      contextItem.path.substring(0, contextItem.path.lastIndexOf(contextItem.path.includes('/') ? '/' : '\\'));
    const name = prompt('New folder name:');
    if (!name) return;
    const fullPath = dirPath + (dirPath.includes('/') ? '/' : '\\') + name;
    const result = await window.api.createFolder(fullPath);
    if (result.success) {
      await this.openFolder(this.rootPath);
    }
  }

  async inlineRename(item) {
    const name = prompt('Rename to:', item.name);
    if (!name || name === item.name) return;
    const parentDir = item.path.substring(0, item.path.length - item.name.length);
    const newPath = parentDir + name;
    const result = await window.api.renamePath(item.path, newPath);
    if (result.success) {
      await this.openFolder(this.rootPath);
    }
  }

  async deleteItem(item) {
    if (!confirm(`Delete "${item.name}"?`)) return;
    const result = await window.api.deletePath(item.path);
    if (result.success) {
      await this.openFolder(this.rootPath);
    }
  }
}

window.fileTree = new FileTree();
