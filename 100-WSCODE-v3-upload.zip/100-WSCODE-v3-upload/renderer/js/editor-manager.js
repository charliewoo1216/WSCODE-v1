/**
 * Monaco Editor Manager
 * Handles editor initialization, tabs, and file management
 */

class EditorManager {
  constructor() {
    this.editor = null;
    this.tabs = new Map(); // filePath -> { model, viewState, modified, name }
    this.activeTab = null;
    this.monacoReady = false;
    this.secondaryEditor = null;
    this.splitMode = false;
    this.secondaryActiveTab = null;
  }

  async init() {
    return new Promise((resolve) => {
      const monacoBase = '../node_modules/monaco-editor/min';
      const loaderScript = document.createElement('script');
      loaderScript.src = `${monacoBase}/vs/loader.js`;
      loaderScript.onload = () => {
        require.config({ paths: { vs: `${monacoBase}/vs` } });
        require(['vs/editor/editor.main'], () => {
          this.monacoReady = true;
          this.createEditor();
          resolve();
        });
      };
      document.head.appendChild(loaderScript);
    });
  }

  createEditor() {
    const container = document.getElementById('editor-primary');
    this.editor = monaco.editor.create(container, {
      value: '',
      language: 'plaintext',
      theme: 'vs-dark',
      automaticLayout: true,
      fontSize: 14,
      fontFamily: "'Consolas', 'Courier New', monospace",
      minimap: { enabled: true },
      scrollBeyondLastLine: false,
      renderWhitespace: 'selection',
      tabSize: 2,
      wordWrap: 'off',
      lineNumbers: 'on',
      glyphMargin: false,
      folding: true,
      bracketPairColorization: { enabled: true },
      cursorBlinking: 'smooth',
      smoothScrolling: true,
      padding: { top: 4 },
    });

    // Cursor position → status bar
    this.editor.onDidChangeCursorPosition((e) => {
      const pos = e.position;
      document.getElementById('status-cursor').textContent = `Ln ${pos.lineNumber}, Col ${pos.column}`;
    });

    // Content change → mark modified
    this.editor.onDidChangeModelContent(() => {
      if (this.activeTab) {
        const tab = this.tabs.get(this.activeTab);
        if (tab && !tab.modified) {
          tab.modified = true;
          this.renderTabs();
        }
      }
    });

    // Keyboard shortcuts
    this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
      this.saveCurrentFile();
    });

    this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyL, () => {
      // Send selection to AI
      const selection = this.editor.getModel().getValueInRange(this.editor.getSelection());
      if (selection && window.aiPanel) {
        window.aiPanel.addContext('selection', selection);
        window.aiPanel.focusInput();
      }
    });

    // AI Context Menu Actions
    this.editor.addAction({
      id: 'ai-explain',
      label: 'AI: Explain This Code',
      contextMenuGroupId: 'ai',
      contextMenuOrder: 1,
      run: (ed) => {
        const selection = ed.getModel().getValueInRange(ed.getSelection());
        if (selection && window.aiPanel) {
          window.aiPanel.addContext('selection', selection);
          window.aiPanel.sendWithPrompt(`Explain the following code in detail:\n\`\`\`\n${selection}\n\`\`\``);
        }
      },
    });

    this.editor.addAction({
      id: 'ai-refactor',
      label: 'AI: Refactor This Code',
      contextMenuGroupId: 'ai',
      contextMenuOrder: 2,
      run: (ed) => {
        const selection = ed.getModel().getValueInRange(ed.getSelection());
        if (selection && window.aiPanel) {
          window.aiPanel.addContext('selection', selection);
          window.aiPanel.sendWithPrompt(`Refactor the following code to improve readability, performance, and best practices. Show the complete refactored code:\n\`\`\`\n${selection}\n\`\`\``);
        }
      },
    });

    this.editor.addAction({
      id: 'ai-test',
      label: 'AI: Generate Tests',
      contextMenuGroupId: 'ai',
      contextMenuOrder: 3,
      run: (ed) => {
        const selection = ed.getModel().getValueInRange(ed.getSelection());
        const lang = ed.getModel().getLanguageId();
        if (selection && window.aiPanel) {
          window.aiPanel.addContext('selection', selection);
          window.aiPanel.sendWithPrompt(`Generate unit tests for the following ${lang} code. Use appropriate testing framework:\n\`\`\`${lang}\n${selection}\n\`\`\``);
        }
      },
    });

    this.editor.addAction({
      id: 'ai-fix',
      label: 'AI: Fix Bugs',
      contextMenuGroupId: 'ai',
      contextMenuOrder: 4,
      run: (ed) => {
        const selection = ed.getModel().getValueInRange(ed.getSelection());
        if (selection && window.aiPanel) {
          window.aiPanel.addContext('selection', selection);
          window.aiPanel.sendWithPrompt(`Find and fix any bugs in the following code. Explain what was wrong and show the corrected code:\n\`\`\`\n${selection}\n\`\`\``);
        }
      },
    });

    this.editor.addAction({
      id: 'ai-comment',
      label: 'AI: Add Comments',
      contextMenuGroupId: 'ai',
      contextMenuOrder: 5,
      run: (ed) => {
        const selection = ed.getModel().getValueInRange(ed.getSelection());
        if (selection && window.aiPanel) {
          window.aiPanel.addContext('selection', selection);
          window.aiPanel.sendWithPrompt(`Add clear, concise comments to the following code. Return the complete code with comments added:\n\`\`\`\n${selection}\n\`\`\``);
        }
      },
    });

    // Setup inline completions
    this.setupInlineCompletions();

    // Hide welcome when editor has content
    this.editor.getContainerDomNode().style.display = 'none';
  }

  setupInlineCompletions() {
    this.completionEnabled = true;
    this.completionDebounce = null;

    // Register inline completion provider for all languages
    monaco.languages.registerInlineCompletionsProvider({ pattern: '**' }, {
      provideInlineCompletions: async (model, position, context, token) => {
        if (!this.completionEnabled) return { items: [] };
        if (!window.aiService.model) return { items: [] };

        // Don't trigger on very short files or if just opened
        const fullText = model.getValue();
        if (fullText.length < 10) return { items: [] };

        // Get code before and after cursor
        const offset = model.getOffsetAt(position);
        const codeBeforeCursor = fullText.substring(0, offset);
        const codeAfterCursor = fullText.substring(offset);

        // Don't trigger if cursor is at the start of a line with no context
        const lineContent = model.getLineContent(position.lineNumber);
        const textBeforeOnLine = lineContent.substring(0, position.column - 1).trim();
        if (textBeforeOnLine.length < 2 && position.column <= 2) return { items: [] };

        const language = model.getLanguageId();
        const fileName = this.getCurrentFileName() || 'untitled';

        try {
          const completion = await window.aiService.getInlineCompletion(
            codeBeforeCursor, codeAfterCursor, language, fileName
          );

          if (!completion || token.isCancellationRequested) return { items: [] };

          return {
            items: [{
              insertText: completion,
              range: {
                startLineNumber: position.lineNumber,
                startColumn: position.column,
                endLineNumber: position.lineNumber,
                endColumn: position.column,
              },
            }],
          };
        } catch {
          return { items: [] };
        }
      },
      freeInlineCompletions: () => {},
    });
  }

  toggleInlineCompletions() {
    this.completionEnabled = !this.completionEnabled;
    return this.completionEnabled;
  }

  getLanguageFromPath(filePath) {
    const ext = filePath.split('.').pop().toLowerCase();
    const map = {
      js: 'javascript', jsx: 'javascript', ts: 'typescript', tsx: 'typescript',
      py: 'python', html: 'html', htm: 'html', css: 'css', scss: 'scss',
      json: 'json', md: 'markdown', xml: 'xml', yaml: 'yaml', yml: 'yaml',
      sh: 'shell', bash: 'shell', sql: 'sql', go: 'go', rs: 'rust',
      java: 'java', c: 'c', cpp: 'cpp', h: 'c', hpp: 'cpp',
      rb: 'ruby', php: 'php', swift: 'swift', kt: 'kotlin',
      dart: 'dart', vue: 'html', svelte: 'html', toml: 'ini',
    };
    return map[ext] || 'plaintext';
  }

  async openFile(filePath, name) {
    // If already open, switch to it
    if (this.tabs.has(filePath)) {
      this.switchTab(filePath);
      return;
    }

    const content = await window.api.readFile(filePath);
    if (content && content.error) {
      console.error('Failed to read file:', content.error);
      return;
    }

    const language = this.getLanguageFromPath(filePath);
    const model = monaco.editor.createModel(content, language, monaco.Uri.file(filePath));

    this.tabs.set(filePath, {
      model,
      viewState: null,
      modified: false,
      name: name || filePath.split(/[/\\]/).pop(),
      language,
    });

    this.switchTab(filePath);
    this.renderTabs();
  }

  switchTab(filePath) {
    // Save current view state
    if (this.activeTab && this.tabs.has(this.activeTab)) {
      this.tabs.get(this.activeTab).viewState = this.editor.saveViewState();
    }

    this.activeTab = filePath;
    const tab = this.tabs.get(filePath);

    // Show editor, hide welcome
    document.getElementById('welcome-screen').style.display = 'none';
    this.editor.getContainerDomNode().style.display = 'block';

    this.editor.setModel(tab.model);
    if (tab.viewState) {
      this.editor.restoreViewState(tab.viewState);
    }
    this.editor.focus();

    // Update status bar
    const lang = tab.language || 'plaintext';
    document.getElementById('status-lang').textContent =
      lang.charAt(0).toUpperCase() + lang.slice(1);

    // Update breadcrumb
    this.updateBreadcrumb(filePath);

    // Mark active in file tree
    document.querySelectorAll('.tree-file').forEach(el => {
      el.classList.toggle('active', el.dataset.path === filePath);
    });

    this.renderTabs();
  }

  updateBreadcrumb(filePath) {
    const bc = document.getElementById('breadcrumb');
    if (!filePath) { bc.classList.remove('visible'); return; }
    bc.classList.add('visible');

    const parts = filePath.replace(/\\/g, '/').split('/');
    const last3 = parts.slice(-3);
    bc.innerHTML = last3.map((p, i) =>
      (i > 0 ? '<span class="bc-sep">&#9656;</span>' : '') +
      `<span>${p}</span>`
    ).join('');
  }

  closeTab(filePath) {
    const tab = this.tabs.get(filePath);
    if (!tab) return;

    tab.model.dispose();
    this.tabs.delete(filePath);

    if (this.activeTab === filePath) {
      const remaining = [...this.tabs.keys()];
      if (remaining.length > 0) {
        this.switchTab(remaining[remaining.length - 1]);
      } else {
        this.activeTab = null;
        document.getElementById('welcome-screen').style.display = 'flex';
        this.editor.getContainerDomNode().style.display = 'none';
        document.getElementById('breadcrumb').classList.remove('visible');
        document.getElementById('status-lang').textContent = 'Plain Text';
        document.getElementById('status-cursor').textContent = 'Ln 1, Col 1';
      }
    }
    this.renderTabs();
  }

  async saveCurrentFile() {
    if (!this.activeTab) return;
    const tab = this.tabs.get(this.activeTab);
    if (!tab) return;

    let filePath = this.activeTab;
    if (filePath.startsWith('untitled:')) {
      filePath = await window.api.saveFileDialog(tab.name);
      if (!filePath) return;
      // Re-key the tab
      this.tabs.delete(this.activeTab);
      this.activeTab = filePath;
      tab.name = filePath.split(/[/\\]/).pop();
      this.tabs.set(filePath, tab);
    }

    const content = tab.model.getValue();
    const result = await window.api.writeFile(filePath, content);
    if (result.success) {
      tab.modified = false;
      this.renderTabs();
    }
  }

  createUntitledFile() {
    const id = `untitled:Untitled-${this.tabs.size + 1}`;
    const model = monaco.editor.createModel('', 'plaintext');
    this.tabs.set(id, {
      model, viewState: null, modified: false,
      name: `Untitled-${this.tabs.size + 1}`, language: 'plaintext',
    });
    this.switchTab(id);
    this.renderTabs();
  }

  renderTabs() {
    const container = document.getElementById('tabs-list');
    container.innerHTML = '';

    for (const [filePath, tab] of this.tabs) {
      const el = document.createElement('div');
      el.className = 'tab' + (filePath === this.activeTab ? ' active' : '') + (tab.modified ? ' modified' : '');

      const ext = tab.name.split('.').pop().toLowerCase();
      const iconClass = `icon-${ext}`;

      el.innerHTML = `
        <span class="tab-icon ${iconClass}">${this.getFileIconText(ext)}</span>
        <span class="tab-name">${tab.name}</span>
        <span class="tab-modified">&bull;</span>
        <span class="tab-close">&times;</span>
      `;

      el.querySelector('.tab-name').addEventListener('click', () => this.switchTab(filePath));
      el.querySelector('.tab-close').addEventListener('click', (e) => {
        e.stopPropagation();
        this.closeTab(filePath);
      });
      el.addEventListener('click', () => this.switchTab(filePath));

      container.appendChild(el);
    }
  }

  getFileIconText(ext) {
    const icons = {
      js: 'JS', ts: 'TS', py: 'Py', html: '<>', css: '#', json: '{}',
      md: 'M', xml: '<>', yaml: 'Y', yml: 'Y', sh: '$', sql: 'Q',
      go: 'Go', rs: 'Rs', java: 'Jv', c: 'C', cpp: 'C+', rb: 'Rb',
    };
    return icons[ext] || '~';
  }

  getCurrentFileContent() {
    if (!this.activeTab) return null;
    const tab = this.tabs.get(this.activeTab);
    return tab ? tab.model.getValue() : null;
  }

  getCurrentFilePath() {
    return this.activeTab;
  }

  getCurrentFileName() {
    if (!this.activeTab) return null;
    const tab = this.tabs.get(this.activeTab);
    return tab ? tab.name : null;
  }

  async backupAndApply(filePath, originalContent, newContent) {
    // Generate backup filename: readme.md → readme-bak01.md, readme-bak02.md, ...
    const lastDot = filePath.lastIndexOf('.');
    const baseName = lastDot > -1 ? filePath.substring(0, lastDot) : filePath;
    const ext = lastDot > -1 ? filePath.substring(lastDot) : '';

    let backupNum = 1;
    let backupPath;
    while (true) {
      const num = String(backupNum).padStart(2, '0');
      backupPath = `${baseName}-bak${num}${ext}`;
      const exists = await window.api.pathExists(backupPath);
      if (!exists) break;
      backupNum++;
      if (backupNum > 99) break;
    }

    // Save backup
    await window.api.writeFile(backupPath, originalContent);

    // Apply new content
    this.applyDiff(filePath, newContent);

    // Notify
    const backupName = backupPath.split(/[/\\]/).pop();
    if (window.aiPanel) {
      window.aiPanel.addSystemMessage(`Backup saved: ${backupName}`);
    }
  }

  applyDiff(filePath, newContent) {
    // If file is open, update its model
    if (this.tabs.has(filePath)) {
      const tab = this.tabs.get(filePath);
      tab.model.setValue(newContent);
      tab.modified = true;
      this.renderTabs();
    }
  }

  // Show diff preview in main editor area (VS Code style)
  showDiffInEditor(filePath, newContent) {
    if (!this.tabs.has(filePath)) return false;

    const tab = this.tabs.get(filePath);
    const originalContent = tab.model.getValue();
    const language = tab.language || 'plaintext';

    // === 1. Update tabs bar: show diff tab ===
    const tabsList = document.getElementById('tabs-list');
    const diffTabId = 'diff-tab-active';

    // Deactivate all existing tabs visually
    tabsList.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));

    // Add diff tab
    let diffTab = document.getElementById(diffTabId);
    if (diffTab) diffTab.remove();
    diffTab = document.createElement('div');
    diffTab.id = diffTabId;
    diffTab.className = 'tab active';
    diffTab.innerHTML = `
      <span class="tab-icon" style="color:#f85149;">&#8644;</span>
      <span class="tab-name">${tab.name} (Changes)</span>
      <span class="tab-close">&times;</span>
    `;
    tabsList.appendChild(diffTab);

    // === 2. Hide editor-container, show diff ===
    const editorContainer = document.getElementById('editor-container');
    editorContainer.style.display = 'none';

    // Update breadcrumb
    const bc = document.getElementById('breadcrumb');
    bc.classList.add('visible');
    bc.innerHTML = `<span style="color:#9cdcfe;">${tab.name}</span><span class="bc-sep">&#9656;</span><span style="color:#f85149;">Review Changes</span>`;

    // Remove previous diff wrap
    let diffWrap = document.getElementById('editor-diff-wrap');
    if (diffWrap) diffWrap.remove();

    // Create diff wrap
    const editorArea = document.getElementById('editor-area');
    diffWrap = document.createElement('div');
    diffWrap.id = 'editor-diff-wrap';
    diffWrap.style.cssText = 'flex:1;display:flex;flex-direction:column;min-height:0;overflow:hidden;';

    // Action bar (VS Code style - minimal, right-aligned)
    const actionBar = document.createElement('div');
    actionBar.style.cssText = 'display:flex;align-items:center;height:35px;padding:0 8px;background:#252526;border-bottom:1px solid #1e1e1e;flex-shrink:0;';
    actionBar.innerHTML = `
      <span style="font-size:12px;color:#9cdcfe;padding:0 8px;">${tab.name}</span>
      <span style="font-size:11px;color:#666;margin-right:auto;">&#8596; Modified</span>
      <button class="diff-action-btn" id="diff-act-inline" title="Inline View" style="width:28px;height:24px;background:none;border:1px solid transparent;border-radius:3px;cursor:pointer;color:#888;font-size:14px;display:flex;align-items:center;justify-content:center;">&#9776;</button>
      <button class="diff-action-btn" id="diff-act-side" title="Side by Side" style="width:28px;height:24px;background:none;border:1px solid #094771;border-radius:3px;cursor:pointer;color:#fff;font-size:14px;display:flex;align-items:center;justify-content:center;">&#9871;</button>
      <span style="width:1px;height:16px;background:#333;margin:0 6px;"></span>
      <button id="diff-act-reject" style="height:24px;padding:0 12px;background:none;border:1px solid #da3633;border-radius:3px;cursor:pointer;color:#f85149;font-size:11px;font-weight:600;">Discard</button>
      <button id="diff-act-accept" style="height:24px;padding:0 12px;background:#238636;border:none;border-radius:3px;cursor:pointer;color:#fff;font-size:11px;font-weight:600;margin-left:4px;">Accept Changes</button>
    `;

    // Diff editor container
    const diffContainer = document.createElement('div');
    diffContainer.style.cssText = 'flex:1;min-height:0;';

    diffWrap.appendChild(actionBar);
    diffWrap.appendChild(diffContainer);
    editorArea.appendChild(diffWrap);

    // === 3. Create Monaco DiffEditor ===
    const originalModel = monaco.editor.createModel(originalContent, language);
    const modifiedModel = monaco.editor.createModel(newContent, language);

    const diffEditor = monaco.editor.createDiffEditor(diffContainer, {
      theme: 'vs-dark',
      readOnly: false,
      automaticLayout: true,
      renderSideBySide: true,
      enableSplitViewResizing: true,
      fontSize: this.editor.getOption(monaco.editor.EditorOption.fontSize),
      minimap: { enabled: true, side: 'right' },
      scrollBeyondLastLine: false,
      lineNumbers: 'on',
      renderOverviewRuler: true,
      originalEditable: false,
    });

    diffEditor.setModel({ original: originalModel, modified: modifiedModel });

    // === 4. Toggle buttons ===
    const sideBtn = actionBar.querySelector('#diff-act-side');
    const inlineBtn = actionBar.querySelector('#diff-act-inline');
    sideBtn.addEventListener('click', () => {
      diffEditor.updateOptions({ renderSideBySide: true });
      sideBtn.style.borderColor = '#094771'; sideBtn.style.color = '#fff';
      inlineBtn.style.borderColor = 'transparent'; inlineBtn.style.color = '#888';
    });
    inlineBtn.addEventListener('click', () => {
      diffEditor.updateOptions({ renderSideBySide: false });
      inlineBtn.style.borderColor = '#094771'; inlineBtn.style.color = '#fff';
      sideBtn.style.borderColor = 'transparent'; sideBtn.style.color = '#888';
    });

    // === 5. Close diff and restore editor ===
    const closeDiff = () => {
      diffEditor.dispose();
      originalModel.dispose();
      modifiedModel.dispose();
      diffWrap.remove();
      editorContainer.style.display = 'flex';

      // Remove diff tab, restore original tab
      const dt = document.getElementById(diffTabId);
      if (dt) dt.remove();
      this.renderTabs();
      this.updateBreadcrumb(filePath);

      this.editor.layout();
      this.editor.focus();
    };

    // Diff tab close button
    diffTab.querySelector('.tab-close').addEventListener('click', (e) => {
      e.stopPropagation();
      closeDiff();
    });

    // === 6. Accept — backup + apply + save to disk ===
    actionBar.querySelector('#diff-act-accept').addEventListener('click', async () => {
      // Get the modified content (user may have edited it in the diff view)
      const finalContent = modifiedModel.getValue();
      await this.backupAndApply(filePath, originalContent, finalContent);
      // Also save to disk immediately
      await window.api.writeFile(filePath, finalContent);
      closeDiff();
    });

    // === 7. Reject ===
    actionBar.querySelector('#diff-act-reject').addEventListener('click', () => {
      closeDiff();
    });

    return true;
  }

  setFontSize(size) {
    if (this.editor) {
      this.editor.updateOptions({ fontSize: size });
    }
  }

  splitEditor() {
    if (this.splitMode) return;
    this.splitMode = true;

    const secondaryContainer = document.getElementById('editor-secondary');
    const splitHandle = document.getElementById('editor-split-handle');

    secondaryContainer.style.display = 'block';
    splitHandle.style.display = 'block';

    this.secondaryEditor = monaco.editor.create(secondaryContainer, {
      value: '',
      language: 'plaintext',
      theme: document.body.classList.contains('light') ? 'vs' : 'vs-dark',
      automaticLayout: true,
      fontSize: this.editor.getOption(monaco.editor.EditorOption.fontSize),
      fontFamily: "'Consolas', 'Courier New', monospace",
      minimap: { enabled: true },
      scrollBeyondLastLine: false,
      renderWhitespace: 'selection',
      tabSize: 2,
      wordWrap: 'off',
      lineNumbers: 'on',
      folding: true,
      bracketPairColorization: { enabled: true },
      cursorBlinking: 'smooth',
      smoothScrolling: true,
      padding: { top: 4 },
    });

    // If there's a current file, show it in secondary too
    if (this.activeTab && this.tabs.has(this.activeTab)) {
      const tab = this.tabs.get(this.activeTab);
      this.secondaryEditor.setModel(tab.model);
    }

    // Setup split handle resize
    this.setupSplitResize();
  }

  closeSplit() {
    if (!this.splitMode) return;
    this.splitMode = false;

    const secondaryContainer = document.getElementById('editor-secondary');
    const splitHandle = document.getElementById('editor-split-handle');

    if (this.secondaryEditor) {
      this.secondaryEditor.dispose();
      this.secondaryEditor = null;
    }

    secondaryContainer.style.display = 'none';
    splitHandle.style.display = 'none';
    this.secondaryActiveTab = null;
  }

  toggleSplit() {
    if (this.splitMode) this.closeSplit();
    else this.splitEditor();
  }

  openInSplit(filePath, name) {
    if (!this.splitMode) this.splitEditor();
    if (!this.tabs.has(filePath)) {
      // Need to open the file first
      this.openFile(filePath, name).then(() => {
        if (this.tabs.has(filePath) && this.secondaryEditor) {
          const tab = this.tabs.get(filePath);
          this.secondaryEditor.setModel(tab.model);
          this.secondaryActiveTab = filePath;
        }
      });
    } else {
      const tab = this.tabs.get(filePath);
      if (this.secondaryEditor) {
        this.secondaryEditor.setModel(tab.model);
        this.secondaryActiveTab = filePath;
      }
    }
  }

  setupSplitResize() {
    const handle = document.getElementById('editor-split-handle');
    const primary = document.getElementById('editor-primary');
    const secondary = document.getElementById('editor-secondary');

    let startX, startPW;
    handle.addEventListener('mousedown', (e) => {
      startX = e.clientX;
      startPW = primary.offsetWidth;
      handle.classList.add('active');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      const onMove = (e) => {
        const diff = e.clientX - startX;
        const container = document.getElementById('editor-container');
        const totalW = container.offsetWidth - handle.offsetWidth;
        const newPW = Math.min(totalW - 100, Math.max(100, startPW + diff));
        primary.style.flex = 'none';
        primary.style.width = newPW + 'px';
        secondary.style.flex = '1';
      };
      const onUp = () => {
        handle.classList.remove('active');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }
}

window.editorManager = new EditorManager();
