/**
 * AI Service - Local LLM Backend (OpenAI-compatible API)
 */

// ─── Context Budget Presets ───
const CONTEXT_BUDGET_PRESETS = {
  '24k':  { numCtx: 24576,  label: 'RTX 3060 / qwen3.5:9b (24K)' },
  '32k':  { numCtx: 32768,  label: '32K Context' },
  '64k':  { numCtx: 65536,  label: '64K Context' },
  '128k': { numCtx: 131072, label: '128K Context' },
  '235k': { numCtx: 235520, label: 'Qwen3 80B (235K)' },
};

// Default budget ratios (from CONTEXT_STRATEGY.md)
const BUDGET_RATIOS = {
  system:   0.04,  // 4%
  project:  0.17,  // 17%
  history:  0.58,  // 58%
  query:    0.13,  // 13%
  response: 0.08,  // 8%
};

class ContextBudget {
  constructor(numCtx = 24576) {
    this.numCtx = numCtx;
    this.system = 0;
    this.project = 0;
    this.history = 0;
    this.query = 0;
    this.response = 0;
    this.numPredict = 2048;
    this.temperature = 0.3;
    this.repeatPenalty = 1.1;
    this.compressAfterMsgs = 8;
    this.keepRecentMsgs = 4;
    this.recalcFromCtx(numCtx);
  }

  // Recalculate all budget slots from num_ctx using fixed ratios
  recalcFromCtx(numCtx) {
    this.numCtx = numCtx;
    this.system   = Math.round(numCtx * BUDGET_RATIOS.system / 256) * 256;
    this.project  = Math.round(numCtx * BUDGET_RATIOS.project / 512) * 512;
    this.history  = Math.round(numCtx * BUDGET_RATIOS.history / 1024) * 1024;
    this.query    = Math.round(numCtx * BUDGET_RATIOS.query / 512) * 512;
    this.response = numCtx - this.system - this.project - this.history - this.query;
    if (this.response < 512) this.response = 512;
    this.numPredict = Math.min(this.response, 8192);
  }

  get total() {
    return this.system + this.project + this.history + this.query + this.response;
  }

  pct(slot) {
    if (this.numCtx === 0) return 0;
    return Math.round((this[slot] / this.numCtx) * 100);
  }

  toJSON() {
    return {
      numCtx: this.numCtx,
      system: this.system, project: this.project,
      history: this.history, query: this.query, response: this.response,
      numPredict: this.numPredict, temperature: this.temperature,
      repeatPenalty: this.repeatPenalty,
      compressAfterMsgs: this.compressAfterMsgs,
      keepRecentMsgs: this.keepRecentMsgs,
    };
  }

  loadFrom(obj) {
    if (!obj) return;
    if (obj.numCtx) this.numCtx = obj.numCtx;
    if (obj.system) this.system = obj.system;
    if (obj.project) this.project = obj.project;
    if (obj.history) this.history = obj.history;
    if (obj.query) this.query = obj.query;
    if (obj.response) this.response = obj.response;
    if (obj.numPredict) this.numPredict = obj.numPredict;
    if (obj.temperature != null) this.temperature = obj.temperature;
    if (obj.repeatPenalty != null) this.repeatPenalty = obj.repeatPenalty;
    if (obj.compressAfterMsgs) this.compressAfterMsgs = obj.compressAfterMsgs;
    if (obj.keepRecentMsgs) this.keepRecentMsgs = obj.keepRecentMsgs;
  }
}

class AIService {
  constructor() {
    this.model = 'qwen3.5:9b';
    this.apiUrl = 'http://192.168.0.8:8080';
    this.apiKey = 'sk_123!';
    this.systemPrompt = '';
    this.history = [];
    this.projectContext = null;
    this.budget = new ContextBudget(24576);
  }

  setModel(model) { this.model = model; }
  setApiUrl(url) { this.apiUrl = url.replace(/\/+$/, ''); }
  setApiKey(key) { this.apiKey = key; }
  setSystemPrompt(prompt) { this.systemPrompt = prompt; }
  clearHistory() { this.history = []; }

  // Build system prompt with project context
  buildSystemPrompt(extraContext) {
    const DEFAULT_SYSTEM_PROMPT = `당신은 WSCODE 에디터에 내장된 AI 코딩 어시스턴트입니다.
WSCODE는 VS Code 스타일의 코드 에디터로, 다음 AI 기능을 갖추고 있습니다.

## 에디터 환경
- 사용자가 @file로 현재 파일을 전달하면 파일 전체 내용이 컨텍스트에 포함됩니다.
- 사용자가 @workspace로 프로젝트를 전달하면 프로젝트 구조와 주요 파일이 포함됩니다.
- 사용자가 @selection으로 코드 선택 영역을 전달할 수 있습니다.
- 코드 검증 결과(ESLint, py_compile 등)가 자동으로 포함될 수 있습니다.
- 당신의 코드 제안은 메인 에디터에서 Diff로 자동 표시됩니다 (원본 vs 수정안).
- 사용자가 Accept하면 원본은 자동 백업(-bak01)되고 수정안이 적용됩니다.

## 기본 규칙
- 반드시 한국어로 답변하세요. 다른 언어 사용 금지.
- 간결하고 정확하게. 불필요한 인사말, 서론, 반복 설명 생략.
- 사용자의 의도를 정확히 파악하고, 요청한 작업만 수행하세요.
- 주요 개발 언어: Python, Java, JavaScript/TypeScript, HTML/CSS, SQL 등.
- Python은 PEP 8, Java는 Google Java Style 등 각 언어의 표준 코딩 컨벤션을 따르세요.
- 언어별 최적의 라이브러리/프레임워크를 제안하세요 (Python: FastAPI, Django 등 / Java: Spring Boot 등).

## 코드 수정 규칙 (가장 중요)
- @file로 전달된 원본 코드의 모든 줄을 반드시 유지하세요.
- 요청한 부분만 수정하고, 나머지는 한 글자도 변경하지 마세요.
- 수정된 전체 파일을 하나의 코드블록으로 출력하세요 (언어 태그 포함).
- 절대 코드를 생략하지 마세요. "// ... 나머지", "// 기존 코드 유지" 등 금지.
- 기존 코드의 들여쓰기, 네이밍 규칙, 코딩 스타일을 그대로 따르세요.
- import/require가 필요하면 파일 상단의 올바른 위치에 추가하세요.
- Diff에서 실제 변경된 줄만 하이라이트되도록, 불필요한 변경을 하지 마세요.

## 에디터 우클릭 AI 메뉴 응답 형식
- "AI: Explain" 요청 → 코드블록 없이 한국어 텍스트로 핵심 로직 설명.
- "AI: Refactor" 요청 → 개선 이유 한 줄 + 전체 수정 코드블록.
- "AI: Generate Tests" 요청 → 적절한 테스트 프레임워크로 테스트 코드블록 출력.
- "AI: Fix Bugs" 요청 → 버그 원인 설명 + 수정된 전체 코드블록.
- "AI: Add Comments" 요청 → 주석이 추가된 전체 코드블록.

## 코드 품질
- 버그 수정 시 근본 원인을 설명하세요.
- 보안 취약점(XSS, SQL Injection 등)이 보이면 경고하세요.
- 성능 문제가 보이면 개선 방안을 제안하세요.

## 응답 형식 요약
- 코드 수정: 수정 이유 1줄 → 전체 파일 코드블록
- 코드 설명: 텍스트만 (코드블록 없음)
- 에러 해결: 원인 → 수정 방법 → 수정 코드블록
- 새 기능: 구현 방향 → 전체 코드블록`;

    let prompt = this.systemPrompt || DEFAULT_SYSTEM_PROMPT;

    if (this.projectContext) {
      prompt += '\n\n## Project Structure\n';
      prompt += this.projectContext.tree || '';

      if (this.projectContext.summary) {
        prompt += '\n\n## Project Summary\n' + this.projectContext.summary;
      } else if (this.projectContext.files && this.projectContext.files.length > 0) {
        prompt += '\n\n## Key Project Files\n';
        for (const f of this.projectContext.files.slice(0, 20)) {
          if (f.content) {
            prompt += `\n### ${f.path}\n\`\`\`\n${f.content.slice(0, 3000)}\n\`\`\`\n`;
          }
        }
      }
    }

    if (extraContext) {
      prompt += '\n\n## Current Context\n' + extraContext;
    }

    return prompt;
  }

  setProjectContext(data) { this.projectContext = data; }

  // Analyze project (scan all files)
  async analyzeProject(rootPath) {
    // Check RAG cache
    const ragCache = await window.api.ragCacheGet(rootPath);
    if (ragCache && (Date.now() - ragCache.timestamp < 300000)) {
      this.projectContext = { files: ragCache.files, tree: ragCache.tree, summary: ragCache.summary };
      return { fileCount: ragCache.files.length, tree: ragCache.tree, cached: true };
    }

    const files = await window.api.scanProjectFiles(rootPath);
    if (files.error) return null;

    const tree = files.map(f => f.path).join('\n');
    this.projectContext = { files, tree };

    // Store in RAG cache
    window.api.ragCacheSet(rootPath, { files, tree, timestamp: Date.now() });

    return { fileCount: files.length, tree };
  }

  // Chunked analysis for large projects
  async analyzeProjectChunked(rootPath, onProgress) {
    const files = await window.api.scanProjectFiles(rootPath);
    if (files.error) return null;

    const tree = files.map(f => f.path).join('\n');

    if (files.length <= 30) {
      this.projectContext = { files, tree };
      window.api.ragCacheSet(rootPath, { files, tree, timestamp: Date.now() });
      return { fileCount: files.length, tree, chunks: 1 };
    }

    const chunkSize = 15;
    const chunks = [];
    for (let i = 0; i < files.length; i += chunkSize) {
      chunks.push(files.slice(i, i + chunkSize));
    }

    const summaries = [];
    for (let i = 0; i < chunks.length; i++) {
      if (onProgress) onProgress(i + 1, chunks.length);
      const chunkContent = chunks[i].map(f =>
        `### ${f.path}\n\`\`\`\n${f.content.slice(0, 1500)}\n\`\`\``
      ).join('\n\n');

      try {
        const result = await this.callLLM([
          { role: 'user', content: `Summarize the purpose and key exports of these files concisely:\n\n${chunkContent}` }
        ], { max_tokens: 500 });
        if (result.content) summaries.push(result.content);
      } catch {
        summaries.push(chunks[i].map(f => f.path).join('\n'));
      }
    }

    const combinedSummary = summaries.join('\n\n---\n\n');
    this.projectContext = { files, tree, summary: combinedSummary };
    window.api.ragCacheSet(rootPath, {
      files: files.map(f => ({ path: f.path, size: f.size })),
      tree, summary: combinedSummary, timestamp: Date.now(),
    });

    return { fileCount: files.length, tree, chunks: chunks.length };
  }

  // Core LLM call (non-streaming)
  async callLLM(messages, options = {}) {
    try {
      const body = {
        model: this.model,
        messages,
        stream: false,
        temperature: options.temperature ?? this.budget.temperature,
        max_tokens: options.max_tokens ?? this.budget.numPredict,
      };
      // Ollama-compatible extended options
      if (this.apiUrl.includes(':11434') || this.apiUrl.includes(':8080')) {
        body.options = {
          num_ctx: this.budget.numCtx,
          num_predict: options.max_tokens ?? this.budget.numPredict,
          repeat_penalty: this.budget.repeatPenalty,
        };
      }
      const result = await window.api.aiRequest({
        provider: 'local',
        url: `${this.apiUrl}/v1/chat/completions`,
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body,
      });

      if (result.choices && result.choices[0]) {
        return {
          content: result.choices[0].message.content,
          usage: result.usage,
        };
      }
      return { error: result.error?.message || 'Unknown error' };
    } catch (e) {
      return { error: e.toString() };
    }
  }

  // Generate cache key (project-scoped)
  generateCacheKey(messages) {
    const projectId = window.fileTree?.rootPath || '_global';
    const str = projectId + ':' + this.model + ':' + JSON.stringify(messages.map(m => m.content).slice(-3));
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return 'llm_' + Math.abs(hash).toString(36);
  }

  // Send message (non-streaming)
  async sendMessage(userMessage, context) {
    // Auto-compress if history is getting long
    await this.compressHistory();

    const systemPrompt = this.buildSystemPrompt(context);
    this.history.push({ role: 'user', content: userMessage });

    // Budget-aware message assembly
    const messages = this.buildMessages(systemPrompt, this.history);

    // Check LLM cache
    const cacheKey = this.generateCacheKey(this.history);
    const cached = await window.api.cacheGet(cacheKey);
    if (cached) {
      this.history.push({ role: 'assistant', content: cached });
      return { content: cached, cached: true };
    }

    const result = await this.callLLM(messages);

    if (result.content) {
      this.history.push({ role: 'assistant', content: result.content });
      window.api.cacheSet(cacheKey, result.content);
    }
    return result;
  }

  // Send message with streaming
  async sendMessageStream(userMessage, context, onChunk, onDone, onError) {
    // Auto-compress if history is getting long
    await this.compressHistory();

    // Check semantic cache (only if context matches — skip for context-heavy requests)
    if (!context) {
      const semanticResult = await window.api.semanticCacheGet(userMessage, window.fileTree?.rootPath);
      if (semanticResult) {
        this.history.push({ role: 'user', content: userMessage });
        this.history.push({ role: 'assistant', content: semanticResult.answer });
        onChunk(semanticResult.answer, semanticResult.answer);
        onDone(semanticResult.answer);
        return;
      }
    }

    const systemPrompt = this.buildSystemPrompt(context);
    this.history.push({ role: 'user', content: userMessage });

    // Budget-aware message assembly
    const messages = this.buildMessages(systemPrompt, this.history);

    // Remove previous listeners
    window.api.removeAiStreamListeners();

    let fullContent = '';

    window.api.onAiStreamChunk((chunk) => {
      const lines = chunk.split('\n');
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6).trim();
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content || '';
            if (delta) {
              fullContent += delta;
              onChunk(delta, fullContent);
            }
          } catch {}
        }
      }
    });

    window.api.onAiStreamEnd(() => {
      if (fullContent) {
        this.history.push({ role: 'assistant', content: fullContent });
        window.api.semanticCacheSet(userMessage, fullContent, window.fileTree?.rootPath);
      }
      onDone(fullContent);
    });

    window.api.onAiStreamError((err) => {
      onError(err);
    });

    const streamBody = {
      model: this.model,
      messages,
      stream: true,
      temperature: this.budget.temperature,
    };
    // Ollama-compatible extended options
    if (this.apiUrl.includes(':11434') || this.apiUrl.includes(':8080')) {
      streamBody.options = {
        num_ctx: this.budget.numCtx,
        num_predict: this.budget.numPredict,
        repeat_penalty: this.budget.repeatPenalty,
      };
    }

    window.api.aiStreamRequest({
      provider: 'local',
      url: `${this.apiUrl}/v1/chat/completions`,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
      },
      body: streamBody,
    });
  }

  // Budget-aware message assembly: fit history within budget
  buildMessages(systemPrompt, history) {
    const budget = this.budget;
    const messages = [];

    // ① System prompt (trimmed to budget)
    let sysContent = systemPrompt;
    const sysTokens = this.estimateTokens(sysContent);
    if (sysTokens > budget.system + budget.project) {
      // Truncate system prompt to fit budget
      const maxChars = (budget.system + budget.project) * 3;
      sysContent = sysContent.substring(0, maxChars);
    }
    messages.push({ role: 'system', content: sysContent });

    // ③ History — fill from the end within history budget
    const maxHistoryTokens = budget.history;
    let historyTokens = 0;
    const included = [];
    for (let i = history.length - 1; i >= 0; i--) {
      const turnTokens = this.estimateTokens(history[i].content);
      if (historyTokens + turnTokens > maxHistoryTokens) break;
      included.unshift(history[i]);
      historyTokens += turnTokens;
    }

    // If some history was dropped, insert summary marker
    if (included.length < history.length && included.length > 0) {
      const droppedCount = history.length - included.length;
      messages.push({
        role: 'system',
        content: `[${droppedCount} earlier messages truncated to fit context budget]`,
      });
    }

    messages.push(...included);
    return messages;
  }

  // Compress conversation history (budget-aware)
  // Returns { compressed: true, summary: '...' } or { compressed: false }
  async compressHistory() {
    const maxMsgs = this.budget.compressAfterMsgs;
    const keepRecent = this.budget.keepRecentMsgs;
    const maxHistoryTokens = this.budget.history;

    if (this.history.length < maxMsgs) return { compressed: false };
    const totalTokens = this.estimateTokens(this.history.map(m => m.content).join(''));
    if (totalTokens < maxHistoryTokens) return { compressed: false };

    const toCompress = this.history.slice(0, -keepRecent);
    const toKeep = this.history.slice(-keepRecent);

    const summaryPrompt = `Summarize the following conversation concisely. Keep key decisions, code context, and important details. Output only the summary:\n\n` +
      toCompress.map(m => `${m.role}: ${m.content.substring(0, 500)}`).join('\n\n');

    try {
      const result = await this.callLLM([{ role: 'user', content: summaryPrompt }], { max_tokens: 500 });
      if (result.content) {
        this.history = [
          { role: 'system', content: `[Previous conversation summary]\n${result.content}` },
          ...toKeep,
        ];
        return { compressed: true, summary: result.content };
      }
    } catch {
      this.history = toKeep;
    }
    return { compressed: false };
  }

  // Ghost text completion
  async getInlineCompletion(codeBeforeCursor, codeAfterCursor, language, fileName) {
    if (!this.apiKey) return null;

    const prompt = `You are a code completion AI. Complete the code at the cursor position. Only output the completion text, nothing else. No explanations, no markdown, no code fences.

File: ${fileName} (${language})

Code before cursor:
${codeBeforeCursor.slice(-500)}

Code after cursor:
${codeAfterCursor.slice(0, 200)}

Complete from the cursor position:`;

    try {
      const result = await this.callLLM(
        [{ role: 'user', content: prompt }],
        { max_tokens: 100, temperature: 0.2 }
      );

      if (result.content) {
        let text = result.content;
        text = text.replace(/^```\w*\n?/, '').replace(/\n?```$/, '').trim();
        return text || null;
      }
    } catch {
      return null;
    }
    return null;
  }

  // Code validation context
  async getValidationContext(filePath) {
    if (!filePath || !window.fileTree?.rootPath) return '';
    try {
      const results = await window.api.runValidation(window.fileTree.rootPath, filePath);
      if (!results || results.length === 0) return '';
      const summary = results.slice(0, 10).map(r =>
        `  ${r.type}: Line ${r.line} - ${r.message}${r.rule ? ` (${r.rule})` : ''}`
      ).join('\n');
      return `\n## Code Issues (${results.length} found)\n${summary}\n`;
    } catch {
      return '';
    }
  }

  // Fetch available models from the API
  async fetchModels() {
    try {
      const result = await window.api.aiFetchModels({
        provider: 'local',
        url: `${this.apiUrl}/v1/models`,
        headers: this.apiKey ? { 'Authorization': `Bearer ${this.apiKey}` } : {},
      });
      if (result.data) {
        return result.data.map(m => ({ id: m.id, name: m.id }));
      }
      return [];
    } catch {
      return [];
    }
  }

  // Estimate tokens (conservative: ~3 chars/token for mixed ko/en/code)
  estimateTokens(text) {
    return Math.ceil(text.length / 3) + 1;
  }

  /**
   * Measure comfortable num_ctx by progressively testing larger contexts.
   * Sends a fixed prompt with varying num_ctx, measures response time.
   * Stops when: error, timeout, or speed drops below threshold.
   *
   * @param {function} onProgress - (step, totalSteps, {numCtx, timeMs, tokPerSec, status})
   * @param {object} opts - { maxTimeMs: 15000, comfortThresholdMs: 8000 }
   * @returns {{ comfortable: number, maximum: number, results: [] }}
   */
  async measureComfortableCtx(onProgress, opts = {}) {
    const maxTimeMs = opts.maxTimeMs || 30000;
    const comfortMs = opts.comfortThresholdMs || 8000;

    const testSizes = [2048, 4096, 8192, 16384, 24576, 32768, 49152, 65536, 98304, 131072, 196608, 262144];
    const results = [];
    let comfortable = 2048;
    let maximum = 2048;
    let aborted = false;

    const fillerLine = 'const x = Math.floor(Math.random() * 100); // padding line\n';

    // Debug log
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    const logFile = `measure_${ts}.log`;
    const log = (msg) => window.api.debugLogAppend(logFile, msg);
    await log(`=== Measure Start: ${new Date().toISOString()} ===`);
    await log(`Model: ${this.model} | API: ${this.apiUrl} | maxTime: ${maxTimeMs}ms | comfortMs: ${comfortMs}ms`);

    for (let i = 0; i < testSizes.length; i++) {
      if (aborted) break;
      const numCtx = testSizes[i];

      // Build a prompt that fills ~70% of numCtx
      const targetChars = Math.floor(numCtx * 0.7) * 3;
      let filler = '';
      while (filler.length < targetChars) filler += fillerLine;
      filler = filler.substring(0, targetChars);
      const testPrompt = `Respond with only "OK". Ignore the padding below.\n\n${filler}`;

      const step = { numCtx, timeMs: 0, tokPerSec: 0, status: 'testing' };
      if (onProgress) onProgress(i, testSizes.length, step);

      await log(`\n[${i+1}/${testSizes.length}] num_ctx=${numCtx} (${(numCtx/1024).toFixed(0)}K) promptChars=${testPrompt.length}`);

      const startTime = Date.now();
      try {
        const reqBody = {
          model: this.model,
          messages: [{ role: 'user', content: testPrompt }],
          stream: false,
          max_tokens: 8,
          temperature: 0,
          options: { num_ctx: numCtx, num_predict: 8, repeat_penalty: 1.0 },
        };

        await log(`  REQ: POST ${this.apiUrl}/v1/chat/completions body.options=${JSON.stringify(reqBody.options)}`);

        const result = await window.api.aiRequest({
          provider: 'local',
          url: `${this.apiUrl}/v1/chat/completions`,
          headers: { 'Authorization': `Bearer ${this.apiKey}` },
          body: reqBody,
          timeout: maxTimeMs + 5000,
        });

        const elapsed = Date.now() - startTime;
        step.timeMs = elapsed;

        // Log raw response (truncated)
        const resPreview = JSON.stringify(result).substring(0, 300);
        await log(`  RES: ${elapsed}ms | ${resPreview}`);

        // Validate response
        if (result.error) {
          const errMsg = result.error.message || (typeof result.error === 'string' ? result.error : JSON.stringify(result.error));
          throw new Error(errMsg);
        }
        if (!result.choices || !result.choices[0]) {
          throw new Error('No choices in response: ' + JSON.stringify(result).substring(0, 150));
        }

        // Log usage if available
        if (result.usage) {
          await log(`  USAGE: prompt=${result.usage.prompt_tokens} completion=${result.usage.completion_tokens} total=${result.usage.total_tokens}`);
        }

        // Estimate prompt eval speed
        const inputTokens = this.estimateTokens(testPrompt);
        step.tokPerSec = elapsed > 0 ? Math.round(inputTokens / (elapsed / 1000)) : 0;

        if (elapsed > maxTimeMs) {
          step.status = 'timeout';
          await log(`  → TIMEOUT (${elapsed}ms > ${maxTimeMs}ms)`);
          results.push({ ...step });
          if (onProgress) onProgress(i, testSizes.length, step);
          aborted = true;
          break;
        }

        if (elapsed <= comfortMs) {
          step.status = 'comfortable';
          comfortable = numCtx;
          await log(`  → COMFORTABLE (${elapsed}ms ≤ ${comfortMs}ms) ${step.tokPerSec} tok/s`);
        } else {
          step.status = 'slow';
          await log(`  → SLOW (${elapsed}ms > ${comfortMs}ms) ${step.tokPerSec} tok/s`);
        }
        maximum = numCtx;

        results.push({ ...step });
        if (onProgress) onProgress(i, testSizes.length, step);

      } catch (e) {
        step.timeMs = Date.now() - startTime;
        step.status = 'error';
        step.error = e.message || e.toString();
        await log(`  → ERROR (${step.timeMs}ms): ${step.error}`);
        results.push({ ...step });
        if (onProgress) onProgress(i, testSizes.length, step);
        aborted = true;
        break;
      }
    }

    await log(`\n=== Result: comfortable=${comfortable} (${(comfortable/1024).toFixed(0)}K) maximum=${maximum} (${(maximum/1024).toFixed(0)}K) ===`);
    return { comfortable, maximum, results };
  }
}

window.aiService = new AIService();
