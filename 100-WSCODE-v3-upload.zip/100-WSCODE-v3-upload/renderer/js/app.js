/**
 * Main Application - Initialization & Event Wiring
 */

(async function () {
  // ─── Load settings ───
  const settings = await window.api.loadSettings();
  if (settings.apiUrl) window.aiService.setApiUrl(settings.apiUrl);
  if (settings.apiKey) window.aiService.setApiKey(settings.apiKey);
  if (settings.modelName) window.aiService.setModel(settings.modelName);
  if (settings.systemPrompt) window.aiService.setSystemPrompt(settings.systemPrompt);

  // Populate settings modal
  if (settings.apiUrl) document.getElementById('set-api-url').value = settings.apiUrl;
  if (settings.apiKey) document.getElementById('set-api-key').value = settings.apiKey;
  if (settings.modelName) document.getElementById('set-model-name').value = settings.modelName;
  if (settings.systemPrompt) document.getElementById('set-system-prompt').value = settings.systemPrompt;
  if (settings.fontSize) document.getElementById('set-font-size').value = settings.fontSize;
  if (settings.autoSave) document.getElementById('set-autosave').value = settings.autoSave;
  if (settings.theme) document.getElementById('set-theme').value = settings.theme;
  if (settings.theme === 'light') document.body.classList.add('light');

  // ─── Init Monaco Editor ───
  await window.editorManager.init();
  if (settings.fontSize) window.editorManager.setFontSize(parseInt(settings.fontSize));

  // ─── Init AI Panel ───
  window.aiPanel.init();

  // ─── Window Controls ───
  document.getElementById('btn-minimize').addEventListener('click', () => window.api.windowMinimize());
  document.getElementById('btn-maximize').addEventListener('click', () => window.api.windowMaximize());
  document.getElementById('btn-close').addEventListener('click', () => window.api.windowClose());

  // ─── Activity Bar ───
  const actIcons = document.querySelectorAll('.act-icon[data-panel]');
  actIcons.forEach(icon => {
    icon.addEventListener('click', () => {
      const panel = icon.dataset.panel;

      if (panel === 'ai') {
        toggleAiPanel();
        // Keep active state but don't affect sidebar
        actIcons.forEach(i => {
          if (i.dataset.panel !== 'ai') return;
          i.classList.toggle('active');
        });
        return;
      }

      // Toggle sidebar panels
      const wasActive = icon.classList.contains('active');

      actIcons.forEach(i => {
        if (i.dataset.panel === 'ai') return;
        i.classList.remove('active');
      });

      document.querySelectorAll('.sidebar-panel').forEach(p => p.classList.remove('active'));

      if (!wasActive) {
        icon.classList.add('active');
        const panelEl = document.getElementById(`panel-${panel}`);
        if (panelEl) panelEl.classList.add('active');
        document.getElementById('sidebar').style.display = 'flex';
      } else {
        document.getElementById('sidebar').style.display = 'none';
      }
    });
  });

  function toggleAiPanel() {
    const aiPanel = document.getElementById('ai-panel');
    const resizeAi = document.querySelector('.resize-ai');
    aiPanel.classList.toggle('hidden');
    resizeAi.style.display = aiPanel.classList.contains('hidden') ? 'none' : 'block';
  }

  // ─── Open Folder ───
  let allFiles = []; // Quick Open file cache (declared early for folder button handlers)
  document.getElementById('btn-open-folder').addEventListener('click', () => { allFiles = []; window.fileTree.openFolder(); });
  document.getElementById('btn-open-folder-big').addEventListener('click', () => { allFiles = []; window.fileTree.openFolder(); });

  // ─── New File ───
  document.getElementById('btn-new-file').addEventListener('click', () => {
    window.editorManager.createUntitledFile();
  });

  // ─── Menu items ───
  document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
      const menu = item.dataset.menu;
      if (menu === 'file') {
        // Could show dropdown; for now handle shortcuts
      }
    });
  });

  // ─── Bottom Panel Tabs ───
  document.querySelectorAll('.panel-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel-body').forEach(b => b.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.dataset.tab;
      const bodyEl = document.getElementById(
        target === 'terminal' ? 'terminal-placeholder' :
        target === 'output' ? 'output-content' : 'problems-content'
      );
      if (bodyEl) bodyEl.classList.add('active');
    });
  });

  document.getElementById('btn-panel-close').addEventListener('click', () => {
    document.getElementById('bottom-panel').classList.toggle('hidden');
  });

  // ─── Multi Terminal Manager ───
  const terminalInstances = new Map(); // id -> { xterm, fitAddon, containerId }
  let activeTerminalId = null;
  let terminalCounter = 0;
  // xterm is loaded via <script> tags in HTML — available as globals
  const TerminalClass = window.Terminal;
  const FitAddonClass = window.FitAddon?.FitAddon || window.FitAddon;

  async function createTerminal() {
    if (!TerminalClass) { console.error('xterm not loaded'); return; }

    terminalCounter++;
    const id = terminalCounter;
    const containerId = `terminal-panel-${id}`;

    // Create container
    const panelsEl = document.getElementById('terminal-panels');
    // Hide all other panels
    panelsEl.querySelectorAll('.terminal-instance').forEach(el => el.style.display = 'none');

    const containerEl = document.createElement('div');
    containerEl.id = containerId;
    containerEl.className = 'terminal-instance';
    containerEl.style.cssText = 'height:100%;display:block;';
    panelsEl.appendChild(containerEl);

    // Create xterm
    const xterm = new TerminalClass({
      cursorBlink: true,
      fontSize: 13,
      fontFamily: "'Consolas', 'Courier New', monospace",
      theme: { background: '#1e1e1e', foreground: '#d4d4d4', cursor: '#d4d4d4', selectionBackground: '#264f78' },
      allowProposedApi: true,
      rightClickSelectsWord: true,
    });

    const fitAddon = new FitAddonClass();
    xterm.loadAddon(fitAddon);
    xterm.open(containerEl);
    try { fitAddon.fit(); } catch {}

    // Create backend process
    const cwd = window.fileTree.rootPath || undefined;
    const result = await window.api.terminalCreate({ cwd });
    const backendId = result.id;

    // Ctrl+C copy / Ctrl+V paste / right-click copy
    xterm.attachCustomKeyEventHandler((e) => {
      if (e.ctrlKey && e.key === 'c' && xterm.hasSelection()) {
        navigator.clipboard.writeText(xterm.getSelection());
        return false;
      }
      if (e.ctrlKey && e.key === 'v') {
        navigator.clipboard.readText().then(text => {
          if (text) window.api.terminalWrite(backendId, text);
        });
        return false;
      }
      return true;
    });

    // Store instance
    terminalInstances.set(id, { xterm, fitAddon, containerId, backendId, name: `Terminal ${id}` });

    // Pipe xterm input to backend
    xterm.onData((data) => {
      window.api.terminalWrite(backendId, data);
    });

    // Fit on resize + sync PTY size
    xterm.onResize(({ cols, rows }) => {
      window.api.terminalResize(backendId, cols, rows);
    });
    const resizeObserver = new ResizeObserver(() => {
      try { fitAddon.fit(); } catch {}
    });
    resizeObserver.observe(containerEl);

    // Set active and render tabs
    activeTerminalId = id;
    renderTerminalTabs();
    xterm.focus();

    return id;
  }

  function switchTerminal(id) {
    if (!terminalInstances.has(id)) return;
    activeTerminalId = id;

    const panelsEl = document.getElementById('terminal-panels');
    panelsEl.querySelectorAll('.terminal-instance').forEach(el => el.style.display = 'none');

    const inst = terminalInstances.get(id);
    const el = document.getElementById(inst.containerId);
    if (el) el.style.display = 'block';

    try { inst.fitAddon.fit(); } catch {}
    inst.xterm.focus();
    renderTerminalTabs();
  }

  function closeTerminal(id) {
    const inst = terminalInstances.get(id);
    if (!inst) return;

    window.api.terminalKill(inst.backendId);
    inst.xterm.dispose();
    const el = document.getElementById(inst.containerId);
    if (el) el.remove();
    terminalInstances.delete(id);

    if (activeTerminalId === id) {
      const remaining = [...terminalInstances.keys()];
      if (remaining.length > 0) {
        switchTerminal(remaining[remaining.length - 1]);
      } else {
        activeTerminalId = null;
        renderTerminalTabs();
      }
    } else {
      renderTerminalTabs();
    }
  }

  function renderTerminalTabs() {
    const tabsList = document.getElementById('terminal-tabs-list');
    if (!tabsList) return;
    tabsList.innerHTML = '';

    for (const [id, inst] of terminalInstances) {
      const tab = document.createElement('div');
      tab.style.cssText = `display:flex;align-items:center;gap:4px;padding:2px 8px;font-size:11px;cursor:pointer;color:${id === activeTerminalId ? '#fff' : '#888'};background:${id === activeTerminalId ? '#1e1e1e' : 'transparent'};border-radius:3px 3px 0 0;white-space:nowrap;`;
      tab.innerHTML = `<span>${inst.name}</span><span class="term-tab-close" style="font-size:12px;opacity:0.5;cursor:pointer;">&times;</span>`;
      tab.querySelector('span').addEventListener('click', () => switchTerminal(id));
      tab.querySelector('.term-tab-close').addEventListener('click', (e) => { e.stopPropagation(); closeTerminal(id); });
      tabsList.appendChild(tab);
    }
  }

  // Wire up terminal data routing
  window.api.onTerminalData(({ id: backendId, data }) => {
    for (const [, inst] of terminalInstances) {
      if (inst.backendId === backendId) {
        inst.xterm.write(data);
        break;
      }
    }
  });

  window.api.onTerminalExit(({ id: backendId, code }) => {
    for (const [termId, inst] of terminalInstances) {
      if (inst.backendId === backendId) {
        inst.xterm.write(`\r\n[Process exited with code ${code}]\r\n`);
        break;
      }
    }
  });

  // New terminal button
  document.getElementById('btn-new-terminal')?.addEventListener('click', () => createTerminal());

  // Init first terminal on panel show
  document.querySelector('.panel-tab[data-tab="terminal"]')?.addEventListener('click', () => {
    if (terminalInstances.size === 0) setTimeout(createTerminal, 100);
  });

  const bottomPanel = document.getElementById('bottom-panel');
  const panelObserver = new MutationObserver(() => {
    if (!bottomPanel.classList.contains('hidden') && terminalInstances.size === 0) {
      setTimeout(createTerminal, 100);
    }
    // Refit active terminal
    if (activeTerminalId && terminalInstances.has(activeTerminalId)) {
      try { terminalInstances.get(activeTerminalId).fitAddon.fit(); } catch {}
    }
  });
  panelObserver.observe(bottomPanel, { attributes: true, attributeFilter: ['class'] });

  // ─── Settings Modal ───
  document.getElementById('btn-settings').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.remove('hidden');
  });

  document.getElementById('btn-ai-settings').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.remove('hidden');
  });

  document.getElementById('btn-settings-close').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.add('hidden');
  });

  document.getElementById('settings-modal').addEventListener('click', (e) => {
    if (e.target.id === 'settings-modal') {
      document.getElementById('settings-modal').classList.add('hidden');
    }
  });

  document.getElementById('btn-save-settings').addEventListener('click', async () => {
    const newSettings = {
      apiUrl: document.getElementById('set-api-url').value,
      apiKey: document.getElementById('set-api-key').value,
      modelName: document.getElementById('set-model-name').value,
      systemPrompt: document.getElementById('set-system-prompt').value,
      fontSize: document.getElementById('set-font-size').value,
      autoSave: document.getElementById('set-autosave').value,
      theme: document.getElementById('set-theme').value,
    };

    await window.api.saveSettings(newSettings);

    window.aiService.setApiUrl(newSettings.apiUrl);
    window.aiService.setApiKey(newSettings.apiKey);
    window.aiService.setModel(newSettings.modelName);
    window.aiService.setSystemPrompt(newSettings.systemPrompt);
    if (newSettings.fontSize) window.editorManager.setFontSize(parseInt(newSettings.fontSize));
    setupAutoSave(newSettings.autoSave);

    document.body.classList.toggle('light', newSettings.theme === 'light');
    if (window.editorManager.editor) {
      monaco.editor.setTheme(newSettings.theme === 'light' ? 'vs' : 'vs-dark');
    }

    document.getElementById('settings-modal').classList.add('hidden');
  });

  // ─── Context Budget Modal ───
  const cbModal = document.getElementById('context-budget-modal');

  // Load saved budget from settings
  if (settings.contextBudget) {
    window.aiService.budget.loadFrom(settings.contextBudget);
  }

  function cbUpdateUI() {
    const b = window.aiService.budget;
    document.getElementById('cb-num-ctx').value = b.numCtx;
    document.getElementById('cb-num-ctx-k').textContent = (b.numCtx / 1024).toFixed(0) + 'K';
    document.getElementById('cb-system').value = b.system;
    document.getElementById('cb-project').value = b.project;
    document.getElementById('cb-history').value = b.history;
    document.getElementById('cb-query').value = b.query;
    document.getElementById('cb-response').value = b.response;
    document.getElementById('cb-num-predict').value = b.numPredict;
    document.getElementById('cb-temperature').value = b.temperature;
    document.getElementById('cb-repeat-penalty').value = b.repeatPenalty;
    document.getElementById('cb-compress-msgs').value = b.compressAfterMsgs;
    document.getElementById('cb-keep-recent').value = b.keepRecentMsgs;

    // Update percentages
    ['system', 'project', 'history', 'query', 'response'].forEach(slot => {
      document.getElementById(`cb-${slot}-pct`).textContent = b.pct(slot) + '%';
    });

    // Update bar
    const bar = document.getElementById('cb-budget-bar');
    bar.querySelector('.cb-seg-system').style.flex = b.pct('system') || 1;
    bar.querySelector('.cb-seg-project').style.flex = b.pct('project') || 1;
    bar.querySelector('.cb-seg-history').style.flex = b.pct('history') || 1;
    bar.querySelector('.cb-seg-query').style.flex = b.pct('query') || 1;
    bar.querySelector('.cb-seg-response').style.flex = b.pct('response') || 1;

    // Total check
    const totalEl = document.getElementById('cb-total');
    const total = b.total;
    totalEl.textContent = `${total.toLocaleString()} / ${b.numCtx.toLocaleString()}`;
    totalEl.classList.toggle('over', total > b.numCtx);
  }

  // Open modal
  document.getElementById('btn-context-budget').addEventListener('click', () => {
    cbUpdateUI();
    cbModal.classList.remove('hidden');
  });

  // Close
  document.getElementById('btn-cb-close').addEventListener('click', () => {
    cbModal.classList.add('hidden');
  });
  cbModal.addEventListener('click', (e) => {
    if (e.target === cbModal) cbModal.classList.add('hidden');
  });

  // Preset change → recalculate
  document.getElementById('cb-preset').addEventListener('change', (e) => {
    const key = e.target.value;
    if (key === 'custom') return;
    const preset = CONTEXT_BUDGET_PRESETS[key];
    if (preset) {
      window.aiService.budget.recalcFromCtx(preset.numCtx);
      cbUpdateUI();
    }
  });

  // num_ctx manual change → recalculate
  document.getElementById('cb-num-ctx').addEventListener('change', (e) => {
    const val = parseInt(e.target.value) || 24576;
    window.aiService.budget.recalcFromCtx(val);
    document.getElementById('cb-preset').value = 'custom';
    cbUpdateUI();
  });

  // Individual budget field changes → update total/bar (custom mode)
  ['cb-system', 'cb-project', 'cb-history', 'cb-query', 'cb-response'].forEach(id => {
    document.getElementById(id).addEventListener('change', (e) => {
      const slot = id.replace('cb-', '');
      window.aiService.budget[slot] = parseInt(e.target.value) || 0;
      document.getElementById('cb-preset').value = 'custom';
      cbUpdateUI();
    });
  });

  // Measure comfortable num_ctx
  let measureRunning = false;
  document.getElementById('btn-cb-measure').addEventListener('click', async () => {
    if (measureRunning) return;
    if (!window.aiService.apiUrl || !window.aiService.model) {
      alert('LLM API URL and Model must be configured first.');
      return;
    }

    measureRunning = true;
    const btn = document.getElementById('btn-cb-measure');
    const area = document.getElementById('cb-measure-area');
    const statusEl = document.getElementById('cb-measure-status');
    const progressEl = document.getElementById('cb-measure-progress');
    const resultsEl = document.getElementById('cb-measure-results');

    btn.textContent = 'Testing...';
    btn.disabled = true;
    area.classList.remove('hidden');
    resultsEl.innerHTML = '';
    statusEl.textContent = `Benchmarking ${window.aiService.model}...`;
    progressEl.style.width = '0%';

    const statusColors = {
      probing: '#5e81ac',
      comfortable: '#a3be8c',
      slow: '#ebcb8b',
      timeout: '#d08770',
      error: '#bf616a',
      testing: '#888',
    };
    const statusLabels = {
      probing: 'Detecting API...',
      comfortable: 'Comfortable',
      slow: 'Slow',
      timeout: 'Timeout',
      error: 'Error',
      testing: 'Testing...',
    };

    try {
      const result = await window.aiService.measureComfortableCtx(
        (step, total, data) => {
          const pct = Math.round(((step + 1) / total) * 100);
          progressEl.style.width = pct + '%';

          const sizeK = (data.numCtx / 1024).toFixed(0) + 'K';
          const color = statusColors[data.status] || '#888';
          const label = statusLabels[data.status] || data.status;
          const timeStr = data.timeMs ? (data.timeMs / 1000).toFixed(1) + 's' : '-';
          const speedStr = data.tokPerSec ? data.tokPerSec.toLocaleString() + ' tok/s' : '-';

          statusEl.textContent = `Testing num_ctx=${sizeK}... (${step + 1}/${total})`;

          if (data.status !== 'testing') {
            resultsEl.innerHTML += `<div style="display:flex;justify-content:space-between;padding:3px 8px;border-radius:2px;margin-bottom:2px;background:rgba(255,255,255,.03);">
              <span style="color:${color};font-weight:600;min-width:50px;">${sizeK}</span>
              <span style="color:#aaa;">${timeStr}</span>
              <span style="color:#aaa;">${speedStr}</span>
              <span style="color:${color};">${label}${data.error ? ' — ' + data.error.substring(0, 40) : ''}</span>
            </div>`;
            resultsEl.scrollTop = resultsEl.scrollHeight;
          }
        }
      );

      // Show final result
      const comfK = (result.comfortable / 1024).toFixed(0) + 'K';
      const maxK = (result.maximum / 1024).toFixed(0) + 'K';
      progressEl.style.width = '100%';
      progressEl.style.background = '#a3be8c';
      statusEl.innerHTML = `Comfortable: <b style="color:#a3be8c;">${comfK}</b> (${result.comfortable.toLocaleString()} tokens) &nbsp;|&nbsp; Max tested: <b style="color:#ebcb8b;">${maxK}</b>`;

      // Auto-apply comfortable value
      window.aiService.budget.recalcFromCtx(result.comfortable);
      document.getElementById('cb-preset').value = 'custom';
      cbUpdateUI();

    } catch (e) {
      statusEl.textContent = 'Benchmark failed: ' + e.toString();
      progressEl.style.background = '#bf616a';
    }

    btn.textContent = 'Measure';
    btn.disabled = false;
    measureRunning = false;
  });

  // Save budget
  document.getElementById('btn-cb-save').addEventListener('click', async () => {
    const b = window.aiService.budget;
    b.numPredict = parseInt(document.getElementById('cb-num-predict').value) || 2048;
    b.temperature = parseFloat(document.getElementById('cb-temperature').value) || 0.3;
    b.repeatPenalty = parseFloat(document.getElementById('cb-repeat-penalty').value) || 1.1;
    b.compressAfterMsgs = parseInt(document.getElementById('cb-compress-msgs').value) || 8;
    b.keepRecentMsgs = parseInt(document.getElementById('cb-keep-recent').value) || 4;

    // Persist to settings
    const currentSettings = await window.api.loadSettings();
    currentSettings.contextBudget = b.toJSON();
    await window.api.saveSettings(currentSettings);

    cbModal.classList.add('hidden');
    if (window.aiPanel) {
      window.aiPanel.addSystemMessage(
        `Context budget applied: ${b.numCtx.toLocaleString()} tokens ` +
        `(History ${b.history.toLocaleString()}, Response ${b.response.toLocaleString()})`
      );
    }
  });

  // ─── Resize Handles ───
  setupResize('.resize-sidebar', 'sidebar', 'width', 120, 500);
  setupResize('.resize-ai', 'ai-panel', 'width', 250, 700, true);
  setupResizeVertical('.resize-panel-h', 'bottom-panel', 100, 500);

  function setupResize(handleSel, targetId, prop, min, max, reverse) {
    const handle = document.querySelector(handleSel);
    const target = document.getElementById(targetId);
    if (!handle || !target) return;

    let startX, startW;
    handle.addEventListener('mousedown', (e) => {
      startX = e.clientX;
      startW = target.offsetWidth;
      handle.classList.add('active');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      const onMove = (e) => {
        const diff = reverse ? startX - e.clientX : e.clientX - startX;
        const newW = Math.min(max, Math.max(min, startW + diff));
        target.style.width = newW + 'px';
      };
      const onUp = () => {
        handle.classList.remove('active');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function setupResizeVertical(handleSel, targetId, min, max) {
    const handle = document.querySelector(handleSel);
    const target = document.getElementById(targetId);
    if (!handle || !target) return;

    let startY, startH;
    handle.addEventListener('mousedown', (e) => {
      startY = e.clientY;
      startH = target.offsetHeight;
      handle.classList.add('active');
      document.body.style.cursor = 'row-resize';
      document.body.style.userSelect = 'none';

      const onMove = (e) => {
        const diff = startY - e.clientY;
        const newH = Math.min(max, Math.max(min, startH + diff));
        target.style.height = newH + 'px';
      };
      const onUp = () => {
        handle.classList.remove('active');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  // ─── Panel Activation Helper ───
  function activatePanel(panelName) {
    document.querySelectorAll('.act-icon[data-panel]').forEach(i => {
      if (i.dataset.panel === 'ai') return;
      i.classList.toggle('active', i.dataset.panel === panelName);
    });
    document.querySelectorAll('.sidebar-panel').forEach(p => p.classList.remove('active'));
    const panelEl = document.getElementById(`panel-${panelName}`);
    if (panelEl) panelEl.classList.add('active');
    document.getElementById('sidebar').style.display = 'flex';
  }

  // ─── Search in Files ───
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  let searchTimeout = null;

  const regexToggle = document.getElementById('regex-toggle');
  const caseToggle = document.getElementById('case-toggle');
  const searchRegex = document.getElementById('search-regex');
  const searchCase = document.getElementById('search-case');

  regexToggle.addEventListener('click', () => {
    searchRegex.checked = !searchRegex.checked;
    regexToggle.classList.toggle('active', searchRegex.checked);
    searchInput.dispatchEvent(new Event('input'));
  });
  caseToggle.addEventListener('click', () => {
    searchCase.checked = !searchCase.checked;
    caseToggle.classList.toggle('active', searchCase.checked);
    searchInput.dispatchEvent(new Event('input'));
  });

  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    const query = searchInput.value.trim();
    if (query.length < 2) {
      searchResults.innerHTML = '<div style="padding:8px; color:#888; font-size:12px;">Type at least 2 characters</div>';
      return;
    }
    searchResults.innerHTML = '<div style="padding:8px; color:#888; font-size:12px;">Searching...</div>';
    searchTimeout = setTimeout(() => performSearch(query, {
      regex: searchRegex.checked,
      caseSensitive: searchCase.checked,
    }), 300);
  });

  async function performSearch(query, options) {
    if (!window.fileTree.rootPath) {
      searchResults.innerHTML = '<div style="padding:8px; color:#888; font-size:12px;">Open a folder first</div>';
      return;
    }
    const results = await window.api.searchInFiles(window.fileTree.rootPath, query, options);
    if (results.error) {
      searchResults.innerHTML = `<div style="padding:8px; color:#f85149; font-size:12px;">Error: ${results.error}</div>`;
      return;
    }
    if (results.length === 0) {
      searchResults.innerHTML = '<div style="padding:8px; color:#888; font-size:12px;">No results found</div>';
      return;
    }

    // Group by file
    const grouped = {};
    for (const r of results.slice(0, 200)) {
      if (!grouped[r.relativePath]) grouped[r.relativePath] = [];
      grouped[r.relativePath].push(r);
    }

    let html = `<div style="padding:4px 12px; font-size:11px; color:#888;">${results.length} results in ${Object.keys(grouped).length} files</div>`;
    for (const [relPath, matches] of Object.entries(grouped)) {
      html += `<div class="search-file-header">${relPath} (${matches.length})</div>`;
      for (const m of matches.slice(0, 10)) {
        const escaped = m.lineContent.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        let highlightPattern;
        if (options && options.regex) {
          try { highlightPattern = new RegExp(query, options.caseSensitive ? 'g' : 'gi'); } catch { highlightPattern = null; }
        } else {
          highlightPattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), options?.caseSensitive ? 'g' : 'gi');
        }
        const highlighted = highlightPattern ? escaped.replace(highlightPattern, '<span class="search-match-text">$&</span>') : escaped;
        html += `<div class="search-match" data-path="${m.filePath}" data-line="${m.lineNumber}">
          <span class="search-line-num">${m.lineNumber}</span>${highlighted}
        </div>`;
      }
    }
    searchResults.innerHTML = html;

    searchResults.querySelectorAll('.search-match').forEach(el => {
      el.addEventListener('click', () => {
        const filePath = el.dataset.path;
        const line = parseInt(el.dataset.line);
        const name = filePath.split(/[/\\]/).pop();
        window.editorManager.openFile(filePath, name).then(() => {
          setTimeout(() => {
            if (window.editorManager.editor) {
              window.editorManager.editor.revealLineInCenter(line);
              window.editorManager.editor.setPosition({ lineNumber: line, column: 1 });
              window.editorManager.editor.focus();
            }
          }, 100);
        });
      });
    });
  }

  // Replace All button
  document.getElementById('btn-replace-all').addEventListener('click', async () => {
    const replaceText = document.getElementById('replace-input').value;
    const query = searchInput.value.trim();
    if (!query || !window.fileTree.rootPath) return;

    const results = await window.api.searchInFiles(window.fileTree.rootPath, query, {
      regex: searchRegex.checked,
      caseSensitive: searchCase.checked,
    });
    if (results.error || results.length === 0) return;

    // Group by file
    const fileSet = new Set(results.map(r => r.filePath));
    let replacedCount = 0;

    for (const filePath of fileSet) {
      const content = await window.api.readFile(filePath);
      if (!content || content.error) continue;

      let newContent;
      if (searchRegex.checked) {
        try {
          const flags = searchCase.checked ? 'gm' : 'gim';
          const re = new RegExp(query, flags);
          newContent = content.replace(re, replaceText);
        } catch { continue; }
      } else {
        const flags = searchCase.checked ? 'g' : 'gi';
        const re = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
        newContent = content.replace(re, replaceText);
      }

      if (newContent !== content) {
        await window.api.writeFile(filePath, newContent);
        replacedCount++;
      }
    }

    searchResults.innerHTML = `<div style="padding:8px; color:#4ec9b0; font-size:12px;">Replaced in ${replacedCount} files. Re-searching...</div>`;
    setTimeout(() => performSearch(searchInput.value.trim(), {
      regex: searchRegex.checked,
      caseSensitive: searchCase.checked,
    }), 500);
  });

  // ─── Command Palette ───
  const paletteOverlay = document.getElementById('command-palette');
  const paletteInput = document.getElementById('palette-input');
  const paletteResults = document.getElementById('palette-results');
  let paletteSelectedIdx = 0;

  const commands = [
    { label: 'New File', shortcut: 'Ctrl+N', action: () => window.editorManager.createUntitledFile() },
    { label: 'Open File', shortcut: 'Ctrl+O', action: () => openFileFromDialog() },
    { label: 'Open Folder', shortcut: 'Ctrl+K Ctrl+O', action: () => window.fileTree.openFolder() },
    { label: 'Save File', shortcut: 'Ctrl+S', action: () => window.editorManager.saveCurrentFile() },
    { label: 'Toggle Sidebar', shortcut: 'Ctrl+B', action: () => { const sb = document.getElementById('sidebar'); sb.style.display = sb.style.display === 'none' ? 'flex' : 'none'; }},
    { label: 'Toggle Terminal', shortcut: 'Ctrl+`', action: () => document.getElementById('bottom-panel').classList.toggle('hidden') },
    { label: 'Toggle AI Panel', shortcut: 'Ctrl+Shift+I', action: () => toggleAiPanel() },
    { label: 'Quick Open File', shortcut: 'Ctrl+P', action: () => openQuickOpen() },
    { label: 'Search in Files', shortcut: 'Ctrl+Shift+F', action: () => { activatePanel('search'); searchInput.focus(); }},
    { label: 'Explorer', shortcut: 'Ctrl+Shift+E', action: () => activatePanel('explorer') },
    { label: 'Format Document', action: () => { if (window.editorManager.editor) window.editorManager.editor.getAction('editor.action.formatDocument')?.run(); }},
    { label: 'Toggle Word Wrap', action: () => { if (window.editorManager.editor) { const curr = window.editorManager.editor.getOption(monaco.editor.EditorOption.wordWrap); window.editorManager.editor.updateOptions({ wordWrap: curr === 'off' ? 'on' : 'off' }); }}},
    { label: 'Toggle Minimap', action: () => { if (window.editorManager.editor) { const curr = window.editorManager.editor.getOption(monaco.editor.EditorOption.minimap).enabled; window.editorManager.editor.updateOptions({ minimap: { enabled: !curr } }); }}},
    { label: 'Zoom In', action: () => { if (window.editorManager.editor) { const size = window.editorManager.editor.getOption(monaco.editor.EditorOption.fontSize); window.editorManager.editor.updateOptions({ fontSize: size + 1 }); }}},
    { label: 'Zoom Out', action: () => { if (window.editorManager.editor) { const size = window.editorManager.editor.getOption(monaco.editor.EditorOption.fontSize); window.editorManager.editor.updateOptions({ fontSize: Math.max(8, size - 1) }); }}},
    { label: 'New Chat', action: () => window.aiPanel.clearChat() },
    { label: 'Settings', action: () => document.getElementById('settings-modal').classList.remove('hidden') },
    { label: 'Split Editor', action: () => window.editorManager.toggleSplit() },
    { label: 'Toggle AI Inline Completions', shortcut: 'Ctrl+I', action: () => {
      const enabled = window.editorManager.toggleInlineCompletions();
      window.aiPanel.addSystemMessage(`AI inline completions ${enabled ? 'enabled' : 'disabled'}`);
    }},
    { label: 'Toggle Theme (Dark/Light)', action: () => {
      const isLight = document.body.classList.toggle('light');
      if (window.editorManager.editor) monaco.editor.setTheme(isLight ? 'vs' : 'vs-dark');
    }},
  ];

  function openCommandPalette() {
    paletteOverlay.classList.remove('hidden');
    paletteInput.value = '';
    paletteSelectedIdx = 0;
    renderPaletteResults(commands);
    paletteInput.focus();
  }

  function closeCommandPalette() {
    paletteOverlay.classList.add('hidden');
  }

  function renderPaletteResults(items) {
    paletteResults.innerHTML = items.map((cmd, i) => `
      <div class="palette-item ${i === paletteSelectedIdx ? 'selected' : ''}" data-idx="${i}">
        <span class="item-label">${cmd.label}</span>
        ${cmd.shortcut ? `<span class="item-shortcut">${cmd.shortcut}</span>` : ''}
      </div>
    `).join('');

    paletteResults.querySelectorAll('.palette-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.idx);
        closeCommandPalette();
        items[idx].action();
      });
      el.addEventListener('mouseenter', () => {
        paletteSelectedIdx = parseInt(el.dataset.idx);
        paletteResults.querySelectorAll('.palette-item').forEach((e, i) => e.classList.toggle('selected', i === paletteSelectedIdx));
      });
    });
  }

  paletteInput.addEventListener('input', () => {
    const query = paletteInput.value.toLowerCase();
    const filtered = commands.filter(c => c.label.toLowerCase().includes(query));
    paletteSelectedIdx = 0;
    renderPaletteResults(filtered);
  });

  paletteInput.addEventListener('keydown', (e) => {
    const items = paletteResults.querySelectorAll('.palette-item');
    if (e.key === 'ArrowDown') { e.preventDefault(); paletteSelectedIdx = Math.min(paletteSelectedIdx + 1, items.length - 1); items.forEach((el, i) => el.classList.toggle('selected', i === paletteSelectedIdx)); items[paletteSelectedIdx]?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); paletteSelectedIdx = Math.max(paletteSelectedIdx - 1, 0); items.forEach((el, i) => el.classList.toggle('selected', i === paletteSelectedIdx)); items[paletteSelectedIdx]?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') { e.preventDefault(); closeCommandPalette(); const query = paletteInput.value.toLowerCase(); const filtered = commands.filter(c => c.label.toLowerCase().includes(query)); if (filtered[paletteSelectedIdx]) filtered[paletteSelectedIdx].action(); }
    else if (e.key === 'Escape') { closeCommandPalette(); }
  });

  paletteOverlay.addEventListener('click', (e) => { if (e.target === paletteOverlay) closeCommandPalette(); });

  // ─── Quick Open ───
  const quickOpenOverlay = document.getElementById('quick-open');
  const quickOpenInput = document.getElementById('quick-open-input');
  const quickOpenResults = document.getElementById('quick-open-results');
  let quickSelectedIdx = 0;

  async function openQuickOpen() {
    quickOpenOverlay.classList.remove('hidden');
    quickOpenInput.value = '';
    quickSelectedIdx = 0;
    quickOpenInput.focus();

    if (window.fileTree.rootPath && allFiles.length === 0) {
      quickOpenResults.innerHTML = '<div class="palette-item disabled"><span class="item-label" style="color:#888">Loading files...</span></div>';
      allFiles = await window.api.listAllFiles(window.fileTree.rootPath);
      if (allFiles.error) allFiles = [];
    }
    renderQuickOpenResults(allFiles.slice(0, 20));
  }

  function closeQuickOpen() {
    quickOpenOverlay.classList.add('hidden');
  }

  function renderQuickOpenResults(items) {
    quickOpenResults.innerHTML = items.map((f, i) => `
      <div class="palette-item ${i === quickSelectedIdx ? 'selected' : ''}" data-idx="${i}">
        <span class="item-icon">${window.editorManager.getFileIconText(f.name.split('.').pop().toLowerCase())}</span>
        <span class="item-label">${f.name}</span>
        <span class="item-detail">${f.relativePath}</span>
      </div>
    `).join('');

    quickOpenResults.querySelectorAll('.palette-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.idx);
        closeQuickOpen();
        window.editorManager.openFile(items[idx].path, items[idx].name);
      });
      el.addEventListener('mouseenter', () => {
        quickSelectedIdx = parseInt(el.dataset.idx);
        quickOpenResults.querySelectorAll('.palette-item').forEach((e, i) => e.classList.toggle('selected', i === quickSelectedIdx));
      });
    });
  }

  quickOpenInput.addEventListener('input', () => {
    const query = quickOpenInput.value.toLowerCase();
    const filtered = query ? allFiles.filter(f => f.name.toLowerCase().includes(query) || f.relativePath.toLowerCase().includes(query)).slice(0, 30) : allFiles.slice(0, 20);
    quickSelectedIdx = 0;
    renderQuickOpenResults(filtered);
  });

  quickOpenInput.addEventListener('keydown', (e) => {
    const items = quickOpenResults.querySelectorAll('.palette-item');
    if (e.key === 'ArrowDown') { e.preventDefault(); quickSelectedIdx = Math.min(quickSelectedIdx + 1, items.length - 1); items.forEach((el, i) => el.classList.toggle('selected', i === quickSelectedIdx)); items[quickSelectedIdx]?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); quickSelectedIdx = Math.max(quickSelectedIdx - 1, 0); items.forEach((el, i) => el.classList.toggle('selected', i === quickSelectedIdx)); items[quickSelectedIdx]?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') { e.preventDefault(); const query = quickOpenInput.value.toLowerCase(); const filtered = query ? allFiles.filter(f => f.name.toLowerCase().includes(query) || f.relativePath.toLowerCase().includes(query)).slice(0, 30) : allFiles.slice(0, 20); if (filtered[quickSelectedIdx]) { closeQuickOpen(); window.editorManager.openFile(filtered[quickSelectedIdx].path, filtered[quickSelectedIdx].name); }}
    else if (e.key === 'Escape') { closeQuickOpen(); }
  });

  quickOpenOverlay.addEventListener('click', (e) => { if (e.target === quickOpenOverlay) closeQuickOpen(); });

  // ─── Auto Save ───
  let autoSaveInterval = null;
  function setupAutoSave(mode) {
    if (autoSaveInterval) clearInterval(autoSaveInterval);
    if (mode === 'afterDelay') {
      autoSaveInterval = setInterval(() => {
        if (window.editorManager.activeTab) {
          const tab = window.editorManager.tabs.get(window.editorManager.activeTab);
          if (tab && tab.modified) window.editorManager.saveCurrentFile();
        }
      }, 1000);
    }
  }
  setupAutoSave(settings.autoSave);

  // ─── Keyboard Shortcuts ───
  document.addEventListener('keydown', (e) => {
    // Ctrl+Shift+P → Command Palette
    if (e.ctrlKey && e.shiftKey && e.key === 'P') {
      e.preventDefault();
      openCommandPalette();
    }
    // Ctrl+P → Quick Open
    if (e.ctrlKey && !e.shiftKey && e.key === 'p') {
      e.preventDefault();
      openQuickOpen();
    }
    // Ctrl+Shift+F → Search in files
    if (e.ctrlKey && e.shiftKey && e.key === 'F') {
      e.preventDefault();
      activatePanel('search');
      searchInput.focus();
    }
    // Ctrl+Shift+E → Explorer
    if (e.ctrlKey && e.shiftKey && e.key === 'E') {
      e.preventDefault();
      activatePanel('explorer');
    }
    // F2 → Rename (focus on file tree)
    // Ctrl+Shift+I → AI Panel toggle
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
      e.preventDefault();
      toggleAiPanel();
    }
    // Ctrl+B → Sidebar toggle
    if (e.ctrlKey && e.key === 'b') {
      e.preventDefault();
      const sb = document.getElementById('sidebar');
      sb.style.display = sb.style.display === 'none' ? 'flex' : 'none';
    }
    // Ctrl+` → Bottom panel toggle
    if (e.ctrlKey && e.key === '`') {
      e.preventDefault();
      document.getElementById('bottom-panel').classList.toggle('hidden');
    }
    // Ctrl+N → New file
    if (e.ctrlKey && e.key === 'n') {
      e.preventDefault();
      window.editorManager.createUntitledFile();
    }
    // Ctrl+O → Open file
    if (e.ctrlKey && !e.shiftKey && e.key === 'o') {
      e.preventDefault();
      openFileFromDialog();
    }
    // Ctrl+\ → Split Editor
    if (e.ctrlKey && e.key === '\\') {
      e.preventDefault();
      window.editorManager.toggleSplit();
    }
    // Ctrl+S → Save
    if (e.ctrlKey && e.key === 's') {
      e.preventDefault();
      window.editorManager.saveCurrentFile();
    }
    // Ctrl+I → Toggle AI inline completions
    if (e.ctrlKey && !e.shiftKey && e.key === 'i') {
      e.preventDefault();
      const enabled = window.editorManager.toggleInlineCompletions();
      if (window.aiPanel) window.aiPanel.addSystemMessage(`AI inline completions ${enabled ? 'enabled' : 'disabled'}`);
    }
  });

  async function openFileFromDialog() {
    const filePath = await window.api.openFileDialog();
    if (filePath) {
      const name = filePath.split(/[/\\]/).pop();
      window.editorManager.openFile(filePath, name);
    }
  }

  // ─── Auto-resize textarea ───
  const aiInput = document.getElementById('ai-input');
  aiInput.addEventListener('input', () => {
    aiInput.style.height = '44px';
    aiInput.style.height = Math.min(aiInput.scrollHeight, 120) + 'px';
  });

})();
