/**
 * AI Copilot Panel - Chat UI, Diff rendering, Apply/Reject
 */

class AIPanel {
  constructor() {
    this.contexts = []; // { type: 'file'|'selection'|'workspace', label, content }
    this.isStreaming = false;
    this.currentChatId = null;
    this.sessionMeta = {
      task: '',
      summary: '',
      keyDecisions: [],
      modifiedFiles: [],
      pendingTasks: [],
    };
  }

  init() {
    this.messagesEl = document.getElementById('ai-messages');
    this.inputEl = document.getElementById('ai-input');
    this.sendBtn = document.getElementById('ai-send-btn');
    this.chipsEl = document.getElementById('ai-context-chips');
    this.tokenInfo = document.getElementById('token-count');

    // @ Autocomplete setup
    this.atPopup = document.getElementById('at-autocomplete');
    this.atSelectedIdx = 0;
    this.atCommands = [
      { cmd: '@file', desc: 'Add current file as context', action: () => this.addCurrentFileContext() },
      { cmd: '@workspace', desc: 'Analyze entire project', action: null },
      { cmd: '@selection', desc: 'Send selected code (Ctrl+L)', action: () => {
        const sel = window.editorManager.editor?.getModel()?.getValueInRange(window.editorManager.editor.getSelection());
        if (sel) this.addContext('selection', sel);
      }},
    ];

    // Send on Enter (but not if @ popup is open)
    this.inputEl.addEventListener('keydown', (e) => {
      if (!this.atPopup.classList.contains('hidden')) {
        if (e.key === 'ArrowDown') { e.preventDefault(); this.atNavigate(1); return; }
        if (e.key === 'ArrowUp') { e.preventDefault(); this.atNavigate(-1); return; }
        if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); this.atSelect(); return; }
        if (e.key === 'Escape') { this.atHide(); return; }
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.send();
      }
    });

    // @ detection on input
    this.inputEl.addEventListener('input', () => {
      this.atDetect();
    });

    this.sendBtn.addEventListener('click', () => this.send());

    this.stopBtn = document.getElementById('btn-stop');
    this.stopBtn.addEventListener('click', () => this.stopGenerating());

    // @ button - add current file context
    document.getElementById('btn-attach').addEventListener('click', () => {
      this.atShow('');
    });

    // AI Help button
    document.getElementById('btn-ai-help').addEventListener('click', () => {
      this.showAiHelp();
    });

    // Chat history button
    document.getElementById('btn-chat-history').addEventListener('click', () => {
      this.showChatHistory();
    });

    // New chat
    document.getElementById('btn-new-chat').addEventListener('click', () => {
      this.clearChat();
    });

    // Right click on new chat also shows history
    document.getElementById('btn-new-chat').addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.showChatHistory();
    });

    // Model selector
    this.initModelSelector();
  }

  initModelSelector() {
    const selector = document.getElementById('model-selector');
    const dropdown = document.getElementById('model-dropdown');
    this.modelsLoaded = false;

    selector.addEventListener('click', () => {
      dropdown.classList.toggle('hidden');
      if (!dropdown.classList.contains('hidden') && !this.modelsLoaded) {
        this.refreshModels();
      }
    });

    // Model item click (delegated)
    dropdown.addEventListener('click', (e) => {
      const item = e.target.closest('.dropdown-item');
      if (!item || item.classList.contains('disabled')) return;

      const model = item.dataset.model;
      window.aiService.setModel(model);
      document.getElementById('model-name').textContent = item.textContent.trim();
      document.querySelector('.model-dot').classList.add('connected');
      document.querySelector('#status-model').textContent = model;
      document.querySelector('.status-dot').classList.add('online');

      dropdown.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      dropdown.classList.add('hidden');
    });

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#model-selector') && !e.target.closest('#model-dropdown')) {
        dropdown.classList.add('hidden');
      }
    });

    // Auto-set default model on init
    const defaultModel = window.aiService.model;
    if (defaultModel) {
      document.getElementById('model-name').textContent = defaultModel;
      document.querySelector('.model-dot').classList.add('connected');
      document.querySelector('#status-model').textContent = defaultModel;
      document.querySelector('.status-dot').classList.add('online');
    }
  }

  async refreshModels() {
    const container = document.getElementById('llm-models');
    container.innerHTML = '<div class="dropdown-item disabled">Loading models...</div>';

    const models = await window.aiService.fetchModels();
    if (models.length === 0) {
      // Still show the default model as selectable
      const defaultModel = window.aiService.model;
      container.innerHTML = `<div class="dropdown-item active" data-model="${defaultModel}">${defaultModel}</div>`;
    } else {
      container.innerHTML = models.map(m =>
        `<div class="dropdown-item${m.id === window.aiService.model ? ' active' : ''}" data-model="${m.id}">${m.name}</div>`
      ).join('');
    }

    this.modelsLoaded = true;
  }

  addCurrentFileContext() {
    const filePath = window.editorManager.getCurrentFilePath();
    const fileName = window.editorManager.getCurrentFileName();
    if (filePath) {
      this.addFileContext(filePath, fileName);
    }
  }

  async addFileContext(filePath, fileName) {
    // Avoid duplicates
    if (this.contexts.find(c => c.type === 'file' && c.label === fileName)) return;

    const content = await window.api.readFile(filePath);
    if (content && !content.error) {
      this.contexts.push({
        type: 'file', label: fileName, content: `File: ${fileName}\n\`\`\`\n${content}\n\`\`\``,
      });
      this.renderChips();
    }
  }

  // @ Autocomplete methods
  atDetect() {
    const text = this.inputEl.value;
    const cursor = this.inputEl.selectionStart;
    // Find @ before cursor
    const before = text.substring(0, cursor);
    const atMatch = before.match(/@(\w*)$/);
    if (atMatch) {
      this.atShow(atMatch[1]);
    } else {
      this.atHide();
    }
  }

  atShow(filter) {
    const filtered = this.atCommands.filter(c =>
      c.cmd.toLowerCase().includes(('@' + filter).toLowerCase())
    );
    if (filtered.length === 0) { this.atHide(); return; }

    this.atSelectedIdx = 0;
    this.atFiltered = filtered;
    this.atPopup.innerHTML = filtered.map((c, i) =>
      `<div class="at-item ${i === 0 ? 'selected' : ''}" data-idx="${i}">
        <span class="at-cmd">${c.cmd}</span>
        <span class="at-desc">${c.desc}</span>
      </div>`
    ).join('');
    this.atPopup.classList.remove('hidden');

    this.atPopup.querySelectorAll('.at-item').forEach(el => {
      el.addEventListener('click', () => {
        this.atSelectedIdx = parseInt(el.dataset.idx);
        this.atSelect();
      });
    });
  }

  atHide() {
    this.atPopup.classList.add('hidden');
    this.atFiltered = [];
  }

  atNavigate(dir) {
    if (!this.atFiltered || this.atFiltered.length === 0) return;
    this.atSelectedIdx = Math.max(0, Math.min(this.atFiltered.length - 1, this.atSelectedIdx + dir));
    this.atPopup.querySelectorAll('.at-item').forEach((el, i) =>
      el.classList.toggle('selected', i === this.atSelectedIdx)
    );
  }

  atSelect() {
    if (!this.atFiltered || !this.atFiltered[this.atSelectedIdx]) return;
    const cmd = this.atFiltered[this.atSelectedIdx];

    // Replace @partial with full command in input
    const text = this.inputEl.value;
    const cursor = this.inputEl.selectionStart;
    const before = text.substring(0, cursor);
    const after = text.substring(cursor);
    const replaced = before.replace(/@\w*$/, cmd.cmd + ' ');
    this.inputEl.value = replaced + after;
    this.inputEl.selectionStart = this.inputEl.selectionEnd = replaced.length;
    this.inputEl.focus();

    // Execute action if it has one (e.g., @file, @selection)
    if (cmd.action) cmd.action();

    this.atHide();
  }

  addContext(type, content) {
    if (type === 'selection') {
      // Remove previous selection context
      this.contexts = this.contexts.filter(c => c.type !== 'selection');
      this.contexts.push({
        type: 'selection', label: 'Selection',
        content: `Selected code:\n\`\`\`\n${content}\n\`\`\``,
      });
    } else if (type === 'workspace') {
      this.contexts = this.contexts.filter(c => c.type !== 'workspace');
      this.contexts.push({ type: 'workspace', label: '@workspace', content });
    }
    this.renderChips();
  }

  renderChips() {
    this.chipsEl.innerHTML = this.contexts.map((c, i) =>
      `<span class="ctx-chip">
        ${c.type === 'file' ? '&#128196;' : c.type === 'workspace' ? '&#127380;' : '&#9998;'}
        ${c.label}
        <span class="ctx-chip-x" data-idx="${i}">&times;</span>
      </span>`
    ).join('');

    this.chipsEl.querySelectorAll('.ctx-chip-x').forEach(el => {
      el.addEventListener('click', () => {
        this.contexts.splice(parseInt(el.dataset.idx), 1);
        this.renderChips();
      });
    });
  }

  focusInput() {
    this.inputEl.focus();
  }

  async sendWithPrompt(promptText) {
    // Make sure AI panel is visible
    const aiPanel = document.getElementById('ai-panel');
    if (aiPanel.classList.contains('hidden')) {
      aiPanel.classList.remove('hidden');
      document.querySelector('.resize-ai').style.display = 'block';
    }

    // Set the input text and send
    this.inputEl.value = promptText;
    this.send();
  }

  async send() {
    const text = this.inputEl.value.trim();
    if (!text || this.isStreaming) return;
    if (!window.aiService.model || !window.aiService.apiUrl) {
      this.addSystemMessage('Please configure LLM API in Settings first.');
      return;
    }

    // Check for @workspace command
    let workspaceAnalysis = '';
    if (text.includes('@workspace') && window.fileTree.rootPath) {
      this.addSystemMessage('Analyzing project files...');
      let result = await window.aiService.analyzeProject(window.fileTree.rootPath);
      // If project is large and not cached, use chunked analysis
      if (result && result.fileCount > 30 && !result.cached) {
        this.addSystemMessage(`Large project (${result.fileCount} files) — analyzing in chunks...`);
        result = await window.aiService.analyzeProjectChunked(window.fileTree.rootPath, (current, total) => {
          this.tokenInfo.textContent = `Analyzing chunk ${current}/${total}...`;
        });
      }
      if (result) {
        workspaceAnalysis = `\nProject has ${result.fileCount} files.`;
        this.addContext('workspace', `Project file list:\n${result.tree}`);
      }
    }

    // Build context string
    let contextStr = '';
    for (const ctx of this.contexts) {
      contextStr += ctx.content + '\n\n';
    }

    // Only add file context if user explicitly used @ commands
    // (not automatically on every message)
    if (text.includes('@file') && !contextStr && window.editorManager.getCurrentFilePath()) {
      const content = window.editorManager.getCurrentFileContent();
      const name = window.editorManager.getCurrentFileName();
      if (content) {
        contextStr = `Currently editing: ${name}\n\`\`\`\n${content}\n\`\`\`\n`;
      }
    }

    // Include code validation only when file context is active
    if (contextStr) {
      const currentPath = window.editorManager.getCurrentFilePath();
      if (currentPath) {
        const validationCtx = await window.aiService.getValidationContext(currentPath);
        if (validationCtx) contextStr += validationCtx;
      }
    }

    // Clear welcome
    const welcome = this.messagesEl.querySelector('.ai-welcome');
    if (welcome) welcome.remove();

    // Add user message
    this.addUserMessage(text);
    this.inputEl.value = '';
    this.inputEl.style.height = '44px';

    // Add loading
    const loadingEl = this.addLoading();

    this.isStreaming = true;
    this.tokenInfo.textContent = 'Generating...';
    this.stopBtn.style.display = 'flex';
    this.sendBtn.style.display = 'none';

    // Create AI message container
    const aiMsgEl = this.createAiMessageEl();
    const bodyEl = aiMsgEl.querySelector('.msg-body');

    let fullContent = '';

    // Check if compression happened
    const historyLen = window.aiService.history.length;
    if (historyLen > 0 && window.aiService.history[0].role === 'system' &&
        window.aiService.history[0].content.startsWith('[Previous conversation summary]')) {
      this.tokenInfo.textContent = 'Compressed history...';
    }

    window.aiService.sendMessageStream(
      text, contextStr,
      // onChunk
      (delta, accumulated) => {
        loadingEl.remove();
        fullContent = accumulated;
        bodyEl.innerHTML = this.renderMarkdown(accumulated);
        this.scrollToBottom();
      },
      // onDone
      (finalContent) => {
        this.isStreaming = false;
        this.stopBtn.style.display = 'none';
        this.sendBtn.style.display = 'flex';
        loadingEl.remove();
        bodyEl.innerHTML = this.renderMarkdown(finalContent);
        this.attachCodeBlockActions(aiMsgEl);

        // Token usage with budget info
        const b = window.aiService.budget;
        const usedTokens = window.aiService.estimateTokens(contextStr + text + finalContent);
        const histTokens = window.aiService.estimateTokens(window.aiService.history.map(m => m.content).join(''));
        this.tokenInfo.textContent = `~${usedTokens} tok | hist ${histTokens.toLocaleString()}/${b.history.toLocaleString()}`;

        // Sync compression summary to sessionMeta
        const summaryMsg = window.aiService.history.find(m =>
          m.role === 'system' && m.content.startsWith('[Previous conversation summary]')
        );
        if (summaryMsg) {
          this.sessionMeta.summary = summaryMsg.content.replace('[Previous conversation summary]\n', '');
        }

        this.scrollToBottom();
        this.saveCurrentChat();

        // Auto-show Diff in main editor if file context is active and code block exists
        this.autoShowDiff(finalContent);
      },
      // onError
      (error) => {
        this.isStreaming = false;
        this.stopBtn.style.display = 'none';
        this.sendBtn.style.display = 'flex';
        loadingEl.remove();
        bodyEl.innerHTML = `<p style="color:#f85149;">Error: ${error}</p>`;
        this.tokenInfo.textContent = 'Error';
      }
    );
  }

  addUserMessage(text) {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const el = document.createElement('div');
    el.className = 'msg msg-user';
    el.innerHTML = `
      <div class="msg-header">
        <div class="msg-avatar avatar-user">U</div>
        <span class="msg-name">You</span>
        <span class="msg-time">${time}</span>
      </div>
      ${this.contexts.length ? this.renderContextTags() : ''}
      <div class="msg-body"><p>${this.escapeHtml(text)}</p></div>
    `;
    this.messagesEl.appendChild(el);
    this.scrollToBottom();
  }

  renderContextTags() {
    return '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:6px;">' +
      this.contexts.map(c =>
        `<span class="ctx-chip">${c.type === 'file' ? '&#128196;' : c.type === 'workspace' ? '&#127380;' : '&#9998;'} ${c.label}</span>`
      ).join('') + '</div>';
  }

  createAiMessageEl() {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const el = document.createElement('div');
    el.className = 'msg msg-ai';
    el.innerHTML = `
      <div class="msg-header">
        <div class="msg-avatar avatar-ai">AI</div>
        <span class="msg-name">Copilot</span>
        <span class="msg-time">${time}</span>
      </div>
      <div class="msg-body"></div>
    `;
    this.messagesEl.appendChild(el);
    return el;
  }

  addLoading() {
    const el = document.createElement('div');
    el.className = 'ai-loading';
    el.innerHTML = '<div class="ai-loading-dots"><span>.</span><span>.</span><span>.</span></div> Thinking...';
    this.messagesEl.appendChild(el);
    this.scrollToBottom();
    return el;
  }

  addSystemMessage(text) {
    const el = document.createElement('div');
    el.style.cssText = 'padding:6px 14px; font-size:12px; color:#888; font-style:italic;';
    el.textContent = text;
    this.messagesEl.appendChild(el);
    this.scrollToBottom();
  }

  renderMarkdown(text) {
    // Extract code blocks first to protect them from other replacements
    const codeBlocks = [];
    let processed = text.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
      const langLabel = lang || 'code';
      const placeholder = `__CODEBLOCK_${codeBlocks.length}__`;
      codeBlocks.push(`<div class="ai-code-block">
        <div class="ai-code-header">
          <span class="ai-code-lang">${langLabel}</span>
          <div class="ai-code-actions">
            <button class="ai-code-btn copy-btn">Copy</button>
            <button class="ai-code-btn apply">Apply</button>
          </div>
        </div>
        <pre class="ai-code-pre">${this.escapeHtml(code.trim())}</pre>
      </div>`);
      return placeholder;
    });

    // Now escape HTML on the remaining text (not code blocks)
    processed = this.escapeHtml(processed);

    // Inline code
    processed = processed.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold
    processed = processed.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Italic
    processed = processed.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Paragraphs (double newline)
    processed = processed.replace(/\n\n/g, '</p><p>');

    // Single newlines to <br>
    processed = processed.replace(/\n/g, '<br>');

    // Restore code blocks
    for (let i = 0; i < codeBlocks.length; i++) {
      processed = processed.replace(`__CODEBLOCK_${i}__`, codeBlocks[i]);
    }

    return `<p>${processed}</p>`;
  }

  autoShowDiff(finalContent) {
    // Only auto-show if a file is open and the response contains a code block
    const currentPath = window.editorManager.getCurrentFilePath();
    if (!currentPath) return;

    // Check if there's a code block with substantial code (not just a snippet)
    const codeMatch = finalContent.match(/```\w*\n([\s\S]*?)```/);
    if (!codeMatch) return;

    const suggestedCode = codeMatch[1].trim();
    if (!suggestedCode) return;

    // Only auto-diff if the suggested code looks like a full file replacement
    // (has multiple lines and is significantly different from a short snippet)
    const currentContent = window.editorManager.getCurrentFileContent();
    if (!currentContent) return;

    const suggestedLines = suggestedCode.split('\n').length;
    const currentLines = currentContent.split('\n').length;

    // Heuristic: auto-show diff if suggested code is at least 30% of the original file size
    // or has 5+ lines (likely a meaningful code change, not just a one-liner example)
    if (suggestedLines < 5) return;
    if (suggestedLines < currentLines * 0.2 && suggestedLines < 20) return;

    // Auto-show diff in main editor
    window.editorManager.showDiffInEditor(currentPath, suggestedCode);
    this.addSystemMessage('Changes shown in editor. Review and Accept or Discard.');
  }

  attachCodeBlockActions(msgEl) {
    // Copy buttons
    msgEl.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const code = btn.closest('.ai-code-block').querySelector('.ai-code-pre').textContent;
        navigator.clipboard.writeText(code);
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy', 1500);
      });
    });

    // Apply buttons — show diff in main editor (VS Code style)
    msgEl.querySelectorAll('.ai-code-btn.apply').forEach(btn => {
      btn.addEventListener('click', async () => {
        const codeBlock = btn.closest('.ai-code-block');
        const newCode = codeBlock.querySelector('.ai-code-pre').textContent;
        const langLabel = codeBlock.querySelector('.ai-code-lang')?.textContent || '';

        // Try to find target file
        let targetPath = window.editorManager.getCurrentFilePath();

        if (langLabel.includes('/') || langLabel.includes('\\') || langLabel.includes('.')) {
          // File path hint in language label
          if (window.fileTree.rootPath) {
            const sep = window.fileTree.rootPath.includes('/') ? '/' : '\\';
            const fullPath = window.fileTree.rootPath + sep + langLabel;
            const exists = await window.api.pathExists(fullPath);
            if (exists) {
              await window.editorManager.openFile(fullPath, langLabel.split(/[/\\]/).pop());
              targetPath = fullPath;
            }
          }
        }

        if (!targetPath) {
          this.addSystemMessage('No file is open to apply changes to.');
          return;
        }

        // Show diff in main editor
        const shown = window.editorManager.showDiffInEditor(targetPath, newCode);
        if (shown) {
          btn.textContent = 'Reviewing...';
          btn.disabled = true;
          setTimeout(() => { btn.textContent = 'Apply'; btn.disabled = false; }, 2000);
        } else {
          // Fallback to chat panel diff
          this.showDiffAndApply(newCode, codeBlock);
        }
      });
    });
  }

  parseMultiFileBlocks(content) {
    // Detect patterns like "### filename.js" or "**filename.js**" followed by code blocks
    // Also detect ```language:filepath or ```filepath patterns
    const blocks = [];
    const regex = /(?:^|\n)(?:#{1,3}\s+`?([^\n`]+\.\w+)`?|(?:\*\*([^\n*]+\.\w+)\*\*))\s*\n```(\w*)\n([\s\S]*?)```/g;
    let match;

    while ((match = regex.exec(content)) !== null) {
      const fileName = match[1] || match[2];
      const lang = match[3] || '';
      const code = match[4].trim();
      blocks.push({ fileName, lang, code });
    }

    // Also try ```lang:filepath pattern
    const regex2 = /```(\w+):([^\n]+)\n([\s\S]*?)```/g;
    while ((match = regex2.exec(content)) !== null) {
      const lang = match[1];
      const fileName = match[2].trim();
      const code = match[3].trim();
      // Avoid duplicates
      if (!blocks.find(b => b.fileName === fileName)) {
        blocks.push({ fileName, lang, code });
      }
    }

    return blocks;
  }

  async applyToFile(filePath, newCode, codeBlockEl) {
    // Try to find the file in the project
    if (window.fileTree.rootPath) {
      const fullPath = window.fileTree.rootPath + (window.fileTree.rootPath.includes('/') ? '/' : '\\') + filePath;
      const exists = await window.api.pathExists(fullPath);
      if (exists) {
        // Open the file and show diff
        await window.editorManager.openFile(fullPath, filePath.split(/[/\\]/).pop());
        setTimeout(() => this.showDiffAndApply(newCode, codeBlockEl), 200);
        return;
      }
    }
    // Fallback to current file
    this.showDiffAndApply(newCode, codeBlockEl);
  }

  showMultiFileDiff(blocks, containerEl) {
    const wrapper = document.createElement('div');
    wrapper.className = 'multi-file-diff';

    let html = `<div class="multi-file-header">
      <span>${blocks.length} files to modify</span>
      <div class="diff-actions">
        <button class="diff-btn accept" id="accept-all-btn">&#10003; Accept All</button>
        <button class="diff-btn reject" id="reject-all-btn">&#10007; Reject All</button>
      </div>
    </div>`;

    for (const block of blocks) {
      html += `<div class="multi-file-item" data-file="${block.fileName}">
        <div class="diff-header">
          <span class="diff-filename">${block.fileName}</span>
          <div class="diff-actions">
            <button class="diff-btn accept file-accept">&#10003;</button>
            <button class="diff-btn reject file-reject">&#10007;</button>
          </div>
        </div>
        <pre class="ai-code-pre" style="max-height:200px;overflow:auto;">${this.escapeHtml(block.code)}</pre>
      </div>`;
    }

    wrapper.innerHTML = html;
    containerEl.replaceWith(wrapper);

    // Per-file accept
    wrapper.querySelectorAll('.file-accept').forEach(btn => {
      btn.addEventListener('click', async () => {
        const item = btn.closest('.multi-file-item');
        const fileName = item.dataset.file;
        const code = item.querySelector('.ai-code-pre').textContent;
        await this.applyToFile(fileName, code, item);
      });
    });

    // Per-file reject
    wrapper.querySelectorAll('.file-reject').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.multi-file-item');
        item.innerHTML = `<div style="padding:8px 12px; color:#f85149; font-size:12px;">&#10007; ${item.dataset.file} — rejected</div>`;
      });
    });

    // Accept All
    wrapper.querySelector('#accept-all-btn')?.addEventListener('click', async () => {
      for (const block of blocks) {
        await this.applyToFile(block.fileName, block.code, wrapper);
      }
      wrapper.innerHTML = `<div style="padding:10px 12px; color:#4ec9b0; font-size:12px;">&#10003; All ${blocks.length} files applied</div>`;
    });

    // Reject All
    wrapper.querySelector('#reject-all-btn')?.addEventListener('click', () => {
      wrapper.innerHTML = `<div style="padding:10px 12px; color:#f85149; font-size:12px;">&#10007; All changes rejected</div>`;
    });
  }

  showDiffAndApply(newCode, codeBlockEl) {
    const currentPath = window.editorManager.getCurrentFilePath();
    const currentContent = window.editorManager.getCurrentFileContent();
    const fileName = window.editorManager.getCurrentFileName() || 'current file';
    const language = window.editorManager.activeTab ?
      (window.editorManager.tabs.get(window.editorManager.activeTab)?.language || 'plaintext') : 'plaintext';

    if (currentContent === null || currentContent === undefined) {
      this.addSystemMessage('No file is open to apply changes to.');
      return;
    }

    // Create diff view container
    const diffEl = document.createElement('div');
    diffEl.className = 'ai-diff-block';

    const diffId = 'diff-' + Date.now();
    diffEl.innerHTML = `
      <div class="diff-header">
        <span class="diff-filename">${fileName}</span>
        <div class="diff-view-toggle">
          <button class="diff-toggle-btn active" data-mode="side">Side by Side</button>
          <button class="diff-toggle-btn" data-mode="inline">Inline</button>
        </div>
        <div class="diff-actions">
          <button class="diff-btn accept">&#10003; Accept</button>
          <button class="diff-btn reject">&#10007; Reject</button>
        </div>
      </div>
      <div class="diff-editor-container" id="${diffId}" style="height:300px;"></div>
    `;

    // Replace code block with diff
    codeBlockEl.replaceWith(diffEl);

    // Create Monaco DiffEditor
    const container = diffEl.querySelector(`#${diffId}`);
    const originalModel = monaco.editor.createModel(currentContent, language);
    const modifiedModel = monaco.editor.createModel(newCode, language);

    const diffEditor = monaco.editor.createDiffEditor(container, {
      theme: 'vs-dark',
      readOnly: true,
      automaticLayout: true,
      renderSideBySide: true,
      fontSize: 12,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      lineNumbers: 'on',
      glyphMargin: false,
      folding: false,
    });

    diffEditor.setModel({
      original: originalModel,
      modified: modifiedModel,
    });

    // Toggle side-by-side / inline
    diffEl.querySelectorAll('.diff-toggle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        diffEl.querySelectorAll('.diff-toggle-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        diffEditor.updateOptions({ renderSideBySide: btn.dataset.mode === 'side' });
      });
    });

    // Accept
    diffEl.querySelector('.diff-btn.accept').addEventListener('click', () => {
      if (currentPath) {
        window.editorManager.applyDiff(currentPath, newCode);
      }
      diffEditor.dispose();
      originalModel.dispose();
      modifiedModel.dispose();
      diffEl.innerHTML = `<div style="padding:10px 12px; color:#4ec9b0; font-size:12px;">&#10003; Changes applied to ${fileName}</div>`;
    });

    // Reject
    diffEl.querySelector('.diff-btn.reject').addEventListener('click', () => {
      diffEditor.dispose();
      originalModel.dispose();
      modifiedModel.dispose();
      diffEl.innerHTML = `<div style="padding:10px 12px; color:#f85149; font-size:12px;">&#10007; Changes rejected</div>`;
    });
  }

  generateDiff(oldLines, newLines) {
    // Simple LCS-based diff
    const lcs = this.lcs(oldLines, newLines);
    let html = '';
    let oi = 0, ni = 0, li = 0;

    while (oi < oldLines.length || ni < newLines.length) {
      if (li < lcs.length && oi < oldLines.length && ni < newLines.length &&
          oldLines[oi] === lcs[li] && newLines[ni] === lcs[li]) {
        html += `<div class="diff-line diff-ctx"><span class="diff-ln">${oi + 1}</span>${this.escapeHtml(oldLines[oi])}</div>`;
        oi++; ni++; li++;
      } else if (oi < oldLines.length && (li >= lcs.length || oldLines[oi] !== lcs[li])) {
        html += `<div class="diff-line diff-del"><span class="diff-ln">-</span>${this.escapeHtml(oldLines[oi])}</div>`;
        oi++;
      } else if (ni < newLines.length && (li >= lcs.length || newLines[ni] !== lcs[li])) {
        html += `<div class="diff-line diff-add"><span class="diff-ln">+</span>${this.escapeHtml(newLines[ni])}</div>`;
        ni++;
      }
    }
    return html;
  }

  lcs(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1] + 1 : Math.max(dp[i-1][j], dp[i][j-1]);
      }
    }

    const result = [];
    let i = m, j = n;
    while (i > 0 && j > 0) {
      if (a[i-1] === b[j-1]) { result.unshift(a[i-1]); i--; j--; }
      else if (dp[i-1][j] > dp[i][j-1]) i--;
      else j--;
    }
    return result;
  }

  generateChatId() {
    return 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  }

  getHistoryRoot() {
    return window.fileTree.rootPath || null;
  }

  async saveCurrentChat() {
    const root = this.getHistoryRoot();
    if (!root) return;
    if (!this.currentChatId) this.currentChatId = this.generateChatId();
    const history = window.aiService.history;
    if (history.length === 0) return;

    // Auto-extract session metadata
    this.updateSessionMeta();

    const title = history[0]?.content?.substring(0, 50) || 'New Chat';
    await window.api.saveChat(root, this.currentChatId, {
      id: this.currentChatId,
      title,
      timestamp: Date.now(),
      messages: history,
      session: {
        task: this.sessionMeta.task,
        summary: this.sessionMeta.summary,
        keyDecisions: this.sessionMeta.keyDecisions,
        modifiedFiles: this.sessionMeta.modifiedFiles,
        pendingTasks: this.sessionMeta.pendingTasks,
        budgetSnapshot: window.aiService.budget.toJSON(),
      },
    });
  }

  // Auto-extract session metadata from current state
  updateSessionMeta() {
    const history = window.aiService.history;

    // Task: first user message (truncated)
    if (!this.sessionMeta.task && history.length > 0) {
      const firstUser = history.find(m => m.role === 'user');
      if (firstUser) {
        this.sessionMeta.task = firstUser.content.substring(0, 100);
      }
    }

    // Summary: use compressed history if available
    const summaryMsg = history.find(m =>
      m.role === 'system' && m.content.startsWith('[Previous conversation summary]')
    );
    if (summaryMsg) {
      this.sessionMeta.summary = summaryMsg.content.replace('[Previous conversation summary]\n', '');
    } else if (history.length >= 4) {
      // Fallback: last assistant message as rough summary
      const lastAssistant = [...history].reverse().find(m => m.role === 'assistant');
      if (lastAssistant) {
        this.sessionMeta.summary = lastAssistant.content.substring(0, 300);
      }
    }

    // Modified files: extract from file contexts used in this session
    const fileNames = this.contexts
      .filter(c => c.type === 'file')
      .map(c => c.label);
    if (fileNames.length > 0) {
      // Merge without duplicates
      for (const f of fileNames) {
        if (!this.sessionMeta.modifiedFiles.includes(f)) {
          this.sessionMeta.modifiedFiles.push(f);
        }
      }
    }
  }

  async showChatHistory() {
    const root = this.getHistoryRoot();
    if (!root) {
      this.addSystemMessage('Open a folder first to use chat history.');
      return;
    }
    const chats = await window.api.listChats(root);
    if (chats.error || chats.length === 0) {
      this.addSystemMessage('No saved chats found.');
      return;
    }

    // Show chat list in messages area
    const listEl = document.createElement('div');
    listEl.style.cssText = 'padding: 8px;';
    listEl.innerHTML = '<div style="font-size:12px;color:#888;padding:4px 8px;font-weight:600;">Chat History</div>' +
      chats.slice(0, 20).map(c =>
        `<div class="search-match" data-chat-id="${c.id}" style="padding:6px 12px;cursor:pointer;font-size:12px;color:#ccc;">
          ${c.title || 'Untitled'}
          <span style="float:right;color:#666;font-size:11px;">${new Date(c.timestamp).toLocaleDateString()}</span>
        </div>`
      ).join('');

    this.messagesEl.innerHTML = '';
    this.messagesEl.appendChild(listEl);

    listEl.querySelectorAll('.search-match').forEach(el => {
      el.addEventListener('click', () => this.loadChatById(el.dataset.chatId));
    });
  }

  async loadChatById(chatId) {
    const root = this.getHistoryRoot();
    if (!root) return;
    const data = await window.api.loadChat(root, chatId);
    if (data.error) return;

    this.currentChatId = chatId;
    window.aiService.history = data.messages || [];

    // Restore session metadata
    if (data.session) {
      this.sessionMeta = {
        task: data.session.task || '',
        summary: data.session.summary || '',
        keyDecisions: data.session.keyDecisions || [],
        modifiedFiles: data.session.modifiedFiles || [],
        pendingTasks: data.session.pendingTasks || [],
      };

      // Restore budget if saved
      if (data.session.budgetSnapshot) {
        window.aiService.budget.loadFrom(data.session.budgetSnapshot);
      }

      // If history is empty but summary exists, inject as context
      if (window.aiService.history.length === 0 && data.session.summary) {
        window.aiService.history.push({
          role: 'system',
          content: `[Previous session summary]\n${data.session.summary}`,
        });
      }
    } else {
      // Legacy chat without session — reset meta
      this.sessionMeta = { task: '', summary: '', keyDecisions: [], modifiedFiles: [], pendingTasks: [] };
    }

    // Re-render messages
    this.messagesEl.innerHTML = '';

    // Show session info banner if available
    if (data.session && (data.session.task || data.session.modifiedFiles?.length)) {
      this.showSessionBanner(data.session);
    }

    for (const msg of data.messages) {
      if (msg.role === 'user') {
        this.addUserMessage(msg.content);
      } else if (msg.role === 'assistant') {
        const aiMsgEl = this.createAiMessageEl();
        const bodyEl = aiMsgEl.querySelector('.msg-body');
        bodyEl.innerHTML = this.renderMarkdown(msg.content);
        this.attachCodeBlockActions(aiMsgEl);
      }
    }
    this.scrollToBottom();
  }

  showSessionBanner(session) {
    const el = document.createElement('div');
    el.style.cssText = 'padding:8px 14px;margin-bottom:8px;background:#1e1e1e;border-radius:6px;border-left:3px solid #b48ead;font-size:12px;color:#aaa;';

    let html = '';
    if (session.task) {
      html += `<div style="color:#ccc;font-weight:600;margin-bottom:4px;">${this.escapeHtml(session.task.substring(0, 80))}</div>`;
    }
    if (session.modifiedFiles && session.modifiedFiles.length > 0) {
      html += `<div>Files: ${session.modifiedFiles.map(f => `<code style="background:#333;padding:0 4px;border-radius:2px;">${this.escapeHtml(f)}</code>`).join(' ')}</div>`;
    }
    if (session.keyDecisions && session.keyDecisions.length > 0) {
      html += `<div style="margin-top:3px;color:#888;">Decisions: ${session.keyDecisions.map(d => this.escapeHtml(d)).join(' | ')}</div>`;
    }
    if (session.budgetSnapshot) {
      const bk = (session.budgetSnapshot.numCtx / 1024).toFixed(0);
      html += `<div style="margin-top:3px;color:#666;">Budget: ${bk}K context</div>`;
    }

    el.innerHTML = html;
    this.messagesEl.appendChild(el);
  }

  showAiHelp() {
    this.messagesEl.innerHTML = '';
    const helpEl = document.createElement('div');
    helpEl.style.cssText = 'padding: 12px 16px; font-size: 13px; color: #ccc; line-height: 1.7;';
    helpEl.innerHTML = `
      <h3 style="color:#b48ead;margin-bottom:12px;font-size:16px;">WSCODE AI Copilot Guide</h3>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">@ 명령어 (입력창에서 @ 입력)</div>
        <div style="padding-left:12px;">
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">@file</code> — 현재 편집 중인 파일을 AI에게 전달</div>
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">@workspace</code> — 전체 프로젝트를 분석하여 AI에게 전달</div>
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">@selection</code> — 에디터에서 선택한 코드를 AI에게 전달</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">에디터 우클릭 메뉴 (코드 선택 후)</div>
        <div style="padding-left:12px;">
          <div><b>AI: Explain</b> — 선택한 코드를 상세 설명</div>
          <div><b>AI: Refactor</b> — 코드 리팩토링 제안</div>
          <div><b>AI: Generate Tests</b> — 단위 테스트 자동 생성</div>
          <div><b>AI: Fix Bugs</b> — 버그 찾기 및 수정</div>
          <div><b>AI: Add Comments</b> — 주석 자동 추가</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">Diff & Apply (AI 코드 제안)</div>
        <div style="padding-left:12px;">
          <div><b>자동 Diff:</b> @file로 파일 컨텍스트 추가 후 수정 요청하면, AI 응답 완료 시 <b>자동으로 메인 에디터에 Diff 표시</b></div>
          <div><b>수동 Diff:</b> 채팅의 코드블록에서 <b>Apply</b> 버튼 클릭으로도 가능</div>
          <div><b>Side-by-side / Inline</b> 토글, Modified 쪽 직접 편집 가능</div>
          <div><b>Accept Changes</b> — 원본을 <code style="background:#333;padding:1px 6px;border-radius:3px;">파일명-bak01.ext</code> 로 백업 후 저장</div>
          <div><b>Discard</b> — 변경 취소, 원본 유지</div>
          <div>백업 파일은 자동 번호 증가 (-bak01, -bak02, ...)</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">Ghost Text (자동완성)</div>
        <div style="padding-left:12px;">
          <div>코드 입력 중 AI가 자동으로 완성 제안 (회색 텍스트)</div>
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">Tab</code> 수락 &nbsp;|&nbsp; <code style="background:#333;padding:1px 6px;border-radius:3px;">Esc</code> 취소 &nbsp;|&nbsp; <code style="background:#333;padding:1px 6px;border-radius:3px;">Ctrl+I</code> on/off</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">단축키</div>
        <div style="padding-left:12px;">
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">Ctrl+Shift+I</code> — AI 패널 열기/닫기</div>
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">Ctrl+L</code> — 선택 영역 AI에 전송</div>
          <div><code style="background:#333;padding:1px 6px;border-radius:3px;">Ctrl+I</code> — Ghost Text on/off</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">상단 아이콘</div>
        <div style="padding-left:12px;">
          <div><b>?</b> — 이 도움말</div>
          <div><b>📜</b> — 이전 대화 목록 불러오기</div>
          <div><b>+</b> — 새 세션 시작</div>
          <div><b>⚙</b> — LLM 설정 (API URL, Key, Model, System Prompt)</div>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="color:#9cdcfe;font-weight:600;margin-bottom:4px;">캐시 시스템</div>
        <div style="padding-left:12px;">
          <div><b>LLM 캐시</b> — 동일 질문 재사용 (24시간)</div>
          <div><b>RAG 캐시</b> — 프로젝트 분석 결과 캐싱 (5분)</div>
          <div><b>Semantic 캐시</b> — 유사 질문 매칭 (48시간)</div>
          <div><b>대화 압축</b> — 긴 대화 자동 요약 (10+ 메시지)</div>
        </div>
      </div>

      <div style="color:#666;font-size:11px;border-top:1px solid #333;padding-top:8px;">
        대화 히스토리는 프로젝트 <code>.history/</code> 폴더에 저장됩니다.
      </div>
    `;
    this.messagesEl.appendChild(helpEl);
    this.scrollToBottom();
  }

  clearChat() {
    this.saveCurrentChat();
    this.currentChatId = this.generateChatId();
    window.aiService.clearHistory();
    window.aiService.projectContext = null;
    this.contexts = [];
    this.sessionMeta = { task: '', summary: '', keyDecisions: [], modifiedFiles: [], pendingTasks: [] };
    this.renderChips();
    this.messagesEl.innerHTML = `
      <div class="ai-welcome">
        <div class="ai-welcome-icon">&#129302;</div>
        <h3>WSCODE AI Copilot</h3>
        <p>Ask me anything about your code.</p>
        <p class="ai-welcome-hint">Use <code>@workspace</code> to analyze the whole project<br>Use <code>@file</code> to reference a specific file</p>
      </div>
    `;
    this.tokenInfo.textContent = 'Ready';
  }

  stopGenerating() {
    if (!this.isStreaming) return;
    window.api.aiStreamAbort();
    window.api.removeAiStreamListeners();
    this.isStreaming = false;
    this.stopBtn.style.display = 'none';
    this.sendBtn.style.display = 'flex';
    this.tokenInfo.textContent = 'Stopped';
    // Remove loading indicator if present
    const loading = this.messagesEl.querySelector('.ai-loading');
    if (loading) loading.remove();
  }

  scrollToBottom() {
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  unescapeHtml(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    return doc.body.textContent || '';
  }
}

window.aiPanel = new AIPanel();
